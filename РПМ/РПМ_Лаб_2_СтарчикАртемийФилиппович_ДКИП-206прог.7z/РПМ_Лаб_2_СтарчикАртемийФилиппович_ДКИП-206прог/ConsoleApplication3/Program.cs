﻿using System;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое десятичное число N: ");
        int N = int.Parse(Console.ReadLine());

        Console.Write("Введите основание системы счисления p (p > 10): ");
        int p = int.Parse(Console.ReadLine());

        if (p < 2 || p >= 10)
        {
            Console.WriteLine("Основание системы счисления должно быть в пределах от 2 до 9.");
            return;
        }
        string result = ConvertToBase(N, p);
        Console.WriteLine("Число {N} в {p}-ичной системе счисления: {result}");
    }
    static string ConvertToBase(int number, int BaseValue)
    {
        if (number == 0) return "0";
        string result = "";
        bool isNegative = number < 0;
        number = Math.Abs(number);
        while (number > 0)
        {
            result = (number % BaseValue) + result;
            number /= BaseValue;
        }
        return (isNegative ? "-" : "") + result;
    }
}

