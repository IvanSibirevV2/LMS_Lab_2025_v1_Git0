﻿using System;

namespace Lab3Combined
{
    // Лабораторная работа 2. Организация циклов
    // ФИО: [Алиев Тимур Заурович]
    // Группа: [VДКИП 111-прог]
    // Дата: 18 марта 2025

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа 3. Организация циклов");
            Console.WriteLine("Выберите задание:");
            Console.WriteLine("1 - Таблица значений функции");
            Console.WriteLine("2 - Серия выстрелов по мишени");
            Console.WriteLine("3 - Ряды Тейлора для sin(x)");
            Console.WriteLine("Введите номер задачи (1, 2 или 3):");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Task1();
                    break;
                case "2":
                    Task2();
                    break;
                case "3":
                    Task3();
                    break;
                default:
                    Console.WriteLine("Ошибка: введите 1, 2 или 3.");
                    break;
            }
        }

        // Задание 1: Таблица значений функции
        static void Task1()
        {
            Console.WriteLine("\nЗадание 1: Таблица значений функции");
            Console.WriteLine("Функция: f(x) = -R при x < -R; x при -R <= x < 0; x^2 при 0 <= x < R; R при x >= R");
            Console.WriteLine("Введите параметр R:");
            if (!double.TryParse(Console.ReadLine(), out double R) || R <= 0)
            {
                Console.WriteLine("Ошибка: R должен быть положительным числом.");
                return;
            }

            double xStart = -R - 1; // Начало интервала
            double xEnd = R + 1;    // Конец интервала
            double dx = R / 2;      // Шаг для проверки всех ветвей

            Console.WriteLine("\nТаблица значений функции f(x):");
            Console.WriteLine("---------------------------------");
            Console.WriteLine("|    x    |    f(x)    |");
            Console.WriteLine("---------------------------------");

            for (double x = xStart; x <= xEnd; x += dx)
            {
                double fx;
                if (x < -R)
                    fx = -R;
                else if (x >= -R && x < 0)
                    fx = x;
                else if (x >= 0 && x < R)
                    fx = x * x;
                else
                    fx = R;

                Console.WriteLine($"| {x,7:F2} | {fx,10:F2} |");
            }
            Console.WriteLine("---------------------------------");
        }

        // Задание 2: Серия выстрелов по мишени
        static void Task2()
        {
            Console.WriteLine("\nЗадание 2: Серия выстрелов по мишени");
            Console.WriteLine("Введите радиус мишени R:");
            if (!double.TryParse(Console.ReadLine(), out double R) || R <= 0)
            {
                Console.WriteLine("Ошибка: R должен быть положительным числом.");
                return;
            }

            Console.WriteLine("\nВведите координаты 10 выстрелов:");
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"\nВыстрел {i}:");
                Console.Write("x = ");
                if (!double.TryParse(Console.ReadLine(), out double x))
                {
                    Console.WriteLine("Ошибка: введите корректное число для x.");
                    return;
                }

                Console.Write("y = ");
                if (!double.TryParse(Console.ReadLine(), out double y))
                {
                    Console.WriteLine("Ошибка: введите корректное число для y.");
                    return;
                }

                bool isHit = (x * x + y * y) <= (R * R);
                Console.WriteLine(isHit ? "Попадание!" : "Промах!");
            }
        }

        // Задание 3: Ряды Тейлора для sin(x)
        static void Task3()
        {
            Console.WriteLine("\nЗадание 3: Ряды Тейлора для sin(x)");
            double xStart = -1.0, xEnd = 1.0, dx = 0.5, epsilon = 0.0001;

            Console.WriteLine("\nТаблица значений sin(x) через ряд Тейлора:");
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("|    x    |   sin(x)   | Членов ряда |");
            Console.WriteLine("-------------------------------------------------");

            for (double x = xStart; x <= xEnd; x += dx)
            {
                double sum = 0;
                double term = x; // Первый член ряда
                int n = 1;
                int termsCount = 1;

                while (Math.Abs(term) >= epsilon)
                {
                    sum += term;
                    n += 2;
                    term = -term * x * x / (n * (n - 1)); // Следующий член
                    termsCount++;
                }

                Console.WriteLine($"| {x,7:F2} | {sum,10:F6} | {termsCount,11} |");
            }
            Console.WriteLine("-------------------------------------------------");
        }
    }
}