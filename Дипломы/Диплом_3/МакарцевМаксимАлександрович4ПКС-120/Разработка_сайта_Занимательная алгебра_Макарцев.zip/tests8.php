<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "<script>
        if (confirm('Вы должны зарегистрироваться или войти, чтобы пройти тест. Нажмите ОК для входа или Отмена для возвращения на главную страницу.')) {
            window.location.href = 'authorization.html';
        } else {
            window.location.href = 'math.php';
        }
    </script>";
    exit();
}
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}

mysqli_set_charset($connect, 'utf8');

$header = mysqli_query($connect, "SELECT * FROM `adm_headerlt`");
$header = mysqli_fetch_all($header);

$test = mysqli_query($connect, "SELECT * FROM `test_answers`");
$test = mysqli_fetch_all($test);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование 8 класс | InterestAlg</title>
    <link rel="stylesheet" href="css/tests.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <style>
        .question ul {
            list-style-type: none;
            padding-left: 0;
        }
    </style>
</head>
<body>
    <header>
        <div id="header">
            <div id="logo" onclick="slowScroll('#test')">
                <span>InterestAlg</span>
            </div>
            <div id="back">
                <a href="math.php#materials" title="Лекционный материал" onclick="slowScroll('#materials')"><?php echo $header[0][1]?></a>
                <a href="math.php#test" title="Тестирование"><?php echo $header[0][2]?></a>
                <a href="math.php"><?php echo $header[0][3]?></a>
            </div>
        </div>
    </header> 
    <main>
        <div class="fullpage">
            <div class="heading">
                <h2>Тестирование для 8 класса</h2>
            </div>
            <div id="test">
                <div class="container1">
                    <form class="testForm" id="testForm" action="save_test_result.php" method="POST" data-test-id="2">
                        <input type="hidden" name="testId" id="testId" value="2">
                        <div class="question">
                            <h3><?php echo $test[10][2]?></h3>
                            <label><input type="radio" name="11" value="a" id="q11a"> <?php echo $test[10][3]?></label>
                            <label><input type="radio" name="11" value="b" id="q11b"> <?php echo $test[10][4]?></label>
                            <label><input type="radio" name="11" value="c" id="q11c"> <?php echo $test[10][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[11][2]?></h3>
                            <label><input type="radio" name="12" value="a" id="q12a"> <?php echo $test[11][3]?></label>
                            <label><input type="radio" name="12" value="b" id="q12b"> <?php echo $test[11][4]?></label>
                            <label><input type="radio" name="12" value="c" id="q12c"> <?php echo $test[11][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[12][2]?></h3>
                            <label><input type="radio" name="13" value="a" id="q13a"> <?php echo $test[12][3]?></label>
                            <label><input type="radio" name="13" value="b" id="q13b"> <?php echo $test[12][4]?></label>
                            <label><input type="radio" name="13" value="c" id="q13c"> <?php echo $test[12][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[13][2]?></h3>
                            <label><input type="radio" name="14" value="a" id="q14a"> <?php echo $test[13][3]?></label>
                            <label><input type="radio" name="14" value="b" id="q14b"> <?php echo $test[13][4]?></label>
                            <label><input type="radio" name="14" value="c" id="q14c"> <?php echo $test[13][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[14][2]?></h3>
                            <label><input type="radio" name="15" value="a" id="q15a"> <?php echo $test[14][3]?></label>
                            <label><input type="radio" name="15" value="b" id="q15b"> <?php echo $test[14][4]?></label>
                            <label><input type="radio" name="15" value="c" id="q15c"> <?php echo $test[14][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[15][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[15][3]; ?></a></li>
                                <li><a>b) <?php echo $test[15][4]; ?></a></li>
                                <li><a>c) <?php echo $test[15][5]; ?></a></li>
                                <li><a>d) <?php echo $test[15][6]; ?></a></li>
                                <li><a>e) <?php echo $test[15][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="16" id="q16" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[16][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[16][3]; ?></a></li>
                                <li><a>b) <?php echo $test[16][4]; ?></a></li>
                                <li><a>c) <?php echo $test[16][5]; ?></a></li>
                                <li><a>d) <?php echo $test[16][6]; ?></a></li>
                                <li><a>e) <?php echo $test[16][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="17" id="q17" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[17][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[17][3]; ?></a></li>
                                <li><a>b) <?php echo $test[17][4]; ?></a></li>
                                <li><a>c) <?php echo $test[17][5]; ?></a></li>
                                <li><a>d) <?php echo $test[17][6]; ?></a></li>
                                <li><a>e) <?php echo $test[17][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="18" id="q18" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[18][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="19" id="q19" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[19][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="20" id="q20" placeholder="Введите ответ">
                            </label>
                        </div>
                        <button type="submit" id="submit">Отправить результаты</button>
                        <div id="resultDisplay"></div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <script src="js/quiz.js"></script>
</body>
</html>
