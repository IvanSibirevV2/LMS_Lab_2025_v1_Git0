<?php
session_start();
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');

$part17 = mysqli_query($connect, "SELECT * FROM `7lecturepart1`");
$part17 = mysqli_fetch_all($part17);

$part27 = mysqli_query($connect, "SELECT * FROM `7lecturepart2`");
$part27 = mysqli_fetch_all($part27);

$part37 = mysqli_query($connect, "SELECT * FROM `7lecturepart3`");
$part37 = mysqli_fetch_all($part37);

$part47 = mysqli_query($connect, "SELECT * FROM `7lecturepart4`");
$part47 = mysqli_fetch_all($part47);

$part18 = mysqli_query($connect, "SELECT * FROM `8lecturepart1`");
$part18 = mysqli_fetch_all($part18);

$part28 = mysqli_query($connect, "SELECT * FROM `8lecturepart2`");
$part28 = mysqli_fetch_all($part28);

$part38 = mysqli_query($connect, "SELECT * FROM `8lecturepart3`");
$part38 = mysqli_fetch_all($part38);

$part48 = mysqli_query($connect, "SELECT * FROM `8lecturepart4`");
$part48 = mysqli_fetch_all($part48);

$part19 = mysqli_query($connect, "SELECT * FROM `9lecturepart1`");
$part19 = mysqli_fetch_all($part19);

$part29 = mysqli_query($connect, "SELECT * FROM `9lecturepart2`");
$part29 = mysqli_fetch_all($part29);

$part39 = mysqli_query($connect, "SELECT * FROM `9lecturepart3`");
$part39 = mysqli_fetch_all($part39);

$part49 = mysqli_query($connect, "SELECT * FROM `9lecturepart4`");
$part49 = mysqli_fetch_all($part49);

$part110 = mysqli_query($connect, "SELECT * FROM `10lecturepart1`");
$part110 = mysqli_fetch_all($part110);

$part210 = mysqli_query($connect, "SELECT * FROM `10lecturepart2`");
$part210 = mysqli_fetch_all($part210);

$part310 = mysqli_query($connect, "SELECT * FROM `10lecturepart3`");
$part310 = mysqli_fetch_all($part310);

$part410 = mysqli_query($connect, "SELECT * FROM `10lecturepart4`");
$part410 = mysqli_fetch_all($part410);

$part111 = mysqli_query($connect, "SELECT * FROM `11lecturepart1`");
$part111 = mysqli_fetch_all($part111);

$part211 = mysqli_query($connect, "SELECT * FROM `11lecturepart2`");
$part211 = mysqli_fetch_all($part211);

$part311 = mysqli_query($connect, "SELECT * FROM `11lecturepart3`");
$part311 = mysqli_fetch_all($part311);

$part411 = mysqli_query($connect, "SELECT * FROM `11lecturepart4`");
$part411 = mysqli_fetch_all($part411);

$lecturetext = mysqli_query($connect, "SELECT * FROM `lecturesall`");
$lecturetext = mysqli_fetch_all($lecturetext);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лекционные материалы | InterestAlg</title>
    <link rel="stylesheet" href="css/allclasses.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <style>
        .chapters {
            display: none;
        }

        .subtopics {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <a href="math.php" id="logo">InterestAlg</a>
            <h2>Навигация</h2>
            <ul id="navigation">
                <li class="class">
                    <a href="#">Класс 7</a>
                    <ul class="chapters">
                        <li class="chapter"><a href="#"><?php echo $part17[0][2]?></a>
                            <ul class="subtopics">
                                <li><a href="#class7_chapter1_topic1"><?php echo $part17[0][3]?></a></li>
                                <li><a href="#class7_chapter1_topic2"><?php echo $part17[0][4]?></a></li>
                                <li><a href="#class7_chapter1_topic3"><?php echo $part17[0][5]?></a></li>
                                <li><a href="#class7_chapter1_topic4"><?php echo $part17[0][6]?></a></li>
                                <li><a href="#class7_chapter1_topic5"><?php echo $part17[0][7]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part27[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class7_chapter2_topic1"><?php echo $part27[0][2]?></a></li>
                                <li><a href="#class7_chapter2_topic2"><?php echo $part27[0][3]?></a></li>
                                <li><a href="#class7_chapter2_topic3"><?php echo $part27[0][4]?></a></li>
                                <li><a href="#class7_chapter2_topic4"><?php echo $part27[0][5]?></a></li>
                                <li><a href="#class7_chapter2_topic5"><?php echo $part27[0][6]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part37[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class7_chapter3_topic1"><?php echo $part37[0][2]?></a></li>
                                <li><a href="#class7_chapter3_topic2"><?php echo $part37[0][3]?></a></li>
                                <li><a href="#class7_chapter3_topic3"><?php echo $part37[0][4]?></a></li>
                                <li><a href="#class7_chapter3_topic4"><?php echo $part37[0][5]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part47[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class7_chapter4_topic1"><?php echo $part47[0][2]?></a></li>
                                <li><a href="#class7_chapter4_topic2"><?php echo $part47[0][3]?></a></li>
                                <li><a href="#class7_chapter4_topic3"><?php echo $part47[0][4]?></a></li>
                                <li><a href="#class7_chapter4_topic4"><?php echo $part47[0][5]?></a></li>
                                <li><a href="#class7_chapter4_topic5"><?php echo $part47[0][6]?></a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="class">
                    <a href="#">Класс 8</a>
                    <ul class="chapters">
                        <li class="chapter"><a href="#"><?php echo $part18[0][2]?></a>
                            <ul class="subtopics">
                                <li><a href="#class8_chapter1_topic1"><?php echo $part18[0][3]?></a></li>
                                <li><a href="#class8_chapter1_topic2"><?php echo $part18[0][4]?></a></li>
                                <li><a href="#class8_chapter1_topic3"><?php echo $part18[0][5]?></a></li>
                                <li><a href="#class8_chapter1_topic4"><?php echo $part18[0][6]?></a></li>
                                <li><a href="#class8_chapter1_topic5"><?php echo $part18[0][7]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part28[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class8_chapter2_topic1"><?php echo $part28[0][2]?></a></li>
                                <li><a href="#class8_chapter2_topic2"><?php echo $part28[0][3]?></a></li>
                                <li><a href="#class8_chapter2_topic3"><?php echo $part28[0][4]?></a></li>
                                <li><a href="#class8_chapter2_topic4"><?php echo $part28[0][5]?></a></li>
                                <li><a href="#class8_chapter2_topic5"><?php echo $part28[0][6]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part38[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class8_chapter3_topic1"><?php echo $part38[0][2]?></a></li>
                                <li><a href="#class8_chapter3_topic2"><?php echo $part38[0][3]?></a></li>
                                <li><a href="#class8_chapter3_topic3"><?php echo $part38[0][4]?></a></li>
                                <li><a href="#class8_chapter3_topic4"><?php echo $part38[0][5]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part48[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class8_chapter4_topic1"><?php echo $part48[0][2]?></a></li>
                                <li><a href="#class8_chapter4_topic2"><?php echo $part48[0][3]?></a></li>
                                <li><a href="#class8_chapter4_topic3"><?php echo $part48[0][4]?></a></li>
                                <li><a href="#class8_chapter4_topic4"><?php echo $part48[0][5]?></a></li>
                                <li><a href="#class8_chapter4_topic5"><?php echo $part48[0][6]?></a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="class">
                    <a href="#">Класс 9</a>
                    <ul class="chapters">
                        <li class="chapter"><a href="#"><?php echo $part19[0][2]?></a>
                            <ul class="subtopics">
                                <li><a href="#class9_chapter1_topic1"><?php echo $part19[0][3]?></a></li>
                                <li><a href="#class9_chapter1_topic2"><?php echo $part19[0][4]?></a></li>
                                <li><a href="#class9_chapter1_topic3"><?php echo $part19[0][5]?></a></li>
                                <li><a href="#class9_chapter1_topic4"><?php echo $part19[0][6]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part29[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class9_chapter2_topic1"><?php echo $part29[0][2]?></a></li>
                                <li><a href="#class9_chapter2_topic2"><?php echo $part29[0][3]?></a></li>
                                <li><a href="#class9_chapter2_topic3"><?php echo $part29[0][4]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part39[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class9_chapter3_topic1"><?php echo $part39[0][2]?></a></li>
                                <li><a href="#class9_chapter3_topic2"><?php echo $part39[0][3]?></a></li>
                                <li><a href="#class9_chapter3_topic3"><?php echo $part39[0][4]?></a></li>
                                <li><a href="#class9_chapter3_topic4"><?php echo $part39[0][5]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part49[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class9_chapter4_topic1"><?php echo $part49[0][2]?></a></li>
                                <li><a href="#class9_chapter4_topic2"><?php echo $part49[0][3]?></a></li>
                                <li><a href="#class9_chapter4_topic3"><?php echo $part49[0][4]?></a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="class">
                    <a href="#">Класс 10</a>
                    <ul class="chapters">
                        <li class="chapter"><a href="#"><?php echo $part110[0][2]?></a>
                            <ul class="subtopics">
                                <li><a href="#class10_chapter1_topic1"><?php echo $part110[0][3]?></a></li>
                                <li><a href="#class10_chapter1_topic2"><?php echo $part110[0][4]?></a></li>
                                <li><a href="#class10_chapter1_topic3"><?php echo $part110[0][5]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part210[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class10_chapter2_topic1"><?php echo $part210[0][2]?></a></li>
                                <li><a href="#class10_chapter2_topic2"><?php echo $part210[0][3]?></a></li>
                                <li><a href="#class10_chapter2_topic3"><?php echo $part210[0][4]?></a></li>
                                <li><a href="#class10_chapter2_topic4"><?php echo $part210[0][5]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part310[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class10_chapter3_topic1"><?php echo $part310[0][2]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part410[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class10_chapter4_topic1"><?php echo $part410[0][2]?></a></li>
                                <li><a href="#class10_chapter4_topic2"><?php echo $part410[0][3]?></a></li>
                                <li><a href="#class10_chapter4_topic3"><?php echo $part410[0][4]?></a></li>
                                <li><a href="#class10_chapter4_topic4"><?php echo $part410[0][5]?></a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="class">
                    <a href="#">Класс 11</a>
                    <ul class="chapters">
                        <li class="chapter"><a href="#"><?php echo $part111[0][2]?></a>
                            <ul class="subtopics">
                                <li><a href="#class11_chapter1_topic1"><?php echo $part111[0][3]?></a></li>
                                <li><a href="#class11_chapter1_topic2"><?php echo $part111[0][4]?></a></li>
                                <li><a href="#class11_chapter1_topic3"><?php echo $part111[0][5]?></a></li>
                                <li><a href="#class11_chapter1_topic4"><?php echo $part111[0][6]?></a></li>
                                <li><a href="#class11_chapter1_topic5"><?php echo $part111[0][7]?></a></li>
                                <li><a href="#class11_chapter1_topic6"><?php echo $part111[0][8]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part211[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class11_chapter2_topic1"><?php echo $part211[0][2]?></a></li>
                                <li><a href="#class11_chapter2_topic2"><?php echo $part211[0][3]?></a></li>
                                <li><a href="#class11_chapter2_topic3"><?php echo $part211[0][4]?></a></li>
                                <li><a href="#class11_chapter2_topic4"><?php echo $part211[0][5]?></a></li>
                                <li><a href="#class11_chapter2_topic5"><?php echo $part211[0][6]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part311[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class11_chapter3_topic1"><?php echo $part311[0][2]?></a></li>
                                <li><a href="#class11_chapter3_topic2"><?php echo $part311[0][3]?></a></li>
                                <li><a href="#class11_chapter3_topic3"><?php echo $part311[0][4]?></a></li>
                                <li><a href="#class11_chapter3_topic4"><?php echo $part311[0][5]?></a></li>
                            </ul>
                        </li>
                        <li class="chapter"><a href="#"><?php echo $part411[0][1]?></a>
                            <ul class="subtopics">
                                <li><a href="#class11_chapter4_topic1"><?php echo $part411[0][2]?></a></li>
                                <li><a href="#class11_chapter4_topic2"><?php echo $part411[0][3]?></a></li>
                                <li><a href="#class11_chapter4_topic3"><?php echo $part411[0][4]?></a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <div class="content">
            <h1 id="class7">Класс 7</h1>
            <ul>
                <li id="class7_chapter1_topic1">
                    <h1><?php echo $part17[0][2]?></h1>
                    <h2><?php echo $part17[0][3]?></h2>
                    <?php echo $lecturetext[0][1]?>
                </li>
                <li id="class7_chapter1_topic2">
                    <h2><?php echo $part17[0][4]?></h2>
                    <?php echo $lecturetext[0][2]?>
                </li>
                <li id="class7_chapter1_topic3">
                    <h2><?php echo $part17[0][5]?></h2>
                    <?php echo $lecturetext[0][3]?>
                </li>
                <li id="class7_chapter1_topic4">
                    <h2><?php echo $part17[0][6]?></h2>
                    <?php echo $lecturetext[0][4]?>
                </li>                
                <li id="class7_chapter1_topic5">
                    <h2><?php echo $part17[0][7]?></h2>
                    <?php echo $lecturetext[0][5]?>
                </li>

                <li id="class7_chapter2_topic1">
                    <h1><?php echo $part27[0][1]?></h1>
                    <h2><?php echo $part27[0][2]?></h2>
                    <?php echo $lecturetext[0][7]?>
                </li>

                <li id="class7_chapter2_topic2">
                    <h2><?php echo $part27[0][3]?></h2>
                    <?php echo $lecturetext[0][8]?>
                </li>           
                <li id="class7_chapter2_topic3">
                    <h2><?php echo $part27[0][4]?></h2>
                    <?php echo $lecturetext[0][9]?>
                </li>              
                <li id="class7_chapter2_topic4">
                    <h2><?php echo $part27[0][5]?></h2>
                    <?php echo $lecturetext[0][10]?>
                </li>
                <li id="class7_chapter2_topic5">
                    <h2><?php echo $part27[0][6]?></h2>
                    <?php echo $lecturetext[0][11]?>
                </li>

                <li id="class7_chapter3_topic1">
                    <h1><?php echo $part37[0][1]?></h1>
                    <h2><?php echo $part37[0][2]?></h2>
                    <?php echo $lecturetext[0][12]?>
                </li>
                <li id="class7_chapter3_topic2">
                    <h2><?php echo $part37[0][3]?></h2>
                    <?php echo $lecturetext[0][13]?>
                </li>
                <li id="class7_chapter3_topic3">
                    <h2><?php echo $part37[0][4]?></h2>
                    <?php echo $lecturetext[0][14]?>
                </li>
                <li id="class7_chapter3_topic4">
                    <h2><?php echo $part37[0][5]?></h2>
                    <?php echo $lecturetext[0][15]?>
                </li>

                <li id="class7_chapter4_topic1">
                    <h1><?php echo $part47[0][1]?></h1>
                    <h2><?php echo $part47[0][2]?></h2>
                    <?php echo $lecturetext[0][16]?>
                </li>
                <li id="class7_chapter4_topic2">
                    <h2><?php echo $part47[0][3]?></h2>
                    <?php echo $lecturetext[0][17]?>
                </li>
                <li id="class7_chapter4_topic3">
                    <h2><?php echo $part47[0][4]?></h2>
                    <?php echo $lecturetext[0][18]?>
                </li>
                <li id="class7_chapter4_topic4">
                    <h2><?php echo $part47[0][5]?></h2>
                    <?php echo $lecturetext[0][19]?>
                </li>
                <li id="class7_chapter4_topic5">
                    <h2><?php echo $part47[0][6]?></h2>
                    <?php echo $lecturetext[0][20]?>
                </li>
            </ul>
            <h1 id="class8">Класс 8</h1>
            <ul>
                <li id="class8_chapter1_topic1">
                    <h1><?php echo $part18[0][2]?></h1>
                    <h2><?php echo $part18[0][3]?></h2>
                    <?php echo $lecturetext[1][1]?>
                </li>
                <li id="class8_chapter1_topic2">
                    <h2><?php echo $part18[0][4]?></h2>
                    <?php echo $lecturetext[1][2]?>
                </li>
                <li id="class8_chapter1_topic3">
                    <h2><?php echo $part18[0][5]?></h2>
                    <?php echo $lecturetext[1][3]?>
                </li>
                <li id="class8_chapter1_topic4">
                    <h2><?php echo $part18[0][6]?></h2>
                    <?php echo $lecturetext[1][4]?>
                </li>
                <li id="class8_chapter1_topic5">
                    <h2><?php echo $part18[0][7]?></h2>
                    <?php echo $lecturetext[1][5]?>
                </li>

                <li id="class8_chapter2_topic1">
                    <h1><?php echo $part28[0][1]?></h1>
                    <h2><?php echo $part28[0][2]?></h2>
                    <?php echo $lecturetext[1][7]?>
                </li>
                <li id="class8_chapter2_topic2">
                    <h2><?php echo $part28[0][3]?></h2>
                    <?php echo $lecturetext[1][8]?>
                </li>
                <li id="class8_chapter2_topic3">
                    <h2><?php echo $part28[0][4]?></h2>
                    <?php echo $lecturetext[1][9]?>
                </li>
                <li id="class8_chapter2_topic4">
                    <h2><?php echo $part28[0][5]?></h2>
                    <?php echo $lecturetext[1][10]?>
                </li>
                <li id="class8_chapter2_topic5">
                    <h2><?php echo $part28[0][6]?></h2>
                    <?php echo $lecturetext[1][11]?>
                </li>

                <li id="class8_chapter3_topic1">
                    <h1><?php echo $part38[0][1]?></h1>
                    <h2><?php echo $part38[0][2]?></h2>
                    <?php echo $lecturetext[1][12]?>
                </li>
                <li id="class8_chapter3_topic2">
                    <h2><?php echo $part38[0][3]?></h2>
                    <?php echo $lecturetext[1][13]?>
                </li>
                <li id="class8_chapter3_topic3">
                    <h2><?php echo $part38[0][4]?></h2>
                    <?php echo $lecturetext[1][14]?>
                </li>
                <li id="class8_chapter3_topic4">
                    <h2><?php echo $part38[0][5]?></h2>
                    <?php echo $lecturetext[1][15]?>
                </li>

                <li id="class8_chapter4_topic1">
                    <h1><?php echo $part48[0][1]?></h1>
                    <h2><?php echo $part48[0][2]?></h2>
                    <?php echo $lecturetext[1][16]?>
                </li>
                <li id="class8_chapter4_topic2">
                    <h2><?php echo $part48[0][3]?></h2>
                    <?php echo $lecturetext[1][17]?>
                </li>
                <li id="class8_chapter4_topic3">
                    <h2><?php echo $part48[0][4]?></h2>
                    <?php echo $lecturetext[1][18]?>
                </li>
                <li id="class8_chapter4_topic4">
                    <h2><?php echo $part48[0][5]?></h2>
                    <?php echo $lecturetext[1][19]?>
                </li>
                <li id="class8_chapter4_topic5">
                    <h2><?php echo $part48[0][6]?></h2>
                    <?php echo $lecturetext[1][20]?>
                </li>
            </ul>

            <h1 id="class9">Класс 9</h1>
            <ul>
                <li id="class9_chapter1_topic1">
                    <h1><?php echo $part19[0][2]?></h1>
                    <h2><?php echo $part19[0][3]?></h2>
                    <?php echo $lecturetext[2][1]?>
                </li>
                <li id="class9_chapter1_topic2">
                    <h2><?php echo $part19[0][4]?></h2>
                    <?php echo $lecturetext[2][2]?>
                </li>
                <li id="class9_chapter1_topic3">
                    <h2><?php echo $part19[0][5]?></h2>
                    <?php echo $lecturetext[2][3]?>
                </li>
                <li id="class9_chapter1_topic4">
                    <h2><?php echo $part19[0][6]?></h2>
                    <?php echo $lecturetext[2][4]?>
                </li>

                <li id="class9_chapter2_topic1">
                    <h1><?php echo $part29[0][1]?></h1>
                    <h2><?php echo $part29[0][2]?></h2>
                    <?php echo $lecturetext[2][7]?>
                </li>
                <li id="class9_chapter2_topic2">
                    <h2><?php echo $part29[0][3]?></h2>
                    <?php echo $lecturetext[2][8]?>
                </li>
                <li id="class9_chapter2_topic3">
                    <h2><?php echo $part29[0][4]?></h2>
                    <?php echo $lecturetext[2][9]?>
                </li>

                <li id="class9_chapter3_topic1">
                    <h1><?php echo $part39[0][1]?></h1>
                    <h2><?php echo $part39[0][2]?></h2>
                    <?php echo $lecturetext[2][12]?>
                </li>
                <li id="class9_chapter3_topic2">
                    <h2><?php echo $part39[0][3]?></h2>
                    <?php echo $lecturetext[2][13]?>
                </li>
                <li id="class9_chapter3_topic3">
                    <h2><?php echo $part39[0][4]?></h2>
                    <?php echo $lecturetext[2][14]?>
                </li>
                <li id="class9_chapter3_topic4">
                <?php echo $lecturetext[2][15]?>
                </li>

                <li id="class9_chapter4_topic1">
                    <h1><?php echo $part49[0][1]?></h1>
                    <h2><?php echo $part49[0][2]?></h2>
                    <?php echo $lecturetext[2][16]?>
                </li>
                <li id="class9_chapter4_topic2">
                    <h2><?php echo $part49[0][3]?></h2>
                    <?php echo $lecturetext[2][17]?>
                </li>
                <li id="class9_chapter4_topic3">
                <?php echo $lecturetext[2][18]?>
                </li>
            </ul>

            <h1 id="class10">Класс 10</h1>
            <ul>
                <li id="class10_chapter1_topic1">
                    <h1><?php echo $part110[0][2]?></h1>
                    <h2><?php echo $part110[0][3]?></h2>
                    <?php echo $lecturetext[3][1]?>
                </li>
                <li id="class10_chapter1_topic2">
                    <h2><?php echo $part110[0][4]?></h2>
                    <?php echo $lecturetext[3][2]?>
                </li>
                <li id="class10_chapter1_topic3">
                    <h2><?php echo $part110[0][5]?></h2>
                    <?php echo $lecturetext[3][3]?>
                </li>

                <li id="class10_chapter2_topic1">
                    <h1><?php echo $part210[0][1]?></h1>
                    <h2><?php echo $part210[0][2]?></h2>
                    <?php echo $lecturetext[3][7]?>
                </li>
                <li id="class10_chapter2_topic2">
                    <h2><?php echo $part210[0][3]?></h2>
                    <?php echo $lecturetext[3][8]?>
                </li>
                <li id="class10_chapter2_topic3">
                <?php echo $lecturetext[3][9]?>
                </li>
                <li id="class10_chapter2_topic4">
                    <h2><?php echo $part210[0][5]?></h2>
                    <?php echo $lecturetext[3][10]?>
                </li>

                <li id="class10_chapter3_topic1">
                    <h1><?php echo $part310[0][1]?></h1>
                    <h2><?php echo $part310[0][2]?></h2>
                    <?php echo $lecturetext[3][12]?>
                </li>
                <li id="class10_chapter4_topic1">
                    <h1><?php echo $part410[0][1]?></h1>
                    <h2><?php echo $part410[0][2]?></h2>
                    <?php echo $lecturetext[3][16]?>
                </li>
                <li id="class10_chapter4_topic2">
                    <h2><?php echo $part410[0][3]?></h2>
                    <?php echo $lecturetext[3][17]?>
                </li>
                <li id="class10_chapter4_topic3">
                    <h2><?php echo $part410[0][4]?></h2>
                    <?php echo $lecturetext[3][18]?>
                </li>
                <li id="class10_chapter4_topic4">
                    <h2><?php echo $part410[0][5]?></h2>
                    <?php echo $lecturetext[3][19]?>
                </li>
            </ul>

            <h1 id="class11">Класс 11</h1>
            <ul>
                <li id="class11_chapter1_topic1">
                    <h1><?php echo $part111[0][2]?></h1>
                    <h2><?php echo $part111[0][3]?></h2>
                    <?php echo $lecturetext[4][1]?>
                </li>
                <li id="class11_chapter1_topic2">
                    <h2><?php echo $part111[0][4]?></h2>
                    <?php echo $lecturetext[4][2]?>
                </li>
                <li id="class11_chapter1_topic3">
                    <h2><?php echo $part111[0][5]?></h2>
                    <?php echo $lecturetext[4][3]?>
                </li>
                <li id="class11_chapter1_topic4">
                    <h2><?php echo $part111[0][6]?></h2>
                    <?php echo $lecturetext[4][4]?>
                </li>
                <li id="class11_chapter1_topic5">
                    <h2><?php echo $part111[0][7]?></h2>
                    <?php echo $lecturetext[4][5]?>
                </li>
                <li id="class11_chapter1_topic6">
                    <h2><?php echo $part111[0][8]?></h2>
                    <?php echo $lecturetext[4][6]?>
                </li>

                <li id="class11_chapter2_topic1">
                    <h1><?php echo $part211[0][1]?></h1>
                    <h2><?php echo $part211[0][2]?></h2>
                    <?php echo $lecturetext[4][7]?>
                </li>
                <li id="class11_chapter2_topic2">
                    <h2><?php echo $part211[0][3]?></h2>
                    <?php echo $lecturetext[4][8]?>
                </li>
                <li id="class11_chapter2_topic3">
                    <h2><?php echo $part211[0][4]?></h2>
                    <?php echo $lecturetext[4][9]?>
                </li>
                <li id="class11_chapter2_topic4">
                    <h2><?php echo $part211[0][5]?></h2>
                    <?php echo $lecturetext[4][10]?>
                </li>
                <li id="class11_chapter2_topic5">
                    <h2><?php echo $part211[0][6]?></h2>
                    <?php echo $lecturetext[4][11]?>

                <li id="class11_chapter3_topic1">
                    <h1><?php echo $part311[0][1]?></h1>
                    <h2><?php echo $part311[0][2]?></h2>
                    <?php echo $lecturetext[4][12]?>
                </li>
                <li id="class11_chapter3_topic2">
                    <h2><?php echo $part311[0][3]?></h2>
                    <?php echo $lecturetext[4][13]?>
                </li>
                <li id="class11_chapter3_topic3">
                    <h2><?php echo $part311[0][4]?></h2>
                    <?php echo $lecturetext[4][14]?>
                </li>
                <li id="class11_chapter3_topic4">
                    <h2><?php echo $part311[0][5]?></h2>
                    <?php echo $lecturetext[4][15]?>
                </li>

                <li id="class11_chapter4_topic1">
                    <h1><?php echo $part411[0][1]?></h1>
                    <h2><?php echo $part411[0][2]?></h2>
                    <?php echo $lecturetext[4][16]?>
                </li>
                <li id="class11_chapter4_topic2">
                    <h2><?php echo $part411[0][3]?></h2>
                    <?php echo $lecturetext[4][17]?>
                </li>
                <li id="class11_chapter4_topic3">
                    <h2><?php echo $part411[0][4]?></h2>
                    <?php echo $lecturetext[4][18]?>
                </li>
            </ul>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var classes = document.querySelectorAll('.class');
            classes.forEach(function (classItem) {
                classItem.addEventListener('click', function (event) {
                    event.preventDefault(); // Предотвращаем переход по ссылке
                    var chapters = this.querySelector('.chapters');
                    chapters.style.display = chapters.style.display === 'block' ? 'none' : 'block';
                    event.stopPropagation(); // Предотвращаем распространение события, чтобы навигация не сворачивалась
                });
            });
        
            var chapters = document.querySelectorAll('.chapter > a');
            chapters.forEach(function (chapter) {
                chapter.addEventListener('click', function (event) {
                    event.preventDefault(); // Предотвращаем переход по ссылке
                    var subtopics = this.parentNode.querySelector('.subtopics');
                    subtopics.style.display = subtopics.style.display === 'block' ? 'none' : 'block';
                    event.stopPropagation(); // Предотвращаем распространение события, чтобы навигация не сворачивалась
                });
            });
        
            var topics = document.querySelectorAll('.subtopics > li > a');
            topics.forEach(function (topic) {
                topic.addEventListener('click', function (event) {
                    event.preventDefault(); // Предотвращаем переход по ссылке
                    var targetId = this.getAttribute('href').substring(1); // Получаем id целевого элемента
                    var targetElement = document.getElementById(targetId); // Находим целевой элемент по id
                    if (targetElement) {
                        targetElement.scrollIntoView({ behavior: 'smooth' }); // Прокручиваем к целевому элементу
                    }
                });
            });
        });
    </script>
</body>
</html>