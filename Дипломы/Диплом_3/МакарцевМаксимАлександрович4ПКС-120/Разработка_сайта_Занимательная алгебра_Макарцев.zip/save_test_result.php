<?php
session_start();

$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['testId']) && isset($data['score']) && isset($data['grade']) && isset($data['userId'])) {
    $testId = $data['testId'];
    $userId = $data['userId'];
    $score = $data['score'];
    $grade = $data['grade'];

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");

        $stmt = $pdo->prepare('INSERT INTO test_result (user_id, test_id, score, grade) VALUES (?, ?, ?, ?)');
        $stmt->execute([$userId, $testId, $score, $grade]);

        echo json_encode(['message' => 'Результаты успешно сохранены.']);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка при сохранении результатов: ' . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Отсутствуют необходимые данные']);
}
?>
