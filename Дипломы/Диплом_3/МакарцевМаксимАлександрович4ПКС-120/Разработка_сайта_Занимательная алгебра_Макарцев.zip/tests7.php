<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "<script>
        if (confirm('Вы должны зарегистрироваться или войти, чтобы пройти тест. Нажмите ОК для входа или Отмена для возвращения на главную страницу.')) {
            window.location.href = 'authorization.html';
        } else {
            window.location.href = 'math.php';
        }
    </script>";
    exit();
}

$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}

mysqli_set_charset($connect, 'utf8');

$header = mysqli_query($connect, "SELECT * FROM `adm_headerlt`");
$header = mysqli_fetch_all($header);

$test = mysqli_query($connect, "SELECT * FROM `test_answers`");
$test = mysqli_fetch_all($test);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование 7 класс | InterestAlg</title>
    <link rel="stylesheet" href="css/tests.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <style>
        .question ul {
            list-style-type: none;
            padding-left: 0;
        }
    </style>
</head>
<body>
    <header>
        <div id="header">
            <div id="logo">
                <span>InterestAlg</span>
            </div>
            <div id="back">
                <a href="math.php#materials" title="Лекционный материал"><?php echo $header[0][1]?></a>
                <a href="math.php#test" title="Тестирование"><?php echo $header[0][2]?></a>
                <a href="math.php"><?php echo $header[0][3]?></a>
            </div>
        </div>
    </header> 
    <main>
        <div class="fullpage">
            <div class="heading">
                <h2>Тестирование для 7 класса</h2>
            </div>
            <div id="test">
                <div class="container1">
                    <form class="testForm" id="testForm" action="save_test_result.php" method="POST" data-test-id="1">
                        <input type="hidden" name="testId" id="testId" value="1">
                        <div class="question">
                            <h3><?php echo $test[0][2]?></h3>
                            <label><input type="radio" name="1" value="a" id="q1a"> <?php echo $test[0][3]?></label>
                            <label><input type="radio" name="1" value="b" id="q1b"> <?php echo $test[0][4]?></label>
                            <label><input type="radio" name="1" value="c" id="q1c"> <?php echo $test[0][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[1][2]?></h3>
                            <label><input type="radio" name="2" value="a" id="q2a"> <?php echo $test[1][3]?></label>
                            <label><input type="radio" name="2" value="b" id="q2b"> <?php echo $test[1][4]?></label>
                            <label><input type="radio" name="2" value="c" id="q2c"> <?php echo $test[1][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[2][2]?></h3>
                            <label><input type="radio" name="3" value="a" id="q3a"> <?php echo $test[2][3]?></label>
                            <label><input type="radio" name="3" value="b" id="q3b"> <?php echo $test[2][4]?></label>
                            <label><input type="radio" name="3" value="c" id="q3c"> <?php echo $test[2][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[3][2]?></h3>
                            <label><input type="radio" name="4" value="a" id="q4a"> <?php echo $test[3][3]?></label>
                            <label><input type="radio" name="4" value="b" id="q4b"> <?php echo $test[3][4]?></label>
                            <label><input type="radio" name="4" value="c" id="q4c"> <?php echo $test[3][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[4][2]?></h3>
                            <label><input type="radio" name="5" value="a" id="q5a"> <?php echo $test[4][3]?></label>
                            <label><input type="radio" name="5" value="b" id="q5b"> <?php echo $test[4][4]?></label>
                            <label><input type="radio" name="5" value="c" id="q5c"> <?php echo $test[4][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[5][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[5][3]; ?></a></li>
                                <li><a>b) <?php echo $test[5][4]; ?></a></li>
                                <li><a>c) <?php echo $test[5][5]; ?></a></li>
                                <li><a>d) <?php echo $test[5][6]; ?></a></li>
                                <li><a>e) <?php echo $test[5][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="6" id="q6" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[6][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[6][3]; ?></a></li>
                                <li><a>b) <?php echo $test[6][4]; ?></a></li>
                                <li><a>c) <?php echo $test[6][5]; ?></a></li>
                                <li><a>d) <?php echo $test[6][6]; ?></a></li>
                                <li><a>e) <?php echo $test[6][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="7" id="q7" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[7][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[7][3]; ?></a></li>
                                <li><a>b) <?php echo $test[7][4]; ?></a></li>
                                <li><a>c) <?php echo $test[7][5]; ?></a></li>
                                <li><a>d) <?php echo $test[7][6]; ?></a></li>
                                <li><a>e) <?php echo $test[7][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="8" id="q8" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[8][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="9" id="q9" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[9][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="10" id="q10" placeholder="Введите ответ">
                            </label>
                        </div>
                        <button type="submit" id="submit">Отправить результаты</button>
                        <div id="resultDisplay"></div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <script src="js/quiz.js"></script>
</body>
</html>
