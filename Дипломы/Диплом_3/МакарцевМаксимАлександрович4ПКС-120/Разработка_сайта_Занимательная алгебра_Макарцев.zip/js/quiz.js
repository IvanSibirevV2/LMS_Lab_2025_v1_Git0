document.addEventListener("DOMContentLoaded", function() {
    // Функция для получения идентификатора текущего пользователя
    function getCurrentUserId() {
        return fetch('get_current_user_id.php', {
            method: 'POST',
            credentials: 'same-origin' // Важно установить параметр credentials в 'same-origin' для передачи куки с идентификатором сессии
        })
        .then(response => response.json())
        .then(data => data.userId)
        .catch(error => {
            console.error('Ошибка при получении ID пользователя:', error);
            return null;
        });
    }

    // Функция для отправки ответов пользователя на сервер и подсчета результатов
    function calculateTestResult(userId, testId, userAnswers) {
        fetch('calculate_test_result.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ userId: userId, testId: testId, userAnswers: userAnswers })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Результат вычислений:', data);
            if (data.error) {
                throw new Error(data.error);
            }
            if (data.grade === undefined || data.score === undefined) {
                throw new Error('Некорректный ответ от сервера');
            }
            document.getElementById('resultDisplay').innerHTML = 'Ваша оценка: ' + data.grade + ', количество правильных ответов: ' + data.score;
        })
        .catch(error => {
            console.error('Ошибка:', error);
        });
    }

    // Функция для извлечения ответов пользователя из формы и вызова calculateTestResult
    function saveUserAnswers(userId) {
        const form = document.getElementById('testForm');
        const formData = new FormData(form);
        const userAnswers = {};
        formData.forEach((value, key) => {
            userAnswers[key] = value;
        });
        const testId = form.getAttribute('data-test-id');
        console.log('Отправка ответов для расчета:', { userId: userId, testId: testId, userAnswers: userAnswers });
        calculateTestResult(userId, testId, userAnswers);
    }

    // Вызов функции для получения идентификатора текущего пользователя при загрузке страницы
    getCurrentUserId().then(userId => {
        if (userId) {
            console.log('Получен ID пользователя:', userId);
            // Вызов функции для отправки ответов пользователя на сервер при отправке формы
            document.getElementById('testForm').addEventListener('submit', function(event) {
                event.preventDefault(); // Отменяем стандартное действие кнопки submit
                saveUserAnswers(userId); // Вызываем функцию для сохранения ответов пользователя на сервере
            });
        } else {
            console.error('ID пользователя не найден.');
        }
    });
});
