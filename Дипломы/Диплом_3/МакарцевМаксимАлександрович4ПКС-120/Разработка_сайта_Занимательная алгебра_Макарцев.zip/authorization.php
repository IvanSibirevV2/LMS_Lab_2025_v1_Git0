<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $host = 'localhost';
        $dbname = 'u2666147_diplommath';
        $username_db = 'u2666147_default';
        $password_db = 'QMqjgV214mm9uHuV';

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("set names utf8");

            $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $user['email'];
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['authenticated'] = true;
                header("Location: math.php");
                exit();
            } else {
                echo "<script>alert('Неправильный логин или пароль.'); window.location = 'authorization.html';</script>";
                exit();
            }
        } catch (PDOException $e) {
            echo "Ошибка: " . $e->getMessage();
            exit();
        }
    } else {
        echo "<script>alert('Пожалуйста, заполните все поля.'); window.location.href = 'authorization.html';</script>";
        exit();
    }
}
?>
