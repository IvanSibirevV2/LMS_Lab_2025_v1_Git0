<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "<script>
        if (confirm('Вы должны зарегистрироваться или войти, чтобы пройти тест. Нажмите ОК для входа или Отмена для возвращения на главную страницу.')) {
            window.location.href = 'authorization.html';
        } else {
            window.location.href = 'math.php';
        }
    </script>";
    exit();
}
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');

$header = mysqli_query($connect, "SELECT * FROM `adm_headerlt`");
$header = mysqli_fetch_all($header);

$test = mysqli_query($connect, "SELECT * FROM `test_answers`");
$test = mysqli_fetch_all($test);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование 9 класс | InterestAlg</title>
    <link rel="stylesheet" href="css/tests.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <style>
        .question ul {
            list-style-type: none;
            padding-left: 0;
        }
    </style>
</head>
<body>
    <header>
        <div id="header">
            <div id="logo" onclick="slowScroll('#test')">
                <span>InterestAlg</span>
            </div>
            <div id="back">
                <a href="math.php#materials" title="Лекционный материал" onclick="slowScroll('#materials')"><?php echo $header[0][1]?></a>
                <a href="math.php#test" title="Тестирование"><?php echo $header[0][2]?></a>
                <a href="math.php"><?php echo $header[0][3]?></a>
            </div>
        </div>
    </header> 
    <main>
        <div class="fullpage">
            <div class="heading">
                <h2>Тестирование для 9 класса</h2>
            </div>
            <div id="test">
                <div class="container1">
                    <form class="testForm" id="testForm" action="save_test_result.php" method="POST" data-test-id="3">
                        <input type="hidden" name="testId" id="testId" value="3">
                        <div class="question">
                            <h3><?php echo $test[20][2]?></h3>
                            <label><input type="radio" name="21" value="a" id="q21a"> <?php echo $test[20][3]?></label>
                            <label><input type="radio" name="21" value="b" id="q21b"> <?php echo $test[20][4]?></label>
                            <label><input type="radio" name="21" value="c" id="q21c"> <?php echo $test[20][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[21][2]?></h3>
                            <label><input type="radio" name="22" value="a" id="q22a"> <?php echo $test[21][3]?></label>
                            <label><input type="radio" name="22" value="b" id="q22b"> <?php echo $test[21][4]?></label>
                            <label><input type="radio" name="22" value="c" id="q22c"> <?php echo $test[21][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[22][2]?></h3>
                            <label><input type="radio" name="23" value="a" id="q23a"> <?php echo $test[22][3]?></label>
                            <label><input type="radio" name="23" value="b" id="q23b"> <?php echo $test[22][4]?></label>
                            <label><input type="radio" name="23" value="c" id="q23c"> <?php echo $test[22][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[23][2]?></h3>
                            <label><input type="radio" name="24" value="a" id="q24a"> <?php echo $test[23][3]?></label>
                            <label><input type="radio" name="24" value="b" id="q24b"> <?php echo $test[23][4]?></label>
                            <label><input type="radio" name="24" value="c" id="q24c"> <?php echo $test[23][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[24][2]?></h3>
                            <label><input type="radio" name="25" value="a" id="q25a"> <?php echo $test[24][3]?></label>
                            <label><input type="radio" name="25" value="b" id="q25b"> <?php echo $test[24][4]?></label>
                            <label><input type="radio" name="25" value="c" id="q25c"> <?php echo $test[24][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[25][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[25][3]; ?></a></li>
                                <li><a>b) <?php echo $test[25][4]; ?></a></li>
                                <li><a>c) <?php echo $test[25][5]; ?></a></li>
                                <li><a>d) <?php echo $test[25][6]; ?></a></li>
                                <li><a>e) <?php echo $test[25][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="26" id="q26" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[26][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[26][3]; ?></a></li>
                                <li><a>b) <?php echo $test[26][4]; ?></a></li>
                                <li><a>c) <?php echo $test[26][5]; ?></a></li>
                                <li><a>d) <?php echo $test[26][6]; ?></a></li>
                                <li><a>e) <?php echo $test[26][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="27" id="q27" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[27][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[27][3]; ?></a></li>
                                <li><a>b) <?php echo $test[27][4]; ?></a></li>
                                <li><a>c) <?php echo $test[27][5]; ?></a></li>
                                <li><a>d) <?php echo $test[27][6]; ?></a></li>
                                <li><a>e) <?php echo $test[27][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="28" id="q28" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[28][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="29" id="q29" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[29][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="30" id="q30" placeholder="Введите ответ">
                            </label>
                        </div>
                        <button type="submit" id="submit">Отправить результаты</button>
                        <div id="resultDisplay"></div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <script src="js/quiz.js"></script>
</body>
</html>
