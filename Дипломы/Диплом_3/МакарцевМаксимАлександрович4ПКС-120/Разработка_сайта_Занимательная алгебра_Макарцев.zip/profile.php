<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: math.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $servername = "localhost";
        $db_username = "u2666147_default";
        $db_password = "QMqjgV214mm9uHuV";
        $dbname = "u2666147_diplommath";

        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        if ($conn->connect_error) {
            die("Ошибка подключения к базе данных: " . $conn->connect_error);
        }
        mysqli_set_charset($conn, 'utf8');

        $sql = $conn->prepare("SELECT id, email FROM users WHERE username = ? AND password = ?");
        $sql->bind_param('ss', $username, $password);
        $sql->execute();
        $result = $sql->get_result();

        if ($result) {
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $row['email'];
                header("Location: profile.php");
                exit();
            } else {
                echo "Неправильное имя пользователя или пароль.";
            }
        } else {
            echo "Ошибка выполнения запроса: " . $conn->error;
        }
    }
}

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    $servername = "localhost";
    $username = "u2666147_default";
    $password = "QMqjgV214mm9uHuV";
    $dbname = "u2666147_diplommath";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Ошибка подключения к базе данных: " . $conn->connect_error);
    }
    mysqli_set_charset($conn, 'utf8');

    $sql = $conn->prepare("
        SELECT t.tests AS test_name, MAX(tr.grade) AS best_grade
        FROM test_result tr
        JOIN test t ON tr.test_id = t.id
        WHERE tr.user_id = ?
        GROUP BY tr.test_id, t.tests
    ");
    $sql->bind_param('i', $userId);
    $sql->execute();
    $result = $sql->get_result();

    $testResults = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $testResults[] = $row;
        }
    }

    $conn->close();
} else {
    header("Location: math.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <title>Личный кабинет | InterestAlg</title>
</head>

<body>
    <header>
        <div class="profileheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a class="onhome" href="math.php">< На главную</a>
            </div>
        </div>
    </header>

    <main>
        <div class="profileinfo">
            <div class="profilesection">
                <div class="profileitems">
                    <span class="profiletitle">Информация о пользователе</span>
                    <p class="profileheading">Имя: <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : "Нет данных"; ?></p>
                    <p class="profileheading">Email: <?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : "Нет данных"; ?></p>
                </div>
            </div>
            <div class="profilesection">
                <div class="profileitems">
                    <span class="profiletitle">Настройки</span>
                    <a class="profileheading" href="changepass.php">Сменить пароль</a>
                    <a class="profileheading" href="#" onclick="confirmLogout();">Выход</a>
                </div>
            </div>
            <div class="profilesection">
                <div class="profileitems">
                    <span class="profiletitle">История пройденных тестов</span>
                    <ul>
                        <?php foreach ($testResults as $testResult): ?>
                            <li><?php echo htmlspecialchars($testResult['test_name']); ?> - <?php echo htmlspecialchars($testResult['best_grade']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; Ixoqu 2024</p>
    </footer>

    <script>
        function confirmLogout() {
            if (confirm("Вы уверены, что хотите выйти из профиля?")) {
                var form = document.createElement('form');
                form.method = 'post';
                form.action = '';
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'logout';
                input.value = '1';
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>

</html>
