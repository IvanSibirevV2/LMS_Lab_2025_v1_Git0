<?php
header('Content-Type: application/json');
session_start();

// Включить отображение ошибок для отладки
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Подключение к базе данных
$servername = "localhost";
$username = "u2666147_default";
$password = "QMqjgV214mm9uHuV";
$dbname = "u2666147_diplommath";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$data) {
        throw new Exception('Некорректные данные');
    }

    $userId = $data['userId'];
    $testId = $data['testId'];
    $userAnswers = $data['userAnswers'];

    if (!isset($userId) || !isset($testId) || !isset($userAnswers)) {
        throw new Exception('Отсутствуют необходимые данные');
    }

    // Получение правильных ответов из таблицы correct_answers
    $stmt = $conn->prepare("SELECT question_id, correct_answer FROM correct_answers WHERE test_id = ?");
    if (!$stmt) {
        throw new Exception('Ошибка в запросе подготовки (correct_answers): ' . $conn->error);
    }

    $stmt->bind_param("i", $testId);
    if (!$stmt->execute()) {
        throw new Exception('Ошибка выполнения запроса (correct_answers): ' . $stmt->error);
    }
    $result = $stmt->get_result();

    $correctAnswers = [];
    while ($row = $result->fetch_assoc()) {
        $correctAnswers[$row['question_id']] = $row['correct_answer'];
    }

    // Отладка: вывод правильных ответов и ответов пользователя
    error_log('Правильные ответы: ' . print_r($correctAnswers, true));
    error_log('Ответы пользователя: ' . print_r($userAnswers, true));

    // Проверка данных правильных ответов и ответов пользователя
    if (empty($correctAnswers)) {
        throw new Exception('Нет правильных ответов для данного теста');
    }

    if (empty($userAnswers)) {
        throw new Exception('Нет ответов пользователя');
    }

    $score = 0;
    foreach ($correctAnswers as $questionId => $correctAnswer) {
        if (isset($userAnswers[$questionId])) {
            // Преобразование запятой в точку в ответах пользователя
            $userAnswer = strtolower(trim(str_replace(',', '.', $userAnswers[$questionId])));
            $correctAnswer = strtolower(trim($correctAnswer));

            // Для вопросов с множественными вариантами проверяем, совпадают ли ответы
            if (is_numeric($correctAnswer) && is_numeric($userAnswer)) {
                if ($userAnswer == $correctAnswer) {
                    $score++;
                }
            } else if (count_chars($userAnswer, 1) == count_chars($correctAnswer, 1)) {
                $score++;
            }

            error_log("Вопрос $questionId: ответ пользователя '$userAnswer', правильный ответ '$correctAnswer'");
        }
    }

    // Отладка: вывод результата подсчета
    error_log('Score: ' . $score);

    $totalQuestions = count($correctAnswers);
    $gradePercentage = ($totalQuestions > 0) ? ($score / $totalQuestions) * 100 : 0;
    $grade = 2;
    if ($gradePercentage >= 80) {
        $grade = 5;
    } elseif ($gradePercentage >= 60) {
        $grade = 4;
    } elseif ($gradePercentage >= 40) {
        $grade = 3;
    }

    // Отладка: вывод количества вопросов и оценки
    error_log('Total Questions: ' . $totalQuestions);
    error_log('Grade Percentage: ' . $gradePercentage);
    error_log('Grade: ' . $grade);

    // Проверка существования таблицы test_result
    $result = $conn->query("SHOW TABLES LIKE 'test_result'");
    if ($result->num_rows == 0) {
        throw new Exception('Таблица test_result не существует');
    }

    // Подготовка запроса для обновления или вставки результата теста
    $stmt = $conn->prepare("INSERT INTO test_result (user_id, test_id, score, grade) VALUES (?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE score = VALUES(score), grade = VALUES(grade)");
    if (!$stmt) {
        throw new Exception('Ошибка в запросе подготовки (test_result): ' . $conn->error);
    }
    $stmt->bind_param("iiid", $userId, $testId, $score, $grade);
    if (!$stmt->execute()) {
        throw new Exception('Ошибка выполнения запроса (test_result): ' . $stmt->error);
    }

    echo json_encode(['score' => $score, 'grade' => $grade]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
} finally {
    $conn->close();
}
?>
