<?php
session_start();
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');

$top = mysqli_query($connect, "SELECT * FROM `adm_top`");
$top = mysqli_fetch_all($top);

$main = mysqli_query($connect, "SELECT * FROM `adm_main`");
$main = mysqli_fetch_all($main);

$materials = mysqli_query($connect, "SELECT * FROM `adm_materials`");
$materials = mysqli_fetch_all($materials);

$tests = mysqli_query($connect, "SELECT * FROM `adm_tests`");
$tests = mysqli_fetch_all($tests);

$header = mysqli_query($connect, "SELECT * FROM `adm_header`");
$header = mysqli_fetch_all($header);

$contact = mysqli_query($connect, "SELECT * FROM `adm_contact`");
$contact = mysqli_fetch_all($contact);

$footer = mysqli_query($connect, "SELECT * FROM `adm_footer`");
$footer = mysqli_fetch_all($footer);

$logged_in = isset($_SESSION['user_id']);

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/math.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <title>Занимательная алгебра | InterestAlg</title>
</head>
<body>
<header>
    <div id="logo" onclick="slowScroll('#top')">
      <span>InterestAlg</span>
    </div>
    <div id="about">
      <a href="#lectures" title="Лекционный материал" onclick="slowScroll('#materials')"><?php echo $header[0][1]?></a>
      <a href="#test" title="Тестирование" onclick="slowScroll('#test')"><?php echo $header[0][2]?></a>
      <a href="#contact" title="Обратная связь" onclick="slowScroll('#contact')"><?php echo $header[0][3]?></a>
      <a href="#faq" title="О нас" onclick="slowScroll('#faq')"><?php echo $header[0][4]?></a>
      <?php if ($logged_in): ?>
        <a href="profile.php" title="Личный кабинет"><?php echo $header[0][7]?></a>
      <?php else: ?>
        <a href="authorization.html" title="Вход"><?php echo $header[0][5]?></a>
        <a href="registration.html" title="Регистрация"><?php echo $header[0][6]?></a>
      <?php endif; ?>
    </div>
</header>

<div id="top">
  <div>
    <h1><?php echo $top[0][1]?></h1>
    <h3><?php echo $top[0][2]?></h3>
  </div>
</div>

<div id="main">
  <div style="width: 100%; height: auto; display: flex;">
    <div class="intro">
      <h2><?php echo $main[0][1]?></h2>
      <a style="font-size: 1em; text-decoration: none; color: #343434; cursor: text;" href="./adminpanel/loginadmin.php"><?php echo $main[0][2]?></a>
    </div>
    <div class="text">
      <span><?php echo $main[0][3]?></span>
    </div>
  </div>
</div>

<div id="materials">
  <h2><?php echo $materials[0][1]?></h2>
  <h4><?php echo $materials[0][2]?></h4>
  <div style="margin-top:10px; max-width: 400px;">
    <div class="classes">
      <a href="lectures7.php"><?php echo $materials[0][3]?></a>
    </div>

    <div class="classes">
      <a href="lectures8.php"><?php echo $materials[0][4]?></a>
    </div>

    <div class="classes">
      <a href="lectures9.php"><?php echo $materials[0][5]?></a>
    </div>

    <div class="classes">
      <a href="lectures10.php"><?php echo $materials[0][6]?></a>
    </div>

    <div class="classes">
      <a href="lectures11.php"><?php echo $materials[0][7]?></a>
    </div>
  </div>
</div>

<div id="test">
  <h2><?php echo $tests[0][1]?></h2>
  <h4><?php echo $tests[0][2]?></h4>
  <div style="margin-top: 10px; max-width: 300px;">
    <div class="tests">
      <a href="tests7.php"><?php echo $tests[0][3]?></a>
    </div>

    <div class="tests">
      <a href="tests8.php"><?php echo $tests[0][4]?></a>
    </div>

    <div class="tests">
      <a href="tests9.php"><?php echo $tests[0][5]?></a>
    </div>

    <div class="tests">
      <a href="tests10.php"><?php echo $tests[0][6]?></a>
    </div>

    <div class="tests">
      <a href="tests11.php"><?php echo $tests[0][7]?></a>
    </div>
  </div>
</div>

<div id="contact">
  <div class="formcontact">
    <h5><?php echo $contact[0][1]?></h5>
    <form id="form_input" method="post" action="submit_form.php">
      <label for="name"><?php echo $contact[0][2]?> <span>*</span></label><br>
      <input type="text" placeholder="Введите имя" name="name" id="name" required><br>
      <label for="email"><?php echo $contact[0][3]?> <span>*</span></label><br>
      <input type="email" placeholder="Введите email" name="email" id="email" required><br>
      <label for="message"><?php echo $contact[0][4]?> <span>*</span></label><br>
      <textarea placeholder="Введите ваше сообщение" name="message" id="message" rows="5" cols="50" required></textarea><br>
      <button type="submit" class="btn"><?php echo $contact[0][5]?></button>
    </form>
  </div>
</div>

<div id="faq">
  <div class="faqblock">
    <div class="faqcolumn">
      <div class="faqitems">
        <span class="title"><?php echo $footer[0][1]?></span><br>
        <span class="heading"><?php echo $footer[0][2]?> <br><a href="mailto:interestalgdiplom@gmail.com"><?php echo $footer[0][3]?></a></span>
      </div>
    </div>
    <div class="faqcolumn">
      <div class="faqitems">
        <span class="title"><a href="" onclick="slowScroll('#materials')"><?php echo $footer[0][4]?></a></span><br>
        <span class="heading"><a href="lectures7.php"><?php echo $footer[0][5]?></a></span><br>
        <span class="heading"><a href="lectures8.php"><?php echo $footer[0][6]?></a></span><br>
        <span class="heading"><a href="lectures9.php"><?php echo $footer[0][7]?></a></span><br>
        <span class="heading"><a href="lectures10.php"><?php echo $footer[0][8]?></a></span><br>
        <span class="heading"><a href="lectures11.php"><?php echo $footer[0][9]?></a></span>
      </div>
    </div>
    <div class="faqcolumn">
      <div class="faqitems">
        <span class="title"><a href="" onclick="slowScroll('#test')"><?php echo $footer[0][10]?></a></span><br>
        <span class="heading">
        <span class="heading"><a href="tests7.php"><?php echo $footer[0][11]?></a></span><br>
        <span class="heading"><a href="tests8.php"><?php echo $footer[0][12]?></a></span><br>
        <span class="heading"><a href="tests9.php"><?php echo $footer[0][13]?></a></span><br>
        <span class="heading"><a href="tests10.php"><?php echo $footer[0][14]?></a></span><br>
        <span class="heading"><a href="tests11.php"><?php echo $footer[0][15]?></a></span>
      </div>
    </div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
  function slowScroll(id) {
    $('html, body').animate({ 
      scrollTop: $(id).offset().top
    }, 500);
  }

  $(document).on("scroll", function () {
    if($(window).scrollTop() === 0)
      $("header").removeClass("fixed");
    else
      $("header").attr("class", "fixed");
  });

  const messageTextarea = document.getElementById('message');

  messageTextarea.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight + 10) + 'px';
  });

  document.addEventListener("DOMContentLoaded", function() {
    var form = document.getElementById("form_input");
    form.addEventListener("submit", function(event) {
        var nameField = document.getElementById("name");
        var name = nameField.value.trim();
        if (!/^[a-zA-Zа-яА-Я]+$/.test(name)) {
            alert("Пожалуйста, введите только буквы в поле \"Имя\".");
            event.preventDefault();
            return;
        }
        var emailField = document.getElementById("email");
        var email = emailField.value.trim();
        if (!isValidEmail(email)) {
            alert("Пожалуйста, введите корректный email.");
            event.preventDefault();
            return;
        }
    });
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});
</script>
</body>
</html>
