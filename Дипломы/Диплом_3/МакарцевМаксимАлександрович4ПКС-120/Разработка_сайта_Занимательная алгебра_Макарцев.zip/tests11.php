<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "<script>
        if (confirm('Вы должны зарегистрироваться или войти, чтобы пройти тест. Нажмите ОК для входа или Отмена для возвращения на главную страницу.')) {
            window.location.href = 'authorization.html';
        } else {
            window.location.href = 'math.php';
        }
    </script>";
    exit();
}
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');

$header = mysqli_query($connect, "SELECT * FROM `adm_headerlt`");
$header = mysqli_fetch_all($header);

$test = mysqli_query($connect, "SELECT * FROM `test_answers`");
$test = mysqli_fetch_all($test);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование 11 класс | InterestAlg</title>
    <link rel="stylesheet" href="css/tests.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <style>
        .question ul {
            list-style-type: none;
            padding-left: 0;
        }
    </style>
</head>
<body>
    <header>
        <div id="header">
            <div id="logo" onclick="slowScroll('#test')">
                <span>InterestAlg</span>
            </div>
            <div id="back">
                <a href="math.php#materials" title="Лекционный материал" onclick="slowScroll('#materials')"><?php echo $header[0][1]?></a>
                <a href="math.php#test" title="Тестирование"><?php echo $header[0][2]?></a>
                <a href="math.php"><?php echo $header[0][3]?></a>
            </div>
        </div>
    </header> 
    <main>
        <div class="fullpage">
            <div class="heading">
                <h2>Тестирование для 11 класса</h2>
            </div>
            <div id="test">
                <div class="container1">
                    <form class="testForm" id="testForm" action="save_test_result.php" method="POST" data-test-id="5">
                        <input type="hidden" name="testId" id="testId" value="5">
                        <div class="question">
                            <h3><?php echo $test[40][2]?></h3>
                            <label><input type="radio" name="41" value="a" id="q41a"> <?php echo $test[40][3]?></label>
                            <label><input type="radio" name="41" value="b" id="q41b"> <?php echo $test[40][4]?></label>
                            <label><input type="radio" name="41" value="c" id="q41c"> <?php echo $test[40][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[41][2]?></h3>
                            <label><input type="radio" name="42" value="a" id="q42a"> <?php echo $test[41][3]?></label>
                            <label><input type="radio" name="42" value="b" id="q42b"> <?php echo $test[41][4]?></label>
                            <label><input type="radio" name="42" value="c" id="q42c"> <?php echo $test[41][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[42][2]?></h3>
                            <label><input type="radio" name="43" value="a" id="q43a"> <?php echo $test[42][3]?></label>
                            <label><input type="radio" name="43" value="b" id="q43b"> <?php echo $test[42][4]?></label>
                            <label><input type="radio" name="43" value="c" id="q43c"> <?php echo $test[42][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[43][2]?></h3>
                            <label><input type="radio" name="44" value="a" id="q44a"> <?php echo $test[43][3]?></label>
                            <label><input type="radio" name="44" value="b" id="q44b"> <?php echo $test[43][4]?></label>
                            <label><input type="radio" name="44" value="c" id="q44c"> <?php echo $test[43][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[44][2]?></h3>
                            <label><input type="radio" name="45" value="a" id="q45a"> <?php echo $test[44][3]?></label>
                            <label><input type="radio" name="45" value="b" id="q45b"> <?php echo $test[44][4]?></label>
                            <label><input type="radio" name="45" value="c" id="q45c"> <?php echo $test[44][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[45][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[45][3]; ?></a></li>
                                <li><a>b) <?php echo $test[45][4]; ?></a></li>
                                <li><a>c) <?php echo $test[45][5]; ?></a></li>
                                <li><a>d) <?php echo $test[45][6]; ?></a></li>
                                <li><a>e) <?php echo $test[45][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="46" id="q46" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[46][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[46][3]; ?></a></li>
                                <li><a>b) <?php echo $test[46][4]; ?></a></li>
                                <li><a>c) <?php echo $test[46][5]; ?></a></li>
                                <li><a>d) <?php echo $test[46][6]; ?></a></li>
                                <li><a>e) <?php echo $test[46][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="47" id="q47" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[47][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[47][3]; ?></a></li>
                                <li><a>b) <?php echo $test[47][4]; ?></a></li>
                                <li><a>c) <?php echo $test[47][5]; ?></a></li>
                                <li><a>d) <?php echo $test[47][6]; ?></a></li>
                                <li><a>e) <?php echo $test[47][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="48" id="q48" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[48][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="49" id="q49" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[49][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="50" id="q50" placeholder="Введите ответ">
                            </label>
                        </div>
                        <button type="submit" id="submit">Отправить результаты</button>
                        <div id="resultDisplay"></div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <script src="js/quiz.js"></script>
</body>
</html>
