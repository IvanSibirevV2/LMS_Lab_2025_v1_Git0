<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Проверяем, есть ли сеанс аутентификации пользователя
    if (!isset($_SESSION['user_id'])) {
        // Если сеанса аутентификации нет, перенаправляем на страницу входа или выводим сообщение об ошибке
        echo "<script>alert('Вы не авторизованы.');</script>";
        exit(); // Завершаем выполнение скрипта
    }
    
    // Продолжаем только если пользователь авторизован
    $user_id = $_SESSION['user_id'];
    if (isset($_POST['old_password']) && isset($_POST['new_password'])) {
        $old_password = $_POST['old_password'];
        $new_password = $_POST['new_password'];
        
        $servername = "localhost";
        $db_username = "u2666147_default";
        $db_password = "QMqjgV214mm9uHuV";
        $dbname = "u2666147_diplommath";

        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        if ($conn->connect_error) {
            die("Ошибка подключения к базе данных: " . $conn->connect_error);
        }

        $sql_check_password = "SELECT id FROM users WHERE id = '$user_id' AND password = '$old_password'";
        $result_check_password = $conn->query($sql_check_password);

        if ($result_check_password->num_rows == 1) {
            $insert_sql = "INSERT INTO password_history (user_id, old_password, new_password) VALUES ('$user_id', '$old_password', '$new_password')";
            if ($conn->query($insert_sql) === TRUE) {
                $update_sql = "UPDATE users SET password = '$new_password' WHERE id = '$user_id'";
                if ($conn->query($update_sql) === TRUE) {
                    header("Location: profile.php");
                    exit();
                } else {
                    echo "Ошибка при обновлении пароля в таблице users: " . $conn->error;
                }
            } else {
                echo "Ошибка при добавлении записи в историю паролей: " . $conn->error;
            }
        } else {
            echo "<script>alert('Старый пароль введен неверно.');</script>";
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Смена пароля | InterestAlg</title>
    <link rel="stylesheet" href="css/changepass.css">
</head>

<body>
    <div class="container">
        <h1>Смена пароля</h1>
        <form method="post" action="">
            <div>
                <label for="old_password">Старый пароль:</label>
                <input type="password" id="old_password" name="old_password" required>
            </div>
            <div>
                <label for="new_password">Новый пароль:</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div>
                <button type="submit">Изменить пароль</button>
            </div>
        </form>
    </div>
</body>
</html>
