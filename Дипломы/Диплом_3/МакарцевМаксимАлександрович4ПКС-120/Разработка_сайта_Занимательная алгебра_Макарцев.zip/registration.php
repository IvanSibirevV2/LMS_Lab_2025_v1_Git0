<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    if (!empty($_POST['username']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['confirmPassword'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];

        if ($password !== $confirmPassword) {
            echo "<script>alert('Пароли не совпадают!'); window.location.href = 'registration.html';</script>";
            exit();
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $host = 'localhost';
        $dbname = 'u2666147_diplommath';
        $username_db = 'u2666147_default';
        $password_db = 'QMqjgV214mm9uHuV';

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("set names utf8");

            $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
            $stmt->execute([$username]);
            $existingUser = $stmt->fetch();
            if ($existingUser) {
                echo "<script>alert('Имя пользователя уже занято!'); window.location.href = 'registration.html';</script>";
                exit();
            }

            $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
            $stmt->execute([$email]);
            $existingEmail = $stmt->fetch();
            if ($existingEmail) {
                echo "<script>alert('Адрес электронной почты уже используется!'); window.location.href = 'registration.html';</script>";
                exit();
            }

            $stmt = $pdo->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
            $stmt->execute([$username, $email, $hashedPassword]);

            header("Location: authorization.html?username=$username");
            exit();
        } catch (PDOException $e) {
            echo "Ошибка: " . $e->getMessage();
            exit();
        }
    } else {
        echo "<script>alert('Пожалуйста, заполните все поля.'); window.location.href = 'registration.html';</script>";
        exit();
    }
}
?>
