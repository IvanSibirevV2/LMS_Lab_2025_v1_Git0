<?php
session_start();
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');

$header = mysqli_query($connect, "SELECT * FROM `adm_headerlt`");
$header = mysqli_fetch_all($header);

$container1 = mysqli_query($connect, "SELECT * FROM `9lecturepart1`");
$container1 = mysqli_fetch_all($container1);

$container2 = mysqli_query($connect, "SELECT * FROM `9lecturepart2`");
$container2 = mysqli_fetch_all($container2);

$container3 = mysqli_query($connect, "SELECT * FROM `9lecturepart3`");
$container3 = mysqli_fetch_all($container3);

$container4 = mysqli_query($connect, "SELECT * FROM `9lecturepart4`");
$container4 = mysqli_fetch_all($container4);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лекционные материалы</title>
    <link rel="stylesheet" href="css/lectures.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
</head>
<body>
    <header>
        <div id="header">
            <div id="logo" onclick="slowScroll('#lecture')">
                <span>InterestAlg</span>
            </div>
            <div id="back">
                <a href="math.php#materials" title="Лекционный материал" onclick="slowScroll('#materials')"><?php echo $header[0][1]?></a>
                <a href="math.php#test" title="Тестирование"><?php echo $header[0][2]?></a>
                <a href="math.php"><?php echo $header[0][3]?></a>
            </div>
        </div>
    </header> 
    <main>
        <div class="fullpage">
            <div class="heading">
                <h2><?php echo $container1[0][1]?></h2>
            </div>
            <div id="lecture">
                <div class="container1">
                    <h2><?php echo $container1[0][2]?></h2>
                    <ul>
                        <li><a href="lecturesall.php#class9_chapter1_topic1"><?php echo $container1[0][3]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter1_topic2"><?php echo $container1[0][4]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter1_topic3"><?php echo $container1[0][5]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter1_topic4"><?php echo $container1[0][6]?></a></li>
                    </ul>
                </div>
                <div class="container2">
                    <h2><?php echo $container2[0][1]?></h2>
                    <ul>
                        <li><a href="lecturesall.php#class9_chapter2_topic1"><?php echo $container2[0][2]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter2_topic2"><?php echo $container2[0][3]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter2_topic3"><?php echo $container2[0][4]?></a></li>
                    </ul>
                </div>
                <div class="container3">
                    <h2><?php echo $container3[0][1]?></h2>
                    <ul>
                        <li><a href="lecturesall.php#class9_chapter3_topic1"><?php echo $container3[0][2]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter3_topic2"><?php echo $container3[0][3]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter3_topic3"><?php echo $container3[0][4]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter3_topic4"><?php echo $container3[0][5]?></a></li>
                    </ul>
                </div>
                <div class="container4">
                    <h2><?php echo $container4[0][1]?></h2>
                    <ul>
                        <li><a href="lecturesall.php#class9_chapter4_topic1"><?php echo $container4[0][2]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter4_topic2"><?php echo $container4[0][3]?></a></li>
                        <li><a href="lecturesall.php#class9_chapter4_topic3"><?php echo $container4[0][4]?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </main>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function slowScroll(id) {
          $('html, body').animate({ 
            scrollTop: $(id).offset().top
          }, 500);
        }

        $(document).on("scroll", function () {
          if($(window).scrollTop() === 0)
            $("header").removeClass("fixed");
          else
            $("header").attr("class", "fixed");
        });
    </script>
</body>
</html>
