<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "<script>
        if (confirm('Вы должны зарегистрироваться или войти, чтобы пройти тест. Нажмите ОК для входа или Отмена для возвращения на главную страницу.')) {
            window.location.href = 'authorization.html';
        } else {
            window.location.href = 'math.php';
        }
    </script>";
    exit();
}
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');


$header = mysqli_query($connect, "SELECT * FROM `adm_headerlt`");
$header = mysqli_fetch_all($header);

$test = mysqli_query($connect, "SELECT * FROM `test_answers`");
$test = mysqli_fetch_all($test);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование 10 класс | InterestAlg</title>
    <link rel="stylesheet" href="css/tests.css">
    <link rel="icon" href="./pic/InterestAlg.ico">
    <style>
        .question ul {
            list-style-type: none;
            padding-left: 0;
        }
    </style>
</head>
<body>
    <header>
        <div id="header">
            <div id="logo" onclick="slowScroll('#test')">
                <span>InterestAlg</span>
            </div>
            <div id="back">
                <a href="math.php#materials" title="Лекционный материал" onclick="slowScroll('#materials')"><?php echo $header[0][1]?></a>
                <a href="math.php#test" title="Тестирование"><?php echo $header[0][2]?></a>
                <a href="math.php"><?php echo $header[0][3]?></a>
            </div>
        </div>
    </header> 
    <main>
        <div class="fullpage">
            <div class="heading">
                <h2>Тестирование для 10 класса</h2>
            </div>
            <div id="test">
                <div class="container1">
                    <form class="testForm" id="testForm" action="save_test_result.php" method="POST" data-test-id="4">
                        <input type="hidden" name="testId" id="testId" value="4">
                        <div class="question">
                            <h3><?php echo $test[30][2]?></h3>
                            <label><input type="radio" name="31" value="a" id="q31a"> <?php echo $test[30][3]?></label>
                            <label><input type="radio" name="31" value="b" id="q31b"> <?php echo $test[30][4]?></label>
                            <label><input type="radio" name="31" value="c" id="q31c"> <?php echo $test[30][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[31][2]?></h3>
                            <label><input type="radio" name="32" value="a" id="q32a"> <?php echo $test[31][3]?></label>
                            <label><input type="radio" name="32" value="b" id="q32b"> <?php echo $test[31][4]?></label>
                            <label><input type="radio" name="32" value="c" id="q32c"> <?php echo $test[31][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[32][2]?></h3>
                            <label><input type="radio" name="33" value="a" id="q33a"> <?php echo $test[32][3]?></label>
                            <label><input type="radio" name="33" value="b" id="q33b"> <?php echo $test[32][4]?></label>
                            <label><input type="radio" name="33" value="c" id="q33c"> <?php echo $test[32][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[33][2]?></h3>
                            <label><input type="radio" name="34" value="a" id="q34a"> <?php echo $test[33][3]?></label>
                            <label><input type="radio" name="34" value="b" id="q34b"> <?php echo $test[33][4]?></label>
                            <label><input type="radio" name="34" value="c" id="q34c"> <?php echo $test[33][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[34][2]?></h3>
                            <label><input type="radio" name="35" value="a" id="q35a"> <?php echo $test[34][3]?></label>
                            <label><input type="radio" name="35" value="b" id="q35b"> <?php echo $test[34][4]?></label>
                            <label><input type="radio" name="35" value="c" id="q35c"> <?php echo $test[34][5]?></label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[35][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[35][3]; ?></a></li>
                                <li><a>b) <?php echo $test[35][4]; ?></a></li>
                                <li><a>c) <?php echo $test[35][5]; ?></a></li>
                                <li><a>d) <?php echo $test[35][6]; ?></a></li>
                                <li><a>e) <?php echo $test[35][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="36" id="q36" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[36][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[36][3]; ?></a></li>
                                <li><a>b) <?php echo $test[36][4]; ?></a></li>
                                <li><a>c) <?php echo $test[36][5]; ?></a></li>
                                <li><a>d) <?php echo $test[36][6]; ?></a></li>
                                <li><a>e) <?php echo $test[36][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="37" id="q27" placeholder="Введите ответ">
                            </label>
                        </div>

                        <div class="question">
                            <h3><?php echo $test[37][2]; ?></h3>
                            <div>Варианты ответов:</div>
                            <ul>
                                <li><a>a) <?php echo $test[37][3]; ?></a></li>
                                <li><a>b) <?php echo $test[37][4]; ?></a></li>
                                <li><a>c) <?php echo $test[37][5]; ?></a></li>
                                <li><a>d) <?php echo $test[37][6]; ?></a></li>
                                <li><a>e) <?php echo $test[37][7]; ?></a></li>
                            </ul>
                            <label>
                                Ваш ответ: <input type="text" name="38" id="q38" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[38][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="39" id="q39" placeholder="Введите ответ">
                            </label>
                        </div>
                        <div class="question">
                            <h3><?php echo $test[39][2]; ?></h3>
                            <label>
                                Ваш ответ: <input type="text" name="40" id="q40" placeholder="Введите ответ">
                            </label>
                        </div>
                        <button type="submit" id="submit">Отправить результаты</button>
                        <div id="resultDisplay"></div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <script src="js/quiz.js"></script>
</body>
</html>
