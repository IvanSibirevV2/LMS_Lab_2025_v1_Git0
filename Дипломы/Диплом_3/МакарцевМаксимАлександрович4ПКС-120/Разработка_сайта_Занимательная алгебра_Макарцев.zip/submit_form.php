<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-6.9.1/src/Exception.php';
require 'PHPMailer-6.9.1/src/PHPMailer.php';
require 'PHPMailer-6.9.1/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userName = $_POST['name'];
    $userEmail = $_POST['email'];
    $userMessage = $_POST['message'];

    // Validate input data
    if (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
        echo "<p>Неправильный формат email.</p>";
        exit;
    }
    if (empty($userName) || empty($userMessage)) {
        echo "<p>Все поля обязательны для заполнения.</p>";
        exit;
    }
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.mail.ru';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'diplommath@mail.ru';
        $mail->Password   = 'RPHRJJUWvbEY4cmJ3snj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        // Encoding
        $mail->CharSet = 'UTF-8';

        // Recipients
        $mail->setFrom('diplommath@mail.ru', 'Website Contact Form');
        $mail->addAddress('diplommath@mail.ru');

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Новое сообщение от пользователя сайта';
        $mail->Body    = "<p><strong>Имя:</strong> {$userName}</p><p><strong>Email:</strong> {$userEmail}</p><p><strong>Сообщение:</strong><br>{$userMessage}</p>";
        $mail->AltBody = "Имя: {$userName}\nEmail: {$userEmail}\nСообщение:\n{$userMessage}";
        
        // Send the email
        if ($mail->send()) {
            echo "<p>Письмо успешно отправлено!</p>";
        } else {
            echo "<p>Ошибка при отправке письма: {$mail->ErrorInfo}</p>";
        }
    } catch (Exception $e) {
        echo "<p>Ошибка при отправке письма: {$mail->ErrorInfo}</p>";
    }
}
?>