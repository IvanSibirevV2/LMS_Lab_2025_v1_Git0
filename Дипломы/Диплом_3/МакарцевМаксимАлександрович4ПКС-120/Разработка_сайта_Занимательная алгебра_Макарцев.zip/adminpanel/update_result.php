<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $grade = $_POST['grade'];

    $sql = $pdo->prepare("UPDATE test_result SET grade = :grade WHERE id = :id");
    $sql->bindParam(':grade', $grade, PDO::PARAM_STR);
    $sql->bindParam(':id', $id, PDO::PARAM_INT);

    if ($sql->execute()) {
        header("Location: adminpanel.php");
        exit();
    } else {
        echo "Ошибка обновления записи: " . $sql->errorInfo()[2];
    }
}
?>
