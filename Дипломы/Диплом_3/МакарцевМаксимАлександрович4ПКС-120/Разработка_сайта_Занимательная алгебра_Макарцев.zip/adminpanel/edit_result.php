<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

$id = $_GET['id'];

$sql_tests = $pdo->query("SELECT id, tests FROM test")->fetchAll(PDO::FETCH_ASSOC);

$sql_result = $pdo->prepare("SELECT tr.id, tr.test_id, t.tests AS test_name, u.username, tr.grade 
                      FROM test_result tr 
                      JOIN test t ON tr.test_id = t.id
                      JOIN users u ON tr.user_id = u.id
                      WHERE tr.id = :id");
$sql_result->bindParam(':id', $id, PDO::PARAM_INT);
$sql_result->execute();
$row = $sql_result->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/edit_result.css">
    <title>Редактирование результата | InterestAlg</title>
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <h2>Редактировать результат</h2>
    <form action="update_result.php" method="post">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
        <label for="testName">Тест:</label>
        <select id="testName" name="testName">
            <?php foreach ($sql_tests as $test): ?>
                <option value="<?php echo htmlspecialchars($test['id']); ?>" <?php if ($test['id'] == $row['test_id']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($test['tests']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>
        <label for="userName">Пользователь:</label>
        <input type="text" id="userName" name="userName" value="<?php echo htmlspecialchars($row['username']); ?>" readonly><br><br>
        <label for="grade">Результат:</label>
        <input type="text" id="grade" name="grade" value="<?php echo htmlspecialchars($row['grade']); ?>"><br><br>
        <button type="submit">Сохранить</button>
    </form>
</body>
</html>
