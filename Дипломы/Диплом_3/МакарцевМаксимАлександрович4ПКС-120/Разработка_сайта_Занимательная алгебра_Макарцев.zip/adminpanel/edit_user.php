<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

$id = $_GET['id'];
$query = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute(['id' => $id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'] ? password_hash($_POST['password'], PASSWORD_DEFAULT) : $user['password'];

    $query = "UPDATE users SET username = :username, email = :email, password = :password WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        'username' => $username,
        'email' => $email,
        'password' => $password,
        'id' => $id
    ]);

    header('Location: adminpanel.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./mainpage/css/admin_page.css">
    <title>Изменить пользователя | InterestAlg</title>
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
        <div class="container">
            <form class="admin_page-form" action="edit_user.php?id=<?= $user['id'] ?>" method="POST">
                <h1>Изменить пользователя</h1>
                <input class="formInput" name="username" type="text" placeholder="Имя пользователя" value="<?= htmlspecialchars($user['username']) ?>" required>
                <input class="formInput" name="email" type="email" placeholder="Email" value="<?= htmlspecialchars($user['email']) ?>" required>
                <input class="formInput" name="password" type="password" placeholder="Пароль (оставьте пустым, чтобы не изменять)">
                <input class="formInput btn" type="submit" value="Сохранить изменения">
            </form>
        </div>
    </div>
</body>
</html>
