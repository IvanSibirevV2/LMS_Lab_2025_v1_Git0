<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        'username' => $username,
        'email' => $email,
        'password' => $password
    ]);

    header('Location: adminpanel.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./mainpage/css/admin_page.css">
    <title>Добавить пользователя | InterestAlg</title>
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
        <div class="container">
            <form class="admin_page-form" action="add_user.php" method="POST">
                <h1>Добавить пользователя</h1>
                <input class="formInput" name="username" type="text" placeholder="Имя пользователя" required>
                <input class="formInput" name="email" type="email" placeholder="Email" required>
                <input class="formInput" name="password" type="password" placeholder="Пароль" required>
                <input class="formInput btn" type="submit" value="Добавить">
            </form>
        </div>
    </div>
</body>
</html>
