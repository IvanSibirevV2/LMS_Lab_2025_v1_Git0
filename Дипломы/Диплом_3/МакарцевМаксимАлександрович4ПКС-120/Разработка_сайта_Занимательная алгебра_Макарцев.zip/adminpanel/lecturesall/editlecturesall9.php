<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part11"]=="" || $_POST["part12"]=="" || $_POST["part13"]=="" || $_POST["part14"]=="" || $_POST["part21"]=="" || $_POST["part22"]=="" || $_POST["part23"]=="" || $_POST["part31"]=="" || $_POST["part32"]=="" || $_POST["part33"]=="" || $_POST["part34"]=="" || $_POST["part41"]=="" || $_POST["part42"]=="" || $_POST["part43"]==""){    
    $theme1 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme2 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme3 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme4 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme5 = "";//пустая
    $theme6 = "";//пустая
    $theme7 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme8 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme9 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme10 = "";//пустая
    $theme11 = "";//пустая
    $theme12 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme13 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme14 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme15 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme16 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme17 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme18 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme19 = "";//пустая
    $theme20 = "";//пустая
}
else {
    $theme1 = $_POST["part11"];
    $theme2 = $_POST["part12"];
    $theme3 = $_POST["part13"];
    $theme4 = $_POST["part14"];
    // $theme5 = $_POST["part15"];
    // $theme6 = $_POST["part16"];

    $theme7 = $_POST["part21"];
    $theme8 = $_POST["part22"];
    $theme9 = $_POST["part23"];
    // $theme10 = $_POST["part24"];
    // $theme11 = $_POST["part25"];

    $theme12 = $_POST["part31"];
    $theme13 = $_POST["part32"];
    $theme14 = $_POST["part33"];
    $theme15 = $_POST["part34"];

    $theme16 = $_POST["part41"];
    $theme17 = $_POST["part42"];
    $theme18 = $_POST["part43"];
    // $theme19 = $_POST["part44"];
    // $theme20 = $_POST["part45"];
    
}
mysqli_query($connect, "UPDATE `lecturesall` SET `part11` = '$theme1', `part12` = '$theme2', `part13` = '$theme3', `part14` = '$theme4', `part15` = '', `part16` = '', `part21` = '$theme7', `part22` = '$theme8', `part23` = '$theme9', `part24` = '', `part25` = '', `part31` = '$theme12', `part32` = '$theme13', `part33` = '$theme14', `part34` = '$theme15', `part41` = '$theme16', `part42` = '$theme17', `part43` = '$theme18', `part44` = '', `part45` = '' WHERE `lecturesall`.`id` = 3;");