<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part11"]=="" || $_POST["part12"]=="" || $_POST["part13"]=="" || $_POST["part14"]=="" || $_POST["part15"]=="" || $_POST["part21"]=="" || $_POST["part22"]=="" || $_POST["part23"]=="" || $_POST["part24"]=="" || $_POST["part25"]=="" || $_POST["part31"]=="" || $_POST["part32"]=="" || $_POST["part33"]=="" || $_POST["part34"]=="" || $_POST["part41"]=="" || $_POST["part42"]=="" || $_POST["part43"]=="" || $_POST["part44"]=="" || $_POST["part45"]==""){    
    $theme1 = "Числовые выражения - состоит из чисел и знаков арифметических действий между ними, также может содержать скобки для указания порядка действий. Числовое выражение должно иметь смысл.
    Алгебраические выражения - состоит из букв и чисел, между которыми стоят знаки арифметических действий, также может содержать скобки. Алгебраическое выражение должно иметь смысл.    
    В буквенном выражении (520 - x : 5), буква x, вместо которой можно подставить различные числа, называется переменной.    
    Переменная - это буква, входящая в алгебраическое выражение, которая может принимать различные значения.    
    Множество значений, которые может принимать переменная, не лишая выражения смысла, называется областью определения этого выражения.    
    Обычно, при нахождении области определения, мы должны исключить такие значения переменных, при которых придется делить на ноль.    
    Рассмотрим область определения для выражений:    
    x - 11 - x может принимать любые значения
    11 : x - любые значения за исключением нуля (x ≠ 0)
    (x + 5) : (x - 2) - любые значения за исключением двух (x ≠ 2)
    a - b - любые значения за исключением двух вариантов (a ≠ 0) и (a ≠ b)
    a(a - b) - (a ≠ 0) и (a ≠ b).";
    $theme2 = "Мы уже не раз встречали записи, написанные на математическом языке. Например:
    мат. яз.	рус. яз.
    2(a + b)	удвоенная сумма двух чисел, a и b;
    Обратите внимание, что математический язык от русского, отличает краткость и ясность.    
    Приведем еще примеры математических записей и их аналогов на русском языке:    
    мат. яз.	рус. яз.
    (a - b)^2	половина квадрата разности двух чисел a и b
    (a - b)^2 : 2	также половина квадрата разности двух чисел a и b
    1 • (a - b)^2	одна вторая квадрата разности двух чисел a и b
    Если приведенные выше выражения, мы обозначим как A, B и С.    
    A = (a - b)^2, B = (a - b)^2 : 2, C = 1 • (a - b)^2    
    Мы можем утверждать, что A = B = C, так как эти выражения равны при любых значениях переменных.   
    Еще говорят, что эти выражения (A, B и C) тождественны или тождественно равны друг другу.    
    Тождество — это равенство двух отличных по записи, но имеющих одинаковое значение, выражений, при любых переменных из их области определения.    
    (a - b)^2 = (a - b)^2 : 2 — верное тождество    
    Чтобы установить, что равенство не является тождеством, достаточно указать такие значения переменных, из их области определения, при котором выражения не равны друг другу.    
    Например: A = x • 4 + 1; B = x + 4;    
    Несмотря на то, что при x = 1; A = 1 • 4 + 1 = 4 + 1 = 5; B = 1 + 4 = 5;    
    При x = 2; A = 2 • 4 + 1 = 8 + 1 = 9; B = 2 + 4 = 6;    
    Значит выражения A = x • 4 + 1; и B = x + 4; — не тождественны друг другу.    
    Тождественное преобразование — это преобразование выражения в другое, тождественно равное ему.    
    Многие тождественные преобразования вы уже знаете. Например:    
    мат. яз.	рус. яз.
    a • a = a^2	квадрат числа
    a • a • a = a • a^2 = a^3	куб числа
    a + b = b + a	от перемены мест слагаемых сумма не изменится
    (a + b) + c = a + (b + c)	сочетательное свойство сложения
    ab = ba	от перемены мест множителей произведение не изменится
    (ab)c = a(bc)	сочетательное свойство умножения
    a(b + c) = ab + ac	распределительный закон умножения
    5a + 6a = 11a	приведение подобных слагаемых
    a / (b + c) = a / b - a / c	раскрытие скобок (минус перед скобками меняет знаки слагаемых)
    a = a • k (k ≠ 0)	основное свойство дроби
    b = b • k (k ≠ 0)	основное свойство дроби
    a • n = an / b	умножение дроби на число
    a / n = a / bn	деление дроби на число
    a • a1 = aa1 / bb1	произведение двух дробей
    a / a1 = ab1 / ba1	деление дроби на дробь.";
    $theme3 = "Математическая модель - это способ описания реальной жизненной ситуации (задачи) с помощью математического языка. На нашем этапе изучения алгебры мы будем использовать математическое моделирование как помощь в решении задач.
    Решим первую задачу
    В начале боя, в игре Мир танков, у каждой стороны было по 14 боевых машин. В итоге, после захвата базы, потери противника оказались втрое больше потерь вашей команды, и на поле в общей сложности осталось 12 машин. 
    Сколько танков осталось у вашей команды к концу боя?    
    Составим математическую модель:    
    28 — кол-во всех танков до боя (14 у каждой стороны)
    x — количество танков, потерянных вашей командой
    3x — потери вражеской команды
    12 — кол-во всех танков после боя
    Составим уравнение и решим его:    
                            28 - x - 3x = 12
                            28 - 12 - x - 3x = 0
                            28 - 12 = 4x
                            16 = 4x
                            x = 4                        
    Ответ на вопрос задачи: 14 - 4 = 10 (танков).
    Ответ: 10 танков осталось у нашей команды в конце боя.";
    $theme4 = "Уравнением с одной переменной называется равенство, содержащее только одну переменную. Корнем (или решением) уравнения называется такое значение переменной, при котором уравнение превращается в верное числовое равенство.
    Найти все корни уравнения или доказать, что их нет – это значит решить уравнение.    
    Свойства линейных уравнений:
    Свойство 1: При переносе слагаемого из одной части уравнения в другую с противоположным знаком, получается уравнение с теми же корнями.   
                           x – 3 = 6   ⇒   x = 6 + 3   ⇒   x = 9 .                        
    Свойство 2: При умножении или делении обеих частей уравнения на одно и то же число, отличное от нуля, мы получим уравнение с теми же корнями (решениями).   
                            3x = 6   ⇒   3x : 3 = 6 : 3   ⇒   x = 2 .                        
    Уравнение вида ax = b называется линейным. Например:    
    3x = 9 ( ax = b ) .
    3x – 3 = 9 ;
    3x = 9 + 3 ;
    3x = 12 ( ax = b ) .    
    Принято: цифры в алгебраических выражениях заменять первыми буквами латинского алфавита — a, b, c, …, а переменные обозначать последними — x, y, z.   
    Свойства линейных уравнений:    
    a ≠ 0, b — любое значение: ax = b имеет один корень x = b : a .
    a = 0, b ≠ 0: ax = b не имеет корней .
    a = 0, b = 0: ax = b имеет бесконечно много корней .
    Примеры:    
    3x = 3 — один корень — x = 3 : 3 — x = 1 .
    0 • x = 5 — корней нет .
    0 • x = 0 — бесконечно много корней — x — любое число.";
    $theme5 = "Координатной прямой или координатной осью называют прямую m, на которой обозначены начало отсчёта (точка 0), единичный отрезок (отрезок длиной 1) и положительное направление . Любая точка на координатной прямой соответствует числу, причём единственному. И наоборот, для числа можно найти точку на координатной прямой. Например, числу 2 соответствует точка А, которая находится на расстоянии 2 от начальной точки О в положительном направлении. Точка М соответствует числу - 2, которая находится на расстоянии 2 от начальной точки О в отрицательном направлении, т. е. в направлении, противоположном заданному.
    Обратные утверждения также верны. Если точка N находится на расстоянии 3,5 в положительном направлении от точки О, то она соответствует числу 3,5. Если точка М находится на расстоянии 2 в отрицательном направлении, то она соответствует числу -2.    
    Полученные таким образом числа являются координатами соответствующих точек.    
    Записываем: A(2); N(3,5); M(-2); O(0).    
    Говорим: точка А имеет координату 2; точка N имеет координату 3,5; точка М имеет координату -2; точка О имеет координату О.    
    Расстояние между двумя точками A(а) и B(b) на координатной прямой равно AB = |a - b|.
    Используя эту формулу, получим, что AN = 2 - 3,5 = |1,5| = 1,5; AM = |2-(-2)| = |2 +2| = 4.";
    $theme6 = "";//пустая
    $theme7 = "Плоскость с двумя взаимно перпендикулярными прямыми, на которых выбрано направление и обозначены единичные отрезки, образуют координатную плоскость.
    Координаты точки, абсциссу (x) и ординату (y), определяют с помощью перпендикуляров от этой точки к соответствующим осям координат. Координатная плоскость.";
    $theme8 = "Уравнение вида ах + by + с = 0, где а, b, с - числа (коэффициенты), называется линейным уравнением с двумя переменными х и у.
    Решением уравнения ах + by + с = 0 является пара чисел (x, у), обращающая данное уравнение в верное равенство.    
    Пример: изобразим решения линейного уравнения -y - 2 = 0 точками в координатной плоскости xOу.    
    Несложно подобрать несколько решений: (3, 5), (2, 4), (1, 3), (0, 2), (-2, 0). Построим эти точки в координатной плоскости и убедимся, что они лежат на одной прямой t.    
    Прямая t является графиком уравнения -y - 2 = 0, или прямая t является геометрической моделью этого уравнения.    
    Итак, если пара чисел (x, у) удовлетворяет уравнению ах + by + с = 0, то точка M(x, у) принадлежит прямой t. И обратно, если точка M(x, у) принадлежит прямой t, то пара чисел (x, у) удовлетворяет уравнению ax + by + c = 0.   
    Графиком уравнения ах + by + с = 0 является прямая, если коэффициенты a, b не равны нулю одновременно.    
    Алгоритм построения графика уравнения ах + by + с = 0, где а ≠ 0, b ≠ 0:    
    Выбрать любое удобное значение переменной х = x1 и из уравнения аx1 + by + с = 0 вычислить значение у1.
    Выбрать другое значение переменной х = x2 и из уравнения ах2 + by + с = 0 вычислить значение у2.
    На координатной плоскости хОу отметить точки: (x1, y1) и (x2, y2).
    Через эти точки провести прямую - она и будет являться искомым графиком.
    Пример: начертить график уравнения x - 2y - 4 = 0.    
    Подставим х = 0 в уравнение, получим: 0 - 2y - 4 = 0; -2y = 4; y = 4/(-2); y = -2.
    Подставим в уравнение у = 0, получим: x - 2 * 0 - 4 = 0; x - 4 - 0; x - 4.
    Отметим полученные точки (0, -2) и (4, 0) в прямоугольной системе координат.
    Проведём через эти точки прямую.
    Она и будет графиком линейного уравнения x - 2y - 4 = 0";
    $theme9 = "Линейная функция - это функция, которую можно задать формулой y = kx + b, где х - независимая переменная, k и b - некоторые числа.
    Применяя эту формулу, зная конкретное значение х, можно вычислить соответствующее значение у. Пусть у = 0.5x - 2. Тогда: 
    при х = 0 получим у = -2;
    при х = 2 получим у = -1;
    при х = 4 получим у = 0 и т.д.
    Результаты заносим в таблицу, где x - независимая переменная (или аргумент), а y - зависимая переменная (или функция).   
                            x   0   2   4 
    
                            y   -2  -1  0                       
    Графиком линейной функции у = kx + b является прямая. Чтобы построить график данной функции, нам нужны координаты двух точек, принадлежащих графику функции. Построим в системе координат хОу точки (0, -2) и (4, 0) и проведём через них прямую.   
    В жизни существует множество ситуаций, которые можно описать математической моделью с помощью линейных функций.";
    $theme10 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme11 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme12 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme13 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme14 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme15 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme16 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme17 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme18 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme19 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
    $theme20 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?
Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores explicabo, ea libero odit ut aliquid est porro consequuntur sit ex accusantium excepturi earum itaque! Facilis fuga animi quibusdam voluptates? Earum?";
}
else {
    $theme1 = $_POST["part11"];
    $theme2 = $_POST["part12"];
    $theme3 = $_POST["part13"];
    $theme4 = $_POST["part14"];
    $theme5 = $_POST["part15"];
    // $theme6 = $_POST["part16"];

    $theme7 = $_POST["part21"];
    $theme8 = $_POST["part22"];
    $theme9 = $_POST["part23"];
    $theme10 = $_POST["part24"];
    $theme11 = $_POST["part25"];

    $theme12 = $_POST["part31"];
    $theme13 = $_POST["part32"];
    $theme14 = $_POST["part33"];
    $theme15 = $_POST["part34"];

    $theme16 = $_POST["part41"];
    $theme17 = $_POST["part42"];
    $theme18 = $_POST["part43"];
    $theme19 = $_POST["part44"];
    $theme20 = $_POST["part45"];
    
}
mysqli_query($connect, "UPDATE `lecturesall` SET `part11` = '$theme1', `part12` = '$theme2', `part13` = '$theme3', `part14` = '$theme4', `part15` = '$theme5', `part16` = '', `part21` = '$theme7', `part22` = '$theme8', `part23` = '$theme9', `part24` = '$theme10', `part25` = '$theme11', `part31` = '$theme12', `part32` = '$theme13', `part33` = '$theme14', `part34` = '$theme15', `part41` = '$theme16', `part42` = '$theme17', `part43` = '$theme18', `part44` = '$theme19', `part45` = '$theme20' WHERE `lecturesall`.`id` = 1;");