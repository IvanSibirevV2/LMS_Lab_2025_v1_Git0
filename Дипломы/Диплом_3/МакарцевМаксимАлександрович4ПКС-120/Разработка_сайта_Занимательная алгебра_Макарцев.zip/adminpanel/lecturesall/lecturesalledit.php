<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/adminlecturesall.css">
    <title>Admin Lectures All | InterestAlg</title>
    
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="/DiplomSite/adminpanel/adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
        <form class="admin_page-form" action="editlecturesall7.php" method="POST">
            <h1>Изменение блока #lecturesall 7 класс</h1>
            <input class="formInput" name="part11" type="text" placeholder="7 класс Глава 1 Тема 1">
            <textarea class="formmsg" name="part12" placeholder="7 класс Глава 1 Тема 2"></textarea>
            <textarea class="formmsg" name="part13" placeholder="7 класс Глава 1 Тема 3"></textarea>
            <textarea class="formmsg" name="part14" placeholder="7 класс Глава 1 Тема 4"></textarea>
            <textarea class="formmsg" name="part15" placeholder="7 класс Глава 1 Тема 5"></textarea>
            <textarea class="formmsg" name="part21" placeholder="7 класс Глава 2 Тема 1"></textarea>
            <textarea class="formmsg" name="part22" placeholder="7 класс Глава 2 Тема 2"></textarea>
            <textarea class="formmsg" name="part23" placeholder="7 класс Глава 2 Тема 3"></textarea>
            <textarea class="formmsg" name="part24" placeholder="7 класс Глава 2 Тема 4"></textarea>
            <textarea class="formmsg" name="part25" placeholder="7 класс Глава 2 Тема 5"></textarea>
            <textarea class="formmsg" name="part31" placeholder="7 класс Глава 3 Тема 1"></textarea>
            <textarea class="formmsg" name="part32" placeholder="7 класс Глава 3 Тема 2"></textarea>
            <textarea class="formmsg" name="part33" placeholder="7 класс Глава 3 Тема 3"></textarea>
            <textarea class="formmsg" name="part34" placeholder="7 класс Глава 3 Тема 4"></textarea>
            <textarea class="formmsg" name="part41" placeholder="7 класс Глава 4 Тема 1"></textarea>
            <textarea class="formmsg" name="part42" placeholder="7 класс Глава 4 Тема 2"></textarea>
            <textarea class="formmsg" name="part43" placeholder="7 класс Глава 4 Тема 3"></textarea>
            <textarea class="formmsg" name="part44" placeholder="7 класс Глава 4 Тема 4"></textarea>
            <textarea class="formmsg" name="part45" placeholder="7 класс Глава 4 Тема 5"></textarea>
            <input class="formInput btn" name="" type="submit">
        </form>
    </div>
    <div class="content">
        <form class="admin_page-form" action="editlecturesall8.php" method="POST">
            <h1>Изменение блока #lecturesall 8 класс</h1>
            <input class="formInput" name="part11" type="text" placeholder="8 класс Глава 1 Тема 1">
            <textarea class="formmsg" name="part12" placeholder="8 класс Глава 1 Тема 2"></textarea>
            <textarea class="formmsg" name="part13" placeholder="8 класс Глава 1 Тема 3"></textarea>
            <textarea class="formmsg" name="part14" placeholder="8 класс Глава 1 Тема 4"></textarea>
            <textarea class="formmsg" name="part15" placeholder="8 класс Глава 1 Тема 5"></textarea>
            <textarea class="formmsg" name="part21" placeholder="8 класс Глава 2 Тема 1"></textarea>
            <textarea class="formmsg" name="part22" placeholder="8 класс Глава 2 Тема 2"></textarea>
            <textarea class="formmsg" name="part23" placeholder="8 класс Глава 2 Тема 3"></textarea>
            <textarea class="formmsg" name="part24" placeholder="8 класс Глава 2 Тема 4"></textarea>
            <textarea class="formmsg" name="part25" placeholder="8 класс Глава 2 Тема 5"></textarea>
            <textarea class="formmsg" name="part31" placeholder="8 класс Глава 3 Тема 1"></textarea>
            <textarea class="formmsg" name="part32" placeholder="8 класс Глава 3 Тема 2"></textarea>
            <textarea class="formmsg" name="part33" placeholder="8 класс Глава 3 Тема 3"></textarea>
            <textarea class="formmsg" name="part34" placeholder="8 класс Глава 3 Тема 4"></textarea>
            <textarea class="formmsg" name="part41" placeholder="8 класс Глава 4 Тема 1"></textarea>
            <textarea class="formmsg" name="part42" placeholder="8 класс Глава 4 Тема 2"></textarea>
            <textarea class="formmsg" name="part43" placeholder="8 класс Глава 4 Тема 3"></textarea>
            <textarea class="formmsg" name="part44" placeholder="8 класс Глава 4 Тема 4"></textarea>
            <textarea class="formmsg" name="part45" placeholder="8 класс Глава 4 Тема 5"></textarea>
            <input class="formInput btn" name="" type="submit">
        </form>
    </div>
    <div class="content">
        <form class="admin_page-form" action="editlecturesall9.php" method="POST">
            <h1>Изменение блока #lecturesall 9 класс</h1>
            <input class="formInput" name="part11" type="text" placeholder="9 класс Глава 1 Тема 1">
            <textarea class="formmsg" name="part12" placeholder="9 класс Глава 1 Тема 2"></textarea>
            <textarea class="formmsg" name="part13" placeholder="9 класс Глава 1 Тема 3"></textarea>
            <textarea class="formmsg" name="part14" placeholder="9 класс Глава 1 Тема 4"></textarea>

            <textarea class="formmsg" name="part21" placeholder="9 класс Глава 2 Тема 1"></textarea>
            <textarea class="formmsg" name="part22" placeholder="9 класс Глава 2 Тема 2"></textarea>
            <textarea class="formmsg" name="part23" placeholder="9 класс Глава 2 Тема 3"></textarea>

            <textarea class="formmsg" name="part31" placeholder="9 класс Глава 3 Тема 1"></textarea>
            <textarea class="formmsg" name="part32" placeholder="9 класс Глава 3 Тема 2"></textarea>
            <textarea class="formmsg" name="part33" placeholder="9 класс Глава 3 Тема 3"></textarea>
            <textarea class="formmsg" name="part34" placeholder="9 класс Глава 3 Тема 4"></textarea>

            <textarea class="formmsg" name="part41" placeholder="9 класс Глава 4 Тема 1"></textarea>
            <textarea class="formmsg" name="part42" placeholder="9 класс Глава 4 Тема 2"></textarea>
            <textarea class="formmsg" name="part43" placeholder="9 класс Глава 4 Тема 3"></textarea>
            <input class="formInput btn" name="" type="submit">
        </form>
    </div>
    <div class="content">
        <form class="admin_page-form" action="editlecturesall10.php" method="POST">
            <h1>Изменение блока #lecturesall 10 класс</h1>
            <input class="formInput" name="part11" type="text" placeholder="10 класс Глава 1 Тема 1">
            <textarea class="formmsg" name="part12" placeholder="10 класс Глава 1 Тема 2"></textarea>
            <textarea class="formmsg" name="part13" placeholder="10 класс Глава 1 Тема 3"></textarea>

            <textarea class="formmsg" name="part21" placeholder="10 класс Глава 2 Тема 1"></textarea>
            <textarea class="formmsg" name="part22" placeholder="10 класс Глава 2 Тема 2"></textarea>
            <textarea class="formmsg" name="part23" placeholder="10 класс Глава 2 Тема 3"></textarea>
            <textarea class="formmsg" name="part24" placeholder="10 класс Глава 2 Тема 4"></textarea>

            <textarea class="formmsg" name="part31" placeholder="10 класс Глава 3 Тема 1"></textarea>

            <textarea class="formmsg" name="part41" placeholder="10 класс Глава 4 Тема 1"></textarea>
            <textarea class="formmsg" name="part42" placeholder="10 класс Глава 4 Тема 2"></textarea>
            <textarea class="formmsg" name="part43" placeholder="10 класс Глава 4 Тема 3"></textarea>
            <textarea class="formmsg" name="part44" placeholder="10 класс Глава 4 Тема 4"></textarea>
            <input class="formInput btn" name="" type="submit">
        </form>
    </div>
    <div class="content">
        <form class="admin_page-form" action="editlecturesall11.php" method="POST">
            <h1>Изменение блока #lecturesall 11 класс</h1>
            <input class="formInput" name="part11" type="text" placeholder="11 класс Глава 1 Тема 1">
            <textarea class="formmsg" name="part12" placeholder="11 класс Глава 1 Тема 2"></textarea>
            <textarea class="formmsg" name="part13" placeholder="11 класс Глава 1 Тема 3"></textarea>
            <textarea class="formmsg" name="part14" placeholder="11 класс Глава 1 Тема 4"></textarea>
            <textarea class="formmsg" name="part15" placeholder="11 класс Глава 1 Тема 5"></textarea>
            <textarea class="formmsg" name="part16" placeholder="11 класс Глава 1 Тема 6"></textarea>

            <textarea class="formmsg" name="part21" placeholder="11 класс Глава 2 Тема 1"></textarea>
            <textarea class="formmsg" name="part22" placeholder="11 класс Глава 2 Тема 2"></textarea>
            <textarea class="formmsg" name="part23" placeholder="11 класс Глава 2 Тема 3"></textarea>
            <textarea class="formmsg" name="part24" placeholder="11 класс Глава 2 Тема 4"></textarea>
            <textarea class="formmsg" name="part25" placeholder="11 класс Глава 2 Тема 5"></textarea>

            <textarea class="formmsg" name="part31" placeholder="11 класс Глава 3 Тема 1"></textarea>
            <textarea class="formmsg" name="part32" placeholder="11 класс Глава 3 Тема 2"></textarea>
            <textarea class="formmsg" name="part33" placeholder="11 класс Глава 3 Тема 3"></textarea>
            <textarea class="formmsg" name="part34" placeholder="11 класс Глава 3 Тема 4"></textarea>

            <textarea class="formmsg" name="part41" placeholder="11 класс Глава 4 Тема 1"></textarea>
            <textarea class="formmsg" name="part42" placeholder="11 класс Глава 4 Тема 2"></textarea>
            <textarea class="formmsg" name="part43" placeholder="11 класс Глава 4 Тема 3"></textarea>
            <input class="formInput btn" name="" type="submit">
        </form>
    </div>
</body>
</html>
