<?php
$servername = "localhost";
$username = "u2666147_default";
$password = "QMqjgV214mm9uHuV";
$dbname = "u2666147_diplommath";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
mysqli_set_charset($conn, 'utf8');

$sql = "SELECT result.id, test.tests as tests, users.username, result.result 
        FROM result 
        JOIN test ON result.test_id = test.id 
        JOIN users ON result.user_id = users.id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Вывод данных каждой строки
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["tests"]. "</td>";
        echo "<td>" . $row["username"]. "</td>";
        echo "<td>" . $row["result"]. "</td>";
        echo "<td><button onclick=\"editResult(this)\" data-id=\"" . $row["id"] . "\">Редактировать</button>";
        echo "<button onclick=\"deleteResult(this)\" data-id=\"" . $row["id"] . "\">Удалить</button></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>Нет результатов</td></tr>";
}
$conn->close();
?>
