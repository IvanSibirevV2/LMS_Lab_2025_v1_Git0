<?php
session_start();

// Проверяем, была ли отправлена форма входа
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Проверяем, что поля формы заполнены
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        // Получаем введенные данные
        $admin_username = $_POST["username"];
        $admin_password = $_POST["password"];

        // Подключаемся к базе данных
        $conn = mysqli_connect("localhost", "u2666147_default", "QMqjgV214mm9uHuV", "u2666147_diplommath");

        // Проверяем соединение с базой данных
        if (!$conn) {
            die("Ошибка подключения: " . mysqli_connect_error());
        }
        mysqli_set_charset($conn, 'utf8');

        // Подготавливаем SQL-запрос с использованием подготовленных операторов
        $sql = "SELECT * FROM adminlog WHERE username = ? AND password = ?";
        $stmt = mysqli_prepare($conn, $sql);

        // Привязываем параметры к подготовленному запросу
        mysqli_stmt_bind_param($stmt, "ss", $admin_username, $admin_password);

        // Выполняем подготовленный запрос
        mysqli_stmt_execute($stmt);

        // Получаем результаты запроса
        mysqli_stmt_store_result($stmt);
        $num_rows = mysqli_stmt_num_rows($stmt);

        // Проверяем, есть ли результаты
        if ($num_rows > 0) {
            // Вход успешен, устанавливаем переменную сессии для имени администратора
            $_SESSION["admin_username"] = $admin_username;
            header("Location: adminpanel.php"); // Перенаправляем на страницу админ-панели
            exit();
        } else {
            // Если данные администратора не найдены, выводим сообщение об ошибке
            $error_message = "Неверное имя пользователя или пароль.";
        }

        // Закрываем запрос и соединение с базой данных
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else {
        // Если не все поля заполнены, выводим сообщение об ошибке
        $error_message = "Пожалуйста, заполните все поля.";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в админ-панель | InterestAlg</title>
    <link rel="stylesheet" href="css/loginadmin.css">
</head>
<body>
    <div class="container">
        <div>
            <h2>Вход в админ-панель</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <input type="text" id="username" name="username" placeholder="Логин" required><br>
                <input type="password" id="password" name="password" placeholder="Пароль" required><br>
                <button type="submit">Вход</button>
            </form>
            <?php
            if (isset($error_message)) {
                echo '<div>' . $error_message . '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
