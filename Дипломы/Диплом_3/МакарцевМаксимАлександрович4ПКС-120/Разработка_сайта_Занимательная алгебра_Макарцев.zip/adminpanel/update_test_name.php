<?php
session_start();

if (!isset($_SESSION['admin_username'])) {
    header("Location: loginadmin.php");
    exit();
}

$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $new_test_name = $_POST['new_test_name'];

    $sql = "UPDATE test SET tests = :new_test_name WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':new_test_name', $new_test_name, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo "Название теста успешно обновлено.";
    } else {
        echo "Ошибка при обновлении названия теста.";
    }
}
?>
