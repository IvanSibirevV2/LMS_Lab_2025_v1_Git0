<?php
    $host = 'localhost';
    $dbname = 'u2666147_diplommath';
    $username_db = 'u2666147_default';
    $password_db = 'QMqjgV214mm9uHuV';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin_page.css">
    <title>Admin main | InterestAlg</title>
    
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="../adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
        <div class="container">
            <form class="admin_page-form" action="admin_header.php" method="POST">
                <h1>Изменение блока #header</h1>
                <input class="formInput" name="lecture" type="text" placeholder="Лекционные материалы">
                <textarea class="formmsg" name="test" placeholder="Тестирование"></textarea>
                <textarea class="formmsg" name="feedback" placeholder="Обратная связь"></textarea>
                <textarea class="formmsg" name="about" placeholder="О нас"></textarea>
                <textarea class="formmsg" name="enter" placeholder="Вход"></textarea>
                <textarea class="formmsg" name="registration" placeholder="Регистрация"></textarea>
                    <textarea class="formmsg" name="account" placeholder="Личный кабинет"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin_top.php" method="POST">
                    <h1>Изменение блока #top</h1>
                    <input class="formInput" name="theme" type="text" placeholder="Исследуйте, решайте, преуспевайте">
                    <textarea class="formmsg" name="msg" placeholder="с Занимательной алгеброй легко!"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin_main.php" method="POST">
                    <h1>Изменение блока #main</h1>
                    <input class="formInput" name="first_main" type="text" placeholder="От простых вычислений до глубоких теорем!">
                    <textarea class="formmsg" name="second_main" placeholder="Наш сайт - ваш путь к математическому успеху."></textarea>
                    <textarea class="formmsg" name="third_main" placeholder="Приготовьтесь к открытию новых горизонтов в алгебре с нашим сайтом! У нас вы найдете не только теорию, но и практику, необходимую для достижения ваших целей. Войдите в удивительный мир чисел, где каждый шаг приводит к новому открытию. Не упустите возможность стать частью этого увлекательного путешествия - присоединяйтесь к нам прямо сейчас!"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin_materials.php" method="POST">
                    <h1>Изменение блока #materials</h1>
                    <input class="formInput" name="heading" type="text" placeholder="С нами все проще">
                    <textarea class="formmsg" name="subtitle" placeholder="Все лекционные материалы в одном месте"></textarea>
                    <textarea class="formmsg" name="class7" placeholder="Лекционные материалы для 7 классов"></textarea>
                    <textarea class="formmsg" name="class8" placeholder="Лекционные материалы для 8 классов"></textarea>
                    <textarea class="formmsg" name="class9" placeholder="Лекционные материалы для 9 классов"></textarea>
                    <textarea class="formmsg" name="class10" placeholder="Лекционные материалы для 10 классов"></textarea>
                    <textarea class="formmsg" name="class11" placeholder="Лекционные материалы для 11 классов"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin_tests.php" method="POST">
                    <h1>Изменение блока #tests</h1>
                    <input class="formInput" name="heading" type="text" placeholder="Проверь свою математическую точность!">
                    <textarea class="formmsg" name="subtitle" placeholder="Тестирование, которое оценит и усовершенствует твои навыки!"></textarea>
                    <textarea class="formmsg" name="class7" placeholder="Тестирование для 7 классов"></textarea>
                    <textarea class="formmsg" name="class8" placeholder="Тестирование для 8 классов"></textarea>
                    <textarea class="formmsg" name="class9" placeholder="Тестирование для 9 классов"></textarea>
                    <textarea class="formmsg" name="class10" placeholder="Тестирование для 10 классов"></textarea>
                    <textarea class="formmsg" name="class11" placeholder="Тестирование для 11 классов"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin_contact.php" method="POST">
                    <h1>Изменение блока #contact</h1>
                    <input class="formInput" name="ffeedback" type="text" placeholder="Обратная связь">
                    <textarea class="formmsg" name="namefb" placeholder="Имя"></textarea>
                    <textarea class="formmsg" name="emailfb" placeholder="Ваша почта"></textarea>
                    <textarea class="formmsg" name="messagefb" placeholder="Сообщение"></textarea>
                    <textarea class="formmsg" name="buttonfb" placeholder="Отправить"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin_footer.php" method="POST">
                    <h1>Изменение блока #footer</h1>
                    <input class="formInput" name="b1heading" type="text" placeholder="Возникли вопросы?">
                    <textarea class="formmsg" name="b1subtitle" placeholder="Почта для связи с нами:"></textarea>
                    <textarea class="formmsg" name="b1email" placeholder="interestalg@mail.ru"></textarea>

                    <textarea class="formmsg" name="b2heading" placeholder="Лекционные материалы"></textarea>
                    <textarea class="formmsg" name="b2class7" placeholder="7 класс"></textarea>
                    <textarea class="formmsg" name="b2class8" placeholder="8 класс"></textarea>
                    <textarea class="formmsg" name="b2class9" placeholder="9 класс"></textarea>
                    <textarea class="formmsg" name="b2class10" placeholder="10 класс"></textarea>
                    <textarea class="formmsg" name="b2class11" placeholder="11 класс"></textarea>

                <textarea class="formmsg" name="b3heading" placeholder="Тестирование"></textarea>
                <textarea class="formmsg" name="b3class7" placeholder="7 класс"></textarea>
                <textarea class="formmsg" name="b3class8" placeholder="8 класс"></textarea>
                <textarea class="formmsg" name="b3class9" placeholder="9 класс"></textarea>
                <textarea class="formmsg" name="b3class10" placeholder="10 класс"></textarea>
                <textarea class="formmsg" name="b3class11" placeholder="11 класс"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
    </div>
</body>
</html>
