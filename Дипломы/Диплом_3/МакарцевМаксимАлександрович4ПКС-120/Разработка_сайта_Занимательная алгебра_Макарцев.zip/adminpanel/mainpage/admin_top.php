<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["theme"]=="" || $_POST["msg"]==""){    
    $theme = "Исследуйте, решайте, преуспевайте";
    $message = "с Занимательной алгеброй легко!";
}
else {
    $theme = $_POST["theme"];
    $message = $_POST["msg"];
}
mysqli_query($connect, "UPDATE `adm_top` SET `theme` = '$theme', `message` = '$message' WHERE `adm_top`.`id` = 1;");
