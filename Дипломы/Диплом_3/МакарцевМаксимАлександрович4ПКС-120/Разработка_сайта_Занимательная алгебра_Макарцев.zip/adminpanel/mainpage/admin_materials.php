<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["heading"]=="" || $_POST["subtitle"]=="" || $_POST["class7"]=="" || $_POST["class8"]=="" || $_POST["class9"]=="" || $_POST["class10"]=="" || $_POST["class11"]==""){    
    $heading = "С нами все проще";
    $subtitle = "Все лекционные материалы в одном месте";
    $class7 = "Лекционные материалы для 7 классов";
    $class8 = "Лекционные материалы для 8 классов";
    $class9 = "Лекционные материалы для 9 классов";
    $class10 = "Лекционные материалы для 10 классов";
    $class11 = "Лекционные материалы для 11 классов";
}
else {
    $heading = $_POST["heading"];
    $subtitle = $_POST["subtitle"];
    $class7 = $_POST["class7"];
    $class8 = $_POST["class8"];
    $class9 = $_POST["class9"];
    $class10 = $_POST["class10"];
    $class11 = $_POST["class11"];
}
mysqli_query($connect, "UPDATE `adm_materials` SET `heading` = '$heading', `subtitle` = '$subtitle', `class7` = '$class7', `class8` = '$class8', `class9` = '$class9', `class10` = '$class10', `class11` = '$class11' WHERE `adm_materials`.`id` = 1;");