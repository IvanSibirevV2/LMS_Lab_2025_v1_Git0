<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["b1heading"]=="" || $_POST["b1subtitle"]=="" || $_POST["b1email"]=="" || $_POST["b2heading"]=="" || $_POST["b2class7"]=="" || $_POST["b2class8"]=="" || $_POST["b2class9"]=="" || $_POST["b2class10"]=="" || $_POST["b2class11"]=="" || $_POST["b3heading"]=="" || $_POST["b3class7"]=="" || $_POST["b3class8"]=="" || $_POST["b3class9"]=="" || $_POST["b3class10"]=="" || $_POST["b3class11"]==""){    
    $b1heading = "Возникли вопросы?";
    $b1subtitle = "Почта для связи с нами:";
    $b1email = "interestalg@mail.ru";

    $b2heading = "Лекционные материалы";
    $b2class7 = "7 класс";
    $b2class8 = "8 класс";
    $b2class9 = "9 класс";
    $b2class10 = "10 класс";
    $b2class11 = "11 класс";

    $b3heading = "Тестирование";
    $b3class7 = "7 класс";
    $b3class8 = "8 класс";
    $b3class9 = "9 класс";
    $b3class10 = "10 класс";
    $b3class11 = "11 класс";
}
else {
    $b1heading = $_POST["b1heading"];
    $b1subtitle = $_POST["b1subtitle"];
    $b1email = $_POST["b1email"];

    $b2heading = $_POST["b2heading"];
    $b2class7 = $_POST["b2class7"];
    $b2class8 = $_POST["b2class8"];
    $b2class9 = $_POST["b2class9"];
    $b2class10 = $_POST["b2class10"];
    $b2class11 = $_POST["b2class11"];

    $b3heading = $_POST["b3heading"];
    $b3class7 = $_POST["b3class7"];
    $b3class8 = $_POST["b3class8"];
    $b3class9 = $_POST["b3class9"];
    $b3class10 = $_POST["b3class10"];
    $b3class11 = $_POST["b3class11"];
}
mysqli_query($connect, "UPDATE `adm_footer` SET `b1heading` = '$b1heading', `b1subtitle` = '$b1subtitle', `b1email` = '$b1email', `b2heading` = '$b2heading', `b2class7` = '$b2class7', `b2class8` = '$b2class8', `b2class9` = '$b2class9', `b2class10` = '$b2class10', `b2class11` = '$b2class11', `b3heading` = '$b3heading', `b3class7` = '$b3class7', `b3class8` = '$b3class8', `b3class9` = '$b3class9', `b3class10` = '$b3class10', `b3class11` = '$b3class11' WHERE `adm_footer`.`id` = 1;");