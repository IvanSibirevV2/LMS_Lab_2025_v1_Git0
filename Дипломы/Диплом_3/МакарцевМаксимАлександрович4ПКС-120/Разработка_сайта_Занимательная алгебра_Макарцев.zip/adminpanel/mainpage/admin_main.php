<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["first_main"]=="" || $_POST["second_main"]=="" || $_POST["third_main"]==""){    
    $first = "От простых вычислений до глубоких теорем!";
    $second = "Наш сайт - ваш путь к математическому успеху.";
    $third = "Приготовьтесь к открытию новых горизонтов в алгебре с нашим сайтом! У нас вы найдете не только теорию, но и практику, необходимую для достижения ваших целей. Войдите в удивительный мир чисел, где каждый шаг приводит к новому открытию. Не упустите возможность стать частью этого увлекательного путешествия - присоединяйтесь к нам прямо сейчас!";  
}
else {
    $first = $_POST["first_main"];
    $second = $_POST["second_main"];
    $third = $_POST["third_main"];
}
mysqli_query($connect, "UPDATE `adm_main` SET `first_main` = '$first', `second_main` = '$second', `third_main` = '$third' WHERE `adm_main`.`id` = 1;");