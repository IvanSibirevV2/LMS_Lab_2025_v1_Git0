<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["lecture"]=="" || $_POST["test"]=="" || $_POST["feedback"]=="" || $_POST["about"]=="" || $_POST["enter"]=="" || $_POST["registration"]=="" || $_POST["account"]==""){    
    $lecture = "Лекционные материалы";
    $test = "Тестирование";
    $feedback = "Обратная связь";
    $about = "О нас";
    $enter = "Вход";
    $registration = "Регистрация";
    $account = "Личный кабинет";
}
else {
    $lecture = $_POST["lecture"];
    $test = $_POST["test"];
    $feedback = $_POST["feedback"];
    $about = $_POST["about"];
    $enter = $_POST["enter"];
    $registration = $_POST["registration"];
    $account = $_POST["account"];
}
mysqli_query($connect, "UPDATE `adm_header` SET `lecture` = '$lecture', `test` = '$test', `feedback` = '$feedback', `about` = '$about', `enter` = '$enter', `registration` = '$registration', `account` = '$account' WHERE `adm_header`.`id` = 1;");