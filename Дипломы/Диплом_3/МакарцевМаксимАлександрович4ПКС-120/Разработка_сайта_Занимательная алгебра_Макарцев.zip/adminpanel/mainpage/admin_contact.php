<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["ffeedback"]=="" || $_POST["namefb"]=="" || $_POST["emailfb"]=="" || $_POST["messagefb"]=="" || $_POST["buttonfb"]==""){    
    $ffeedback = "Обратная связь";
    $namefb = "Имя";
    $emailfb = "Ваша почта";
    $messagefb = "Сообщение";
    $buttonfb = "Отправить"; 
}
else {
    $ffeedback = $_POST["ffeedback"];
    $namefb = $_POST["namefb"];
    $emailfb = $_POST["emailfb"];
    $messagefb = $_POST["messagefb"];
    $buttonfb = $_POST["buttonfb"]; 
}
mysqli_query($connect, "UPDATE `adm_contact` SET `ffeedback` = '$ffeedback', `namefb` = '$namefb', `emailfb` = '$emailfb', `messagefb` = '$messagefb', `buttonfb` = '$buttonfb' WHERE `adm_contact`.`id` = 1;");