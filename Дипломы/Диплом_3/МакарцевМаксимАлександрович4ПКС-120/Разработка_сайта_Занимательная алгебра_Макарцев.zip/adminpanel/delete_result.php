<?php
$servername = "localhost";
$username = "u2666147_default";
$password = "QMqjgV214mm9uHuV";
$dbname = "u2666147_diplommath";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
mysqli_set_charset($conn, 'utf8');

$id = $_POST['id'];

$sql = "DELETE FROM test_result WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
