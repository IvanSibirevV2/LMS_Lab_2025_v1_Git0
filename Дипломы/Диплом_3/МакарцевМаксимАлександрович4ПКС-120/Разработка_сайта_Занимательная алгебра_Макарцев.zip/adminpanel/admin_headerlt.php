<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["lecture"]=="" || $_POST["test"]=="" || $_POST["back"]==""){    
    $lecture = "Лекционные материалы";
    $test = "Тестирование";
    $back = "На главную";
}
else {
    $lecture = $_POST["lecture"];
    $test = $_POST["test"];
    $back = $_POST["back"];
}
mysqli_query($connect, "UPDATE `adm_headerlt` SET `lecture` = '$lecture', `test` = '$test', `back` = '$back' WHERE `adm_headerlt`.`id` = 1;");