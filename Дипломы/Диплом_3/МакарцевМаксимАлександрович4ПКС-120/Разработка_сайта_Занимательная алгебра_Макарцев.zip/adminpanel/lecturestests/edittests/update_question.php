<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $question = $_POST['question'];
    $option1 = $_POST['option_1'];
    $option2 = $_POST['option_2'];
    $option3 = $_POST['option_3'];
    $option4 = $_POST['option_4'];
    $option5 = $_POST['option_5'];

    try {
        $pdo->beginTransaction();

        $backupQuery = $pdo->prepare("INSERT INTO test_answers_backup 
                                      SELECT * FROM test_answers WHERE id = :id");
        $backupQuery->execute(['id' => $id]);

        $updateQuery = $pdo->prepare("UPDATE test_answers 
                                      SET question = :question, 
                                          option_1 = :option1, 
                                          option_2 = :option2, 
                                          option_3 = :option3, 
                                          option_4 = :option4, 
                                          option_5 = :option5 
                                      WHERE id = :id");
        $updateQuery->execute([
            'question' => $question, 
            'option1' => $option1, 
            'option2' => $option2, 
            'option3' => $option3, 
            'option4' => $option4, 
            'option5' => $option5, 
            'id' => $id
        ]);

        $pdo->commit();
        header("Location: edittests.php");
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Ошибка обновления: " . $e->getMessage();
    }
}
?>
