<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Создаем директорию для резервных копий, если она не существует
$backupDir = __DIR__ . '/backups';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}

$backupFile = 'backup_' . date('Y-m-d_H-i-s') . '.csv';
$backupPath = $backupDir . '/' . $backupFile;

$query = "SELECT * FROM test_answers";
$statement = $pdo->prepare($query);
$statement->execute();
$results = $statement->fetchAll(PDO::FETCH_ASSOC);

try {
    $file = fopen($backupPath, 'w');
    
    // Заголовки CSV
    $headers = array_keys($results[0]);
    fputcsv($file, $headers);
    
    // Данные CSV
    foreach ($results as $row) {
        fputcsv($file, $row);
    }
    
    fclose($file);
    $message = "Резервная копия успешно создана: $backupFile";
} catch (Exception $e) {
    $message = "Ошибка создания резервной копии: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Резервное копирование | InterestAlg</title>
    <link rel="stylesheet" href="./css/edittests.css">
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="edittests.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
        <h1><?php echo $message; ?></h1>
        <a href="edittests.php">Вернуться к редактированию тестов</a>
    </div>
</body>
</html>
