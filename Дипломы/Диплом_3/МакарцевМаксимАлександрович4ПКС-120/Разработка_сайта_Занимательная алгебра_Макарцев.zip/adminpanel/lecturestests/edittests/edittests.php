<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

$query = "SELECT id, question FROM test_answers";
$questions = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/edittests.css">
    <title>Admin tests | InterestAlg</title>
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="/adminpanel/adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
        <form class="reserv" action="backup_questions.php" method="POST">
            <a href="backup_questions.php" class="reserv" type="submit">Создать резервную копию</a>
        </form>
        <?php foreach ($questions as $question): ?>
            <div class="container">
                <form class="admin_page-form" action="update_question.php" method="POST">
                    <h1>Изменение вопроса: <?php echo htmlspecialchars($question['question']); ?></h1>
                    <input type="hidden" name="id" value="<?php echo $question['id']; ?>">
                    <input class="formInput" name="question" type="text" value="<?php echo htmlspecialchars($question['question']); ?>">
                    
                    <?php
                    $answersQuery = $pdo->prepare("SELECT * FROM test_answers WHERE id = :question_id");
                    $answersQuery->execute(['question_id' => $question['id']]);
                    $answer = $answersQuery->fetch(PDO::FETCH_ASSOC);
                    ?>
                    <textarea class="formmsg" name="option_1" placeholder="Option 1"><?php echo htmlspecialchars($answer['option_1']); ?></textarea>
                    <textarea class="formmsg" name="option_2" placeholder="Option 2"><?php echo htmlspecialchars($answer['option_2']); ?></textarea>
                    <textarea class="formmsg" name="option_3" placeholder="Option 3"><?php echo htmlspecialchars($answer['option_3']); ?></textarea>
                    <textarea class="formmsg" name="option_4" placeholder="Option 4"><?php echo htmlspecialchars($answer['option_4']); ?></textarea>
                    <textarea class="formmsg" name="option_5" placeholder="Option 5"><?php echo htmlspecialchars($answer['option_5']); ?></textarea>
                    
                    <input class="formInput btn" name="" type="submit" value="Сохранить">
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
