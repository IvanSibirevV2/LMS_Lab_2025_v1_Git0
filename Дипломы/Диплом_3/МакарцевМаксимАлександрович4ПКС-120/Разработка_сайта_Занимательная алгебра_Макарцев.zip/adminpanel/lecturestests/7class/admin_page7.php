<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/adminpage7.css">
    <title>Admin main | InterestAlg</title>
    
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="/DiplomSite/adminpanel/adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
    <div class="content">
            <div class="container">
                <form class="admin_page-form" action="admin7_head_part1.php" method="POST">
                    <h1>Изменение блока #container1</h1>
                    <input class="formInput" name="heading" type="text" placeholder="Лекционные материалы для 7 класса">
                    <textarea class="formmsg" name="part1" placeholder="Глава 1. Математические модели"></textarea>
                    <textarea class="formmsg" name="topic1" placeholder="Числовые выражения. Алгебраические выражения"></textarea>
                    <textarea class="formmsg" name="topic2" placeholder="Математический язык"></textarea>
                    <textarea class="formmsg" name="topic3" placeholder="Математические модели реальных ситуаций"></textarea>
                    <textarea class="formmsg" name="topic4" placeholder="Линейное уравнение с одной переменной. Алгоритм решения"></textarea>
                    <textarea class="formmsg" name="topic5" placeholder="Координатная прямая. Числовые промежутки"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin7_part2.php" method="POST">
                    <h1>Изменение блока #container2</h1>
                    <input class="formInput" name="part2" type="text" placeholder="Глава 2. Линейная функция y = kx + b">
                    <textarea class="formmsg" name="topic1" placeholder="Координатная плоскость. Координаты точки"></textarea>
                    <textarea class="formmsg" name="topic2" placeholder="Линейное уравнение ax + by + c = 0. График линейного уравнения"></textarea>
                    <textarea class="formmsg" name="topic3" placeholder="Линейная функция y = kx + b. График линейной функции"></textarea>
                    <textarea class="formmsg" name="topic4" placeholder="Линейная функция y = kx, её свойства"></textarea>
                    <textarea class="formmsg" name="topic5" placeholder="Взаимное расположение графиков линейных функций"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin7_part3.php" method="POST">
                    <h1>Изменение блока #container3</h1>
                    <input class="formInput" name="part3" type="text" placeholder="Глава 3. Решение систем линейных уравнений с двумя переменными">
                    <textarea class="formmsg" name="topic1" placeholder="Понятие системы линейных уравнений с двумя переменными"></textarea>
                    <textarea class="formmsg" name="topic2" placeholder="Решение систем линейных уравнений. Метод подстановки"></textarea>
                    <textarea class="formmsg" name="topic3" placeholder="Решение систем линейных уравнений. Метод сложения"></textarea>
                    <textarea class="formmsg" name="topic4" placeholder="Система линейных уравнений как математическая модель"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>

            <div class="container">
                <form class="admin_page-form" action="admin7_part4.php" method="POST">
                    <h1>Изменение блока #container4</h1>
                    <input class="formInput" name="part4" type="text" placeholder="Глава 4. Свойства степеней с натуральным показателем">
                    <textarea class="formmsg" name="topic1" placeholder="Часто используемые степени"></textarea>
                    <textarea class="formmsg" name="topic2" placeholder="Понятие степени с натуральным показателем"></textarea>
                    <textarea class="formmsg" name="topic3" placeholder="Базовые свойства степеней с натуральным показателем"></textarea>
                    <textarea class="formmsg" name="topic4" placeholder="Умножение и деление степеней с одинаковыми натуральными показателями"></textarea>
                    <textarea class="formmsg" name="topic5" placeholder="Понятие степени с нулевым показателем"></textarea>
                    <input class="formInput btn" name="" type="submit">
                </form>
            </div>
        </div>
    </div>
</body>
</html>
