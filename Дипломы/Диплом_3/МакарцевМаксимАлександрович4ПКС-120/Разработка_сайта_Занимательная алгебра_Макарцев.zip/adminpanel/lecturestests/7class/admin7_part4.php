<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part4"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]=="" || $_POST["topic5"]==""){    
    $part4 = "Глава 4. Свойства степеней с натуральным показателем";
    $topic1 = "Часто используемые степени";
    $topic2 = "Понятие степени с натуральным показателем";
    $topic3 = "Базовые свойства степеней с натуральным показателем";
    $topic4 = "Умножение и деление степеней с одинаковыми натуральными показателями";
    $topic5 = "Понятие степени с нулевым показателем";
}
else {
    $part4 = $_POST["part4"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
    $topic5 = $_POST["topic5"];
}
mysqli_query($connect, "UPDATE `7lecturepart4` SET `part4` = '$part4',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3',`topic4` = '$topic4', `topic5` = '$topic5' WHERE `7lecturepart4`.`id` = 1;");