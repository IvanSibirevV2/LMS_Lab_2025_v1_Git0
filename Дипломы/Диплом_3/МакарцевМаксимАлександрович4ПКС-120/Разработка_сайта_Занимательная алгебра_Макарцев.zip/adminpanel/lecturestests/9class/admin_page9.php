<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/adminpage9.css">
    <title>Admin main | InterestAlg</title>
    
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="/DiplomSite/adminpanel/adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
        <div class="container">
            <form class="admin_page-form" action="admin9_head_part1.php" method="POST">
                <h1>Изменение блока #container1</h1>
                <input class="formInput" name="heading" type="text" placeholder="Лекционные материалы для 9 класса">
                <textarea class="formmsg" name="part1" placeholder="Глава 1. Неравенства и системы неравенств"></textarea>
                <textarea class="formmsg" name="topic1" placeholder="Повторение способов решения линейных и квадратных неравенств"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Решение рациональных неравенств методом интервалов"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Множества и подмножества. Объединение и пересечение множеств"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Системы рациональных неравенств"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin9_part2.php" method="POST">
                <h1>Изменение блока #container2</h1>
                <input class="formInput" name="part2" type="text" placeholder="Глава 2. Системы уравнений. Равносильные преобразования">
                <textarea class="formmsg" name="topic1" placeholder="Понятие системы рациональных уравнений"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Методы решения систем рациональных уравнений"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Использование систем рациональных уравнений для решения задач"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin9_part3.php" method="POST">
                <h1>Изменение блока #container3</h1>
                <input class="formInput" name="part3" type="text" placeholder="Глава 3. Числовые функции. Свойства числовых функций">
                <textarea class="formmsg" name="topic1" placeholder="Определение числовой функции и способы её задания"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Свойства основных функций"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Чётные и нечётные функции. Определение чётности и нечётности"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Степенная функция с натуральным показателем"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin9_part4.php" method="POST">
                <h1>Изменение блока #container4</h1>
                <input class="formInput" name="part4" type="text" placeholder="Глава 4. Числовые последовательности. Прогрессии">
                <textarea class="formmsg" name="topic1" placeholder="Понятие числовой последовательности. Способы задания последовательностей"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Арифметическая прогрессия. Свойства арифметической прогрессии"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Геометрическая прогрессия. Свойства геометрической прогрессии"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
    </div>
</body>
</html>
