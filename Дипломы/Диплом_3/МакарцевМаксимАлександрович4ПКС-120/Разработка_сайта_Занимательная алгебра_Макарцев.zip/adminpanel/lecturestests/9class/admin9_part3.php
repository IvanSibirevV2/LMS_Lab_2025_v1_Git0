<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part3"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]==""){    
    $part3 = "Глава 3. Числовые функции. Свойства числовых функций";
    $topic1 = "Определение числовой функции и способы её задания";
    $topic2 = "Свойства основных функций";
    $topic3 = "Чётные и нечётные функции. Определение чётности и нечётности";
    $topic4 = "Степенная функция с натуральным показателем";
}
else {
    $part3 = $_POST["part3"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
}
mysqli_query($connect, "UPDATE `9lecturepart3` SET `part3` = '$part3',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3',`topic4` = '$topic4' WHERE `9lecturepart3`.`id` = 1;");