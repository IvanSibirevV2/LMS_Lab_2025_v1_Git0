<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part2"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]==""){    
    $part2 = "Глава 2. Системы уравнений. Равносильные преобразования";
    $topic1 = "Понятие системы рациональных уравнений";
    $topic2 = "Методы решения систем рациональных уравнений";
    $topic3 = "Использование систем рациональных уравнений для решения задач";
}
else {
    $part2 = $_POST["part2"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];

}
mysqli_query($connect, "UPDATE `9lecturepart2` SET `part2` = '$part2',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3' WHERE `9lecturepart2`.`id` = 1;");