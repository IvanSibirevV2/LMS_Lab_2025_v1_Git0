<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["heading"]=="" || $_POST["part1"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]=="" || $_POST["topic5"]=="" || $_POST["topic6"]==""){    
    $heading = "Лекционные материалы для 11 класса";
    $part1 = "Глава 1. Логарифмы. Показательная и логарифмическая функции";
    $topic1 = "Свойства показательной функции и её график";
    $topic2 = "Методы решения показательных уравнений";
    $topic3 = "Методы решения показательных неравенств";
    $topic4 = "Понятие логарифма. Основное логарифмическое тождество";
    $topic5 = "Свойства логарифмической функции и её график";
    $topic6 = "Базовые свойства логарифмов";
}
else {
    $heading = $_POST["heading"];
    $part1 = $_POST["part1"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
    $topic5 = $_POST["topic5"];
    $topic6 = $_POST["topic6"];
}
mysqli_query($connect, "UPDATE `11lecturepart1` SET `heading` = '$heading', `part1` = '$part1',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3',`topic4` = '$topic4',`topic5` = '$topic5',`topic6` = '$topic6' WHERE `11lecturepart1`.`id` = 1;");