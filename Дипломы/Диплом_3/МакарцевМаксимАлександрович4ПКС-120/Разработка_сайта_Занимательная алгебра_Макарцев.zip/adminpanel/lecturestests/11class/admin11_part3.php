<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part3"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]==""){    
    $part3 = "Глава 3. Производная. Применение производной для исследования функций";
    $topic1 = "Числовые последовательности и их свойства";
    $topic2 = "Понятие предела числовой последовательности";
    $topic3 = "Как найти сумму бесконечной геометрической прогрессии";
    $topic4 = "Предел функции в точке. Предел функции на бесконечности";
}
else {
    $part3 = $_POST["part3"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
}
mysqli_query($connect, "UPDATE `11lecturepart3` SET `part3` = '$part3',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3',`topic4` = '$topic4' WHERE `11lecturepart3`.`id` = 1;");