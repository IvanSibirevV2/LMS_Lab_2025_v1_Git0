<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part4"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]==""){    
    $part4 = "Глава 4. Первообразная. Неопределённые и определённые интегралы";
    $topic1 = "Понятие первообразной";
    $topic2 = "Неопределённые и определённые интегралы. Методы интегрирования";
    $topic3 = "Вычисление площадей с помощью интегралов";
}
else {
    $part4 = $_POST["part4"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
}
mysqli_query($connect, "UPDATE `11lecturepart4` SET `part4` = '$part4',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3' WHERE `11lecturepart4`.`id` = 1;");