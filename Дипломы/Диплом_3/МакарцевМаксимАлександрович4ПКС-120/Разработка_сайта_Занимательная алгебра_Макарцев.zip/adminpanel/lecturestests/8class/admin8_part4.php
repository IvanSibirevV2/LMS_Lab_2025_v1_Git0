<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part4"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]=="" || $_POST["topic5"]==""){    
    $part4 = "Глава 4. Квадратные уравнения";
    $topic1 = "Какие бывают квадратные уравнения";
    $topic2 = "Способы решения квадратных уравнений";
    $topic3 = "Решение рационального уравнения, сводящегося к квадратному";
    $topic4 = "Использование рациональных уравнений для решения задач";
    $topic5 = "Упрощённая формула для решения квадратного уравнения";
}
else {
    $part4 = $_POST["part4"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
    $topic5 = $_POST["topic5"];
}
mysqli_query($connect, "UPDATE `8lecturepart4` SET `part4` = '$part4',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3',`topic4` = '$topic4', `topic5` = '$topic5' WHERE `8lecturepart4`.`id` = 1;");