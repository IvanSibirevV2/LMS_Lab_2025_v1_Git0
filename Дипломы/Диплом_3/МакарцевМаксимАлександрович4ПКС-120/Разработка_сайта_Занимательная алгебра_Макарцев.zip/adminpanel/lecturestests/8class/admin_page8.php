<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/adminpage8.css">
    <title>Admin main | InterestAlg</title>
    
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="/DiplomSite/adminpanel/adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
        <div class="container">
            <form class="admin_page-form" action="admin8_head_part1.php" method="POST">
                <h1>Изменение блока #container1</h1>
                <input class="formInput" name="heading" type="text" placeholder="Лекционные материалы для 8 класса">
                <textarea class="formmsg" name="part1" placeholder="Глава 1. Алгебраические дроби. Арифметические операции над алгебраическими дробями"></textarea>
                <textarea class="formmsg" name="topic1" placeholder="Понятие алгебраической дроби"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Применение основного свойства алгебраической дроби"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Как складывать и вычитать алгебраические дроби с равными знаменателями"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Как складывать и вычитать алгебраические дроби с разными знаменателями"></textarea>
                <textarea class="formmsg" name="topic5" placeholder="Как умножать, делить и возводить в степень алгебраические дроби"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin8_part2.php" method="POST">
                <h1>Изменение блока #container2</h1>
                <input class="formInput" name="part2" type="text" placeholder="Глава 2. Действительные числа">
                <textarea class="formmsg" name="topic1" placeholder="Множества натуральных чисел, целых чисел, рациональных чисел"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Символы математического языка"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Понятие квадратного корня"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Понятие иррационального числа"></textarea>
                <textarea class="formmsg" name="topic5" placeholder="Множество действительных чисел и его геометрическая модель"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin8_part3.php" method="POST">
                <h1>Изменение блока #container3</h1>
                <input class="formInput" name="part3" type="text" placeholder="Глава 3. Функция y = |x|. Функция квадратного корня y = √x">
                <textarea class="formmsg" name="topic1" placeholder="Модуль действительного числа и его геометрический смысл"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Функция квадратного корня y = √x, её свойства и график"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Базовые свойства квадратных корней"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Преобразование иррациональных выражений"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin8_part4.php" method="POST">
                <h1>Изменение блока #container4</h1>
                <input class="formInput" name="part4" type="text" placeholder="Глава 4. Квадратные уравнения">
                <textarea class="formmsg" name="topic1" placeholder="Какие бывают квадратные уравнения"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Способы решения квадратных уравнений"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Решение рационального уравнения, сводящегося к квадратному"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Использование рациональных уравнений для решения задач"></textarea>
                <textarea class="formmsg" name="topic5" placeholder="Упрощённая формула для решения квадратного уравнения"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
    </div>
</body>
</html>
