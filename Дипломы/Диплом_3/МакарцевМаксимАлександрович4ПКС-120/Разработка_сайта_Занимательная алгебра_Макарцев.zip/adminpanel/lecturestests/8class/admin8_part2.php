<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part2"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]=="" || $_POST["topic5"]==""){    
    $part2 = "Глава 2. Действительные числа";
    $topic1 = "Множества натуральных чисел, целых чисел, рациональных чисел";
    $topic2 = "Символы математического языка";
    $topic3 = "Понятие квадратного корня";
    $topic4 = "Понятие иррационального числа";
    $topic5 = "Множество действительных чисел и его геометрическая модель";
}
else {
    $part2 = $_POST["part2"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
    $topic5 = $_POST["topic5"];
}
mysqli_query($connect, "UPDATE `8lecturepart2` SET `part2` = '$part2',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3',`topic4` = '$topic4', `topic5` = '$topic5' WHERE `8lecturepart2`.`id` = 1;");