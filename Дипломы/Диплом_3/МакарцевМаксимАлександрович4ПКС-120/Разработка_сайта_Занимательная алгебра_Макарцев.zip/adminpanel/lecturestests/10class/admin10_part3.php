<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part3"]=="" || $_POST["topic1"]==""){    
    $part3 = "Глава 3. Что мы знаем о числовых функциях";
    $topic1 = "Обратимая и обратная функции";
}
else {
    $part3 = $_POST["part3"];
    $topic1 = $_POST["topic1"];

}
mysqli_query($connect, "UPDATE `10lecturepart3` SET `part3` = '$part3',`topic1` = '$topic1' WHERE `10lecturepart3`.`id` = 1;");