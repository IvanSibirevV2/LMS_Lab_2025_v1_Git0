<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part2"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]==""){    
    $part2 = "Глава 2. Степени с рациональным показателем. Корни. Степенные функции";
    $topic1 = "Понятие системы рациональных уравнений";
    $topic2 = "Функция корня n-й степени";
    $topic3 = "Свойства корня n-й степени. Преобразование иррациональных выражений";
    $topic4 = "Способы упрощения выражений, содержащих радикалы";
}
else {
    $part2 = $_POST["part2"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
}
mysqli_query($connect, "UPDATE `10lecturepart2` SET `part2` = '$part2',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3', `topic4` = '$topic4' WHERE `10lecturepart2`.`id` = 1;");