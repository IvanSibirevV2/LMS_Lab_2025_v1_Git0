<?php
$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("set names utf8");
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/adminpage10.css">
    <title>Admin 10 class | InterestAlg</title>
    
</head>
<body>
    <header>
        <div class="adminheader">
            <div class="logo">
              <span>InterestAlg</span>
            </div>
            <div class="about">
                <a href="/DiplomSite/adminpanel/adminpanel.php"> < Назад</a>
            </div>
        </div>
    </header>
        <div class="container">
            <form class="admin_page-form" action="admin10_head_part1.php" method="POST">
                <h1>Изменение блока #container1</h1>
                <input class="formInput" name="heading" type="text" placeholder="Лекционные материалы для 10 класса">
                <textarea class="formmsg" name="part1" placeholder="Глава 1. Действительные числа"></textarea>
                <textarea class="formmsg" name="topic1" placeholder="Натуральные числа. Повторение"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Рациональные числа. Повторение"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Иррациональные числа. Повторение"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin10_part2.php" method="POST">
                <h1>Изменение блока #container2</h1>
                <input class="formInput" name="part2" type="text" placeholder="Глава 2. Степени с рациональным показателем. Корни. Степенные функции">
                <textarea class="formmsg" name="topic1" placeholder="Понятие корня n-й степени из действительного числа"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Функция корня n-й степени"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Свойства корня n-й степени. Преобразование иррациональных выражений"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Способы упрощения выражений, содержащих радикалы"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin10_part3.php" method="POST">
                <h1>Изменение блока #container3</h1>
                <input class="formInput" name="part3" type="text" placeholder="Глава 3. Что мы знаем о числовых функциях">
                <textarea class="formmsg" name="topic1" placeholder="Обратимая и обратная функции"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
        <div class="container">
            <form class="admin_page-form" action="admin10_part4.php" method="POST">
                <h1>Изменение блока #container4</h1>
                <input class="formInput" name="part4" type="text" placeholder="Глава 4. Синус и косинус. Тангенс и котангенс. Свойства и графики тригонометрических функций">
                <textarea class="formmsg" name="topic1" placeholder="Числовая окружность на координатной плоскости"></textarea>
                <textarea class="formmsg" name="topic2" placeholder="Нахождение значений синуса и косинуса, тангенса и котангенса"></textarea>
                <textarea class="formmsg" name="topic3" placeholder="Числовой аргумент тригонометрических функций"></textarea>
                <textarea class="formmsg" name="topic4" placeholder="Угловой аргумент тригонометрических функций"></textarea>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
    </div>
</body>
</html>
