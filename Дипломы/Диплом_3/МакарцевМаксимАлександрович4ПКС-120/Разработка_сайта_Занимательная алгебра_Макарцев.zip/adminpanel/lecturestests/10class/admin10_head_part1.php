<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["heading"]=="" || $_POST["part1"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]==""){    
    $heading = "Лекционные материалы для 10 класса";
    $part1 = "Глава 1. Действительные числа";
    $topic1 = "Натуральные числа. Повторение";
    $topic2 = "Рациональные числа. Повторение";
    $topic3 = "Иррациональные числа. Повторение";
}
else {
    $heading = $_POST["heading"];
    $part1 = $_POST["part1"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
}
mysqli_query($connect, "UPDATE `10lecturepart1` SET `heading` = '$heading', `part1` = '$part1',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3' WHERE `10lecturepart1`.`id` = 1;");