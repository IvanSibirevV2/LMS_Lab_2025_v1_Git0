<?php 
$connect = mysqli_connect('localhost', 'u2666147_default', 'QMqjgV214mm9uHuV', 'u2666147_diplommath');
if(!$connect){
  die('Ошибка подключения к БД!');
}
mysqli_set_charset($connect, 'utf8');
print_r($_POST);
if ($_POST["part4"]=="" || $_POST["topic1"]=="" || $_POST["topic2"]=="" || $_POST["topic3"]=="" || $_POST["topic4"]==""){    
    $part4 = "Глава 4. Синус и косинус. Тангенс и котангенс. Свойства и графики тригонометрических функций";
    $topic1 = "Числовая окружность на координатной плоскости";
    $topic2 = "Нахождение значений синуса и косинуса, тангенса и котангенса";
    $topic3 = "Числовой аргумент тригонометрических функций";
    $topic4 = "Угловой аргумент тригонометрических функций";
}
else {
    $part4 = $_POST["part4"];
    $topic1 = $_POST["topic1"];
    $topic2 = $_POST["topic2"];
    $topic3 = $_POST["topic3"];
    $topic4 = $_POST["topic4"];
}
mysqli_query($connect, "UPDATE `10lecturepart4` SET `part4` = '$part4',`topic1` = '$topic1',`topic2` = '$topic2', `topic3` = '$topic3', `topic4` = '$topic4' WHERE `10lecturepart4`.`id` = 1;");