<?php
session_start();

if (!isset($_SESSION['admin_username'])) {
    header("Location: loginadmin.php");
    exit();
}

$host = 'localhost';
$dbname = 'u2666147_diplommath';
$username_db = 'u2666147_default';
$password_db = 'QMqjgV214mm9uHuV';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

$query = "SELECT * FROM users";
$users = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT tr.id, t.tests AS test_name, u.username, tr.grade 
        FROM test_result tr 
        JOIN test t ON tr.test_id = t.id
        JOIN users u ON tr.user_id = u.id";
$results = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/adminpanel.css">
    <title>AdminPanel | InterestAlg</title>
    <script>
        function confirmDelete(userId) {
            if (confirm("Вы уверены, что хотите удалить пользователя?")) {
                window.location.href = "delete_user.php?id=" + userId;
            }
        }

        function deleteResult(button) {
            const id = button.getAttribute('data-id');

            fetch('delete_result.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${id}`
            })
            .then(response => response.text())
            .then(data => {
                console.log(data);
                // Обновляем таблицу, убирая удаленную строку
                const row = button.parentElement.parentElement;
                row.parentElement.removeChild(row);
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
          <span>InterestAlg</span>
        </div>
        <ul>
            <li><a href="#dashboard">Панель управления</a></li>
            <li><a href="#users">Пользователи</a></li>
            <li><a href="#resulttest">Результаты тестов</a></li>
            <li><a href="#settings">Настройки</a></li>
            <li><a class="adminexit" href="logoutadmin.php">Выйти</a></li>
        </ul>
    </div>
    <div class="main-content">
        <header>
            <div class="adminusername">
                <?php
                if (isset($_SESSION['admin_username'])) {
                    echo '<span>Добро пожаловать, ' . htmlspecialchars($_SESSION['admin_username']) . '!</span>';
                } else {
                    echo '<span>Имя администратора не установлено</span>';
                }
                ?>
            </div>
        </header>
        <div class="editpages" id="dashboard">
            <h2>Панель управления</h2>
            <ul>
                <li><a href="./mainpage/admin_page.php">Главная страница</a></li>
                <li><a href="./lecturestests/7class/admin_page7.php">Лекционные материалы 7 класса</a></li>
                <li><a href="./lecturestests/8class/admin_page8.php">Лекционные материалы 8 класса</a></li>
                <li><a href="./lecturestests/9class/admin_page9.php">Лекционные материалы 9 класса</a></li>
                <li><a href="./lecturestests/10class/admin_page10.php">Лекционные материалы 10 класса</a></li>
                <li><a href="./lecturestests/11class/admin_page11.php">Лекционные материалы 11 класса</a></li>
                <li><a href="./lecturestests/edittests/edittests.php">Редактирование тестов</a></li>
                <li><a href="./lecturesall/lecturesalledit.php">Редактирование текста лекций</a></li>
            </ul>
        </div>
        <div class="users" id="users">
            <div class="usershead">
                <h2>Пользователи</h2>
                <a href="add_user.php">+ Добавить пользователя</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Login</th>
                        <th>Email</th>
                        <th style="text-align: center" colspan='2'>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><a href="edit_user.php?id=<?= $user['id'] ?>">Редактировать</a></td>
                        <td><a href="javascript:void(0);" onclick="confirmDelete(<?= $user['id'] ?>)">Удалить</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="editnametest" id="settings">
            <h2>Редактирование тестов</h2>
            <form class="admin_page-form" action="update_test_name.php" method="post">
                <label for="test_id">ID теста:</label>
                <input type="text" id="test_id" name="id" required><br><br>
                <label for="new_test_name">Новое название теста:</label>
                <input type="text" id="new_test_name" name="new_test_name" required><br><br>
                <button class="btn" type="submit">Изменить название теста</button>
            </form>
        </div>
        
        <div class="resulttest" id="resulttest">
            <h2>Результаты тестов</h2>
            <table>
                <thead>
                    <tr>
                        <th>Тест</th>
                        <th>Пользователь</th>
                        <th>Результат</th>
                        <th style="text-align: center" colspan='2'>Действия</th>
                    </tr>
                </thead>
                <tbody id="resultsTable">
                    <?php
                    if (count($results) > 0) {
                        foreach ($results as $row) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["test_name"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["username"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["grade"]) . "</td>";
                            echo "<td><a href='edit_result.php?id=" . htmlspecialchars($row["id"]) . "'>Редактировать</a> ";
                            echo "<td><a onclick=\"deleteResult(this)\" data-id=\"" . htmlspecialchars($row["id"]) . "\">Удалить</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>Нет результатов</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="allheaders">
        <h2>Изменение блока #header для лекционных материалов и тестирования</h2>
            <form class="admin_page-form" action="admin_headerlt.php" method="POST">
                <input class="formInput" name="lecture" type="text" placeholder="Лекционные материалы">
                <textarea class="formmsg" name="test" placeholder="Тестирование"></textarea>
                <textarea class="formmsg" name="back" placeholder="На главную"></textarea><br>
                <input class="formInput btn" name="" type="submit">
            </form>
        </div>
    </div>
</body>
</html>
