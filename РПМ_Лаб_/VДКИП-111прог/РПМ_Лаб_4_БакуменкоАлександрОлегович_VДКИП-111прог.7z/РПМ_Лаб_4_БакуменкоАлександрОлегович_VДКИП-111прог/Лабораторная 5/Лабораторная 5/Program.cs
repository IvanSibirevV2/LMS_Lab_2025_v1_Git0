﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите количество элементов в массиве: ");
        int n = Convert.ToInt32(Console.ReadLine());

        double[] array = new double[n];

        Console.WriteLine("Введите элементы массива:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Элемент {i + 1}: ");
            array[i] = Convert.ToDouble(Console.ReadLine());
        }

        int minIndex = FindIndexOfMin(array);
        Console.WriteLine($"Номер минимального элемента: {minIndex + 1}");

        double sumBetweenNegatives = SumBetweenNegatives(array);
        if (sumBetweenNegatives == double.NaN)
        {
            Console.WriteLine("Недостаточно отрицательных элементов для вычисления суммы.");
        }
        else
        {
            Console.WriteLine($"Сумма элементов между первыми двумя отрицательными: {sumBetweenNegatives}");
        }

        double[] transformedArray = TransformArray(array);
        Console.WriteLine("Преобразованный массив:");
        Console.WriteLine(string.Join(", ", transformedArray));
    }

    static int FindIndexOfMin(double[] array)
    {
        int minIndex = 0;
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] < array[minIndex])
            {
                minIndex = i;
            }
        }
        return minIndex;
    }

    static double SumBetweenNegatives(double[] array)
    {
        int firstNegativeIndex = -1;
        int secondNegativeIndex = -1;

        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] < 0)
            {
                if (firstNegativeIndex == -1)
                {
                    firstNegativeIndex = i;
                }
                else if (secondNegativeIndex == -1)
                {
                    secondNegativeIndex = i;
                    break;
                }
            }
        }

        if (firstNegativeIndex == -1 || secondNegativeIndex == -1)
        {
            return double.NaN;
        }

        double sum = 0;
        for (int i = firstNegativeIndex + 1; i < secondNegativeIndex; i++)
        {
            sum += array[i];
        }
        return sum;
    }

    static double[] TransformArray(double[] array)
    {
        int count = 0;
        foreach (var num in array)
        {
            if (Math.Abs(num) <= 1)
            {
                count++;
            }
        }

        double[] transformed = new double[array.Length];
        int index = 0;

        foreach (var num in array)
        {
            if (Math.Abs(num) <= 1)
            {
                transformed[index++] = num;
            }
        }

        foreach (var num in array)
        {
            if (Math.Abs(num) > 1)
            {
                transformed[index++] = num;
            }
        }

        return transformed;
    }
}