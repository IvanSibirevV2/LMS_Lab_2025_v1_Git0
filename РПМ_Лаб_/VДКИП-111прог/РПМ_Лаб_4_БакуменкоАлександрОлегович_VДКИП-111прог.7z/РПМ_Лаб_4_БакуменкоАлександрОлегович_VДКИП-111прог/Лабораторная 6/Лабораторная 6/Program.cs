﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.Write("Введите количество строк матрицы: ");
        int rows = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите количество столбцов матрицы: ");
        int cols = Convert.ToInt32(Console.ReadLine());

        int[,] matrix = new int[rows, cols];

        Console.WriteLine("Введите элементы матрицы:");
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write($"Элемент [{i + 1}, {j + 1}]: ");
                matrix[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        double[] characteristics = new double[cols];
        for (int j = 0; j < cols; j++)
        {
            characteristics[j] = CalculateColumnCharacteristic(matrix, j);
        }

        var sortedIndices = characteristics.Select((value, index) => new { value, index })
                                           .OrderBy(x => x.value)
                                           .Select(x => x.index)
                                           .ToArray();

        int[,] sortedMatrix = new int[rows, cols];
        for (int j = 0; j < cols; j++)
        {
            int originalColumn = sortedIndices[j];
            for (int i = 0; i < rows; i++)
            {
                sortedMatrix[i, j] = matrix[i, originalColumn];
            }
        }

        Console.WriteLine("Отсортированная матрица:");
        PrintMatrix(sortedMatrix);

        int sumOfNegativeColumns = CalculateSumOfNegativeColumns(sortedMatrix);
        Console.WriteLine($"Сумма элементов в столбцах, содержащих хотя бы один отрицательный элемент: {sumOfNegativeColumns}");
    }

    static double CalculateColumnCharacteristic(int[,] matrix, int col)
    {
        double sum = 0;
        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            if (matrix[i, col] < 0 && matrix[i, col] % 2 != 0)
            {
                sum += Math.Abs(matrix[i, col]);
            }
        }
        return sum;
    }

    static void PrintMatrix(int[,] matrix)
    {
        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }

    static int CalculateSumOfNegativeColumns(int[,] matrix)
    {
        int sum = 0;
        for (int j = 0; j < matrix.GetLength(1); j++)
        {
            bool hasNegative = false;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                if (matrix[i, j] < 0)
                {
                    hasNegative = true;
                    break;
                }
            }
            if (hasNegative)
            {
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    sum += matrix[i, j];
                }
            }
        }
        return sum;
    }
}