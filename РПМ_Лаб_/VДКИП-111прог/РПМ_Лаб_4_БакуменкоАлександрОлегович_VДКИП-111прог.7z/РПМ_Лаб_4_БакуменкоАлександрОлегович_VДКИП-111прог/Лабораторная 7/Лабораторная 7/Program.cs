﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.Write("Введите путь к файлу: ");
        string filePath = Console.ReadLine();

        try
        {

            string text = File.ReadAllText(filePath);
            ExtractAndDisplayQuotes(text);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }

    static void ExtractAndDisplayQuotes(string text)
    {
        int startIndex = 0;
        while ((startIndex = text.IndexOf("\"", startIndex)) != -1)
        {
            int endIndex = text.IndexOf("\"", startIndex + 1);
            if (endIndex == -1) break;

            string quote = text.Substring(startIndex + 1, endIndex - startIndex - 1);
            Console.WriteLine(quote);

            startIndex = endIndex + 1;
        }
    }
}