﻿using System;

class Program
{
    static void Main()
    {
        double x = Math.PI / 4;
        double y = Math.PI / 6;

        double z1 = CalculateZ1(x, y);
        double z2 = CalculateZ2(x, y);

        Console.WriteLine($"z1 = {z1}");
        Console.WriteLine($"z2 = {z2}");
    }

    static double CalculateZ1(double x, double y)
    {
        double cos4x = Math.Pow(Math.Cos(x), 4);
        double sin2y = Math.Pow(Math.Sin(y), 2);
        double sin2x = Math.Pow(Math.Sin(2 * x), 2);

        return cos4x + sin2y + (1.0 / 4.0) * sin2x - 1;
    }

    static double CalculateZ2(double x, double y)
    {
        return Math.Sin(y + x) * Math.Sin(y - x);
    }
}