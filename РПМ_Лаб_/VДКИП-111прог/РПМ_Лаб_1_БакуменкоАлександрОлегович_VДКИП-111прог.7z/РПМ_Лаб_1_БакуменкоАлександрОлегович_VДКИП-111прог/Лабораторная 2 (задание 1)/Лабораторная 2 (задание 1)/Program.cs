﻿using System;

class Program
{
    static void Main()
    {
        double R = 5;

        Console.Write("Введите значение аргумента x: ");
        double x = Convert.ToDouble(Console.ReadLine());

        double y = CalculateFunction(x, R);

        if (double.IsNaN(y))
        {
            Console.WriteLine("Не удалось вычислить значение функции для введенного x.");
        }
        else
        {
            Console.WriteLine($"Значение функции для x = {x} равно: y = {y}");
        }
    }

    static double CalculateFunction(double x, double R)
    {
        double ySemiCircle = -2 + Math.Sqrt(R * R - Math.Pow(x + 8, 2));
        if (x >= -8 - R && x <= -8 + R && ySemiCircle >= -2)
        {
            return ySemiCircle;
        }

        if (x >= 0 && x <= 2)
        {
            return x;
        }

        if (x > 6)
        {
            return (x - 6) * (x - 6);
        }

        return double.NaN;
    }
}