﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите координату x: ");
        double x = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите координату y: ");
        double y = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите значение R: ");
        double R = Convert.ToDouble(Console.ReadLine());

        if (IsInCircle(x, y, R))
        {
            Console.WriteLine("Точка лежит в области закрашенного круга.");
        }
        else if (IsInRectangle(x, y, R))
        {
            Console.WriteLine("Точка лежит в области закрашенного прямоугольника.");
        }
        else
        {
            Console.WriteLine("Точка не лежит в закрашенной области.");
        }
    }

    static bool IsInCircle(double x, double y, double R)
    {
        return (x + R) * (x + R) + (y - R) * (y - R) < R * R && y > 0 && x < 0;
    }

    static bool IsInRectangle(double x, double y, double R)
    {
        return x > 0 && x < 2 * R && y > -R && y < 0;
    }
}