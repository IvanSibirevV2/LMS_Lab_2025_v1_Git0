﻿using System;

class Program
{
    static void Main()
    {
        double xStart = 0;
        double xEnd = 2;
        double dx = 0.5;
        double epsilon = 0.0001;

        Console.WriteLine("--------------------------------------------------------");
        Console.WriteLine("|     X      |      f(X)       |     N                |");
        Console.WriteLine("--------------------------------------------------------");

        for (double x = xStart; x <= xEnd; x += dx)
        {
            double functionValue = CalculateExponential(x, epsilon, out int termsCount);
            Console.WriteLine($"| {x,10:F2} | {functionValue,15:F6} | {termsCount,19} |");
        }

        Console.WriteLine("--------------------------------------------------------");
    }

    static double CalculateExponential(double x, double epsilon, out int termsCount)
    {
        double sum = 1.0;
        double term = 1.0;
        termsCount = 1;

        for (int n = 1; Math.Abs(term) > epsilon; n++)
        {
            term *= x / n;
            sum += term;
            termsCount++;
        }

        return sum;
    }
}