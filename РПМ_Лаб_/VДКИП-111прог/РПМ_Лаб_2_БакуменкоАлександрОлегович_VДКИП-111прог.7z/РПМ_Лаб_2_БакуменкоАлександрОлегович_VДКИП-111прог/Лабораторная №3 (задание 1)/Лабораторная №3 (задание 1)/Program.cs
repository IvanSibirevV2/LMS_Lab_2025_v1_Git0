﻿using System;

class Program
{
    static void Main()
    {
        double R = 5;
        double xStart = -10;
        double xEnd = 10;
        double dr = 1;

        Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("|     X      |      Y                           |");
        Console.WriteLine("-------------------------------------------------");

        for (double x = xStart; x <= xEnd; x += dr)
        {
            double y = CalculateFunction(x, R);
            Console.WriteLine($"| {x,7:F2} | {y,30:F2} |");
        }

        Console.WriteLine("-------------------------------------------------");
    }

    static double CalculateFunction(double x, double R)
    {
        if (x >= -10 && x <= -6)
        {
            return -2 - Math.Sqrt(R * R - (x + 8) * (x + 8));
        }
        else if (x >= -2 && x <= 2)
        {
            return x;
        }
        else if (x >= 6)
        {
            return (x - 6) * (x - 6);
        }
        else
        {
            return double.NaN;
        }
    }
}
