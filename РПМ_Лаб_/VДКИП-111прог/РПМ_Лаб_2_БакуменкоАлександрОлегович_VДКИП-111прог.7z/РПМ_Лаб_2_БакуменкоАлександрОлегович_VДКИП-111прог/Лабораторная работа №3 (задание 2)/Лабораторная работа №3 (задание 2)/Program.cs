﻿using System;

class Program
{
    static void Main()
    {
        const double R = 5;

        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine($"Введите координаты выстрела {i}:");
            Console.Write("x: ");
            double x = Convert.ToDouble(Console.ReadLine());

            Console.Write("y: ");
            double y = Convert.ToDouble(Console.ReadLine());

            if (IsInCircle(x, y, R))
            {
                Console.WriteLine("Попадание в круг!");
            }
            else if (IsInRectangle(x, y, R))
            {
                Console.WriteLine("Попадание в прямоугольник!");
            }
            else
            {
                Console.WriteLine("Мимо!");
            }
        }
    }

    static bool IsInCircle(double x, double y, double R)
    {
        return (x - R) * (x - R) + (y - R) * (y - R) <= R * R && x > 0 && y > 0;
    }

    static bool IsInRectangle(double x, double y, double R)
    {
        return x > 0 && x < 2 * R && y < 0 && y > -R;
    }
}