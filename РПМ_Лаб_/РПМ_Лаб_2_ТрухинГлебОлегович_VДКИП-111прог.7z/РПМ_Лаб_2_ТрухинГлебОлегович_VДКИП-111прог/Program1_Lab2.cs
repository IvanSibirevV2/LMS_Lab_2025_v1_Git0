﻿using System;

class Program
{
    // Функция, заданная графически (пример)
    static double CalculateFunction(double x)
    {
        if (x < -2)
        {
            return Math.Pow(x, 2); // Ветвь 1: x < -2
        }
        else if (x >= -2 && x < 0)
        {
            return Math.Abs(x);    // Ветвь 2: -2 <= x < 0
        }
        else if (x >= 0 && x < 3)
        {
            return Math.Sqrt(x);  // Ветвь 3: 0 <= x < 3
        }
        else
        {
            return x - 3;         // Ветвь 4: x >= 3
        }
    }

    static void Main()
    {
        // Задаем интервал и шаг, охватывающие все ветви функции
        double start = -3;    // Начало интервала
        double end = 4;       // Конец интервала
        double step = 0.5;    // Шаг

        Console.WriteLine("Таблица значений функции");
        Console.WriteLine("------------------------");
        Console.WriteLine("|   x   |   f(x)   |");
        Console.WriteLine("------------------------");

        for (double x = start; x <= end; x += step)
        {
            double y = CalculateFunction(x);
            Console.WriteLine($"| {x,5:F1} | {y,8:F3} |");
        }

        Console.WriteLine("------------------------");
        Console.WriteLine("* Проверены все ветви функции:");
        Console.WriteLine("  1) x < -2");
        Console.WriteLine("  2) -2 <= x < 0");
        Console.WriteLine("  3) 0 <= x < 3");
        Console.WriteLine("  4) x >= 3");
    }
}
