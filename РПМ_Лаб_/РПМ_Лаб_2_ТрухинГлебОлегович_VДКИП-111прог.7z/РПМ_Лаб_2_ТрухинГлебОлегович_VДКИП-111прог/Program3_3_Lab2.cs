﻿using System;

class TaylorSeriesExp
{
    static void Main()
    {
        // Параметры вычисления
        double start = 0.1;    // Начало интервала
        double end = 1.0;      // Конец интервала
        double step = 0.1;     // Шаг
        double epsilon = 1e-6; // Точность вычислений

        Console.WriteLine("Таблица значений функции e^x через ряд Тейлора");
        Console.WriteLine("Ряд: 1 + x + x²/2! + x³/3! + x⁴/4! + ...");
        Console.WriteLine("--------------------------------------------------");
        Console.WriteLine("|  x   |    Приближенное   | Членов |   Точное   |");
        Console.WriteLine("|      |      значение      |  ряда  |  значение  |");
        Console.WriteLine("--------------------------------------------------");

        for (double x = start; x <= end + step / 2; x += step)
        {
            double sum = 0;
            double term;
            int n = 0;
            double factorial = 1;

            do
            {
                // Вычисляем n-й член ряда
                if (n == 0)
                {
                    term = 1; // Первый член ряда (x^0/0! = 1)
                }
                else
                {
                    factorial *= n; // Вычисляем факториал итеративно
                    term = Math.Pow(x, n) / factorial;
                }

                sum += term;
                n++;
            } while (Math.Abs(term) > epsilon);

            double exactValue = Math.Exp(x);

            Console.WriteLine($"| {x,4:F1} | {sum,16:F10} | {n,6} | {exactValue,10:F6} |");
        }

        Console.WriteLine("--------------------------------------------------");
        Console.WriteLine($"Точность вычислений: {epsilon}");
        Console.WriteLine("Примечание: Ряд сходится для всех x ∈ ℝ");
    }
}
