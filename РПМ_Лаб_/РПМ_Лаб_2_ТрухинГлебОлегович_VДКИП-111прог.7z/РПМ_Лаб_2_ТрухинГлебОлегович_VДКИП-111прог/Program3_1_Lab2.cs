﻿using System;

class TaylorSeries
{
    static void Main()
    {
        // Параметры вычислений
        double start = 1.5;   // Начало интервала (x > 1)
        double end = 3.0;     // Конец интервала
        double step = 0.1;    // Шаг
        double epsilon = 1e-6; // Точность вычислений

        Console.WriteLine("Таблица значений функции ln((x+1)/(x-1))");
        Console.WriteLine("Разложение в ряд Тейлора: 2*(1/x + 1/(3x^3) + 1/(5x^5) + ...)");
        Console.WriteLine("-------------------------------------------------------------");
        Console.WriteLine("|   x   |  Значение функции | Членов ряда | Стандартное значение |");
        Console.WriteLine("-------------------------------------------------------------");

        for (double x = start; x <= end; x += step)
        {
            // Вычисление через ряд Тейлора
            double sum = 0;
            double term;
            int n = 0;

            do
            {
                int denominator = 2 * n + 1;
                term = 1.0 / (denominator * Math.Pow(x, denominator));
                sum += term;
                n++;
            } while (Math.Abs(term) > epsilon);

            double taylorValue = 2 * sum;
            double standardValue = Math.Log((x + 1) / (x - 1));

            Console.WriteLine($"| {x,5:F2} | {taylorValue,17:F10} | {n,10} | {standardValue,19:F10} |");
        }

        Console.WriteLine("-------------------------------------------------------------");
        Console.WriteLine($"Точность вычислений: {epsilon}");
    }
}
