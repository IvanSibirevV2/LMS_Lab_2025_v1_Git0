﻿using System;

class TargetPractice
{
    static void Main()
    {
        const double targetRadius = 10.0; // Радиус мишени
        int hits = 0; // Счетчик попаданий

        Console.WriteLine("Введите координаты 10 выстрелов (x y):");

        for (int i = 1; i <= 10; i++)
        {
            Console.Write($"Выстрел {i}: ");
            string[] input = Console.ReadLine().Split();

            // Парсинг координат с проверкой ввода
            if (input.Length != 2 || !double.TryParse(input[0], out double x) || !double.TryParse(input[1], out double y))
            {
                Console.WriteLine("Ошибка ввода! Введите две координаты через пробел.");
                i--; // Повторяем ввод для этого выстрела
                continue;
            }

            // Проверка попадания
            double distance = Math.Sqrt(x * x + y * y);
            bool isHit = distance <= targetRadius;

            if (isHit)
            {
                hits++;
                Console.WriteLine($"Попадание! (Расстояние до центра: {distance:F2})");
            }
            else
            {
                Console.WriteLine($"Промах. (Расстояние до центра: {distance:F2})");
            }
        }

        // Итоговые результаты
        Console.WriteLine("\nРезультаты стрельбы:");
        Console.WriteLine($"Всего попаданий: {hits}");
        Console.WriteLine($"Процент попаданий: {hits * 10}%");

        // Дополнительная оценка
        if (hits >= 8)
            Console.WriteLine("Отличный результат!");
        else if (hits >= 5)
            Console.WriteLine("Хороший результат");
        else
            Console.WriteLine("Требуется больше практики");
    }
}
