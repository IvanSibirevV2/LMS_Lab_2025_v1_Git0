﻿using System;

class BinomialCoefficient
{
    // Вычисление биномиального коэффициента
    static long Calculate(int n, int k)
    {
        if (k < 0 || k > n)
            return 0;

        if (k > n - k) // Оптимизация: используем симметрию C(n,k) = C(n,n-k)
            k = n - k;

        long result = 1;
        for (int i = 1; i <= k; i++)
        {
            result *= n - k + i;
            result /= i;
        }

        return result;
    }

    static void Main()
    {
        Console.Write("Введите n: ");
        int n = int.Parse(Console.ReadLine());

        Console.Write("Введите k: ");
        int k = int.Parse(Console.ReadLine());

        try
        {
            long c = Calculate(n, k);
            Console.WriteLine($"C({n},{k}) = {c}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}