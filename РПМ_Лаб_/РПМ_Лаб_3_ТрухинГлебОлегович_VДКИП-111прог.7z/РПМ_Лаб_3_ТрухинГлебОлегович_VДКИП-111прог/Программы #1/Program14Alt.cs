﻿using System;
using System.Collections.Generic;

class DivideAndConquerMax
{
    struct Range
    {
        public int Left;
        public int Right;
    }

    static int FindMaxIterative(int[] arr)
    {
        Stack<Range> stack = new Stack<Range>();
        Stack<int> maxStack = new Stack<int>();

        stack.Push(new Range { Left = 0, Right = arr.Length - 1 });

        while (stack.Count > 0)
        {
            Range current = stack.Pop();

            if (current.Left == current.Right)
            {
                maxStack.Push(arr[current.Left]);
            }
            else
            {
                int mid = (current.Left + current.Right) / 2;

                stack.Push(new Range { Left = current.Left, Right = mid });
                stack.Push(new Range { Left = mid + 1, Right = current.Right });
            }
        }

        // Собираем результаты
        while (maxStack.Count > 1)
        {
            int a = maxStack.Pop();
            int b = maxStack.Pop();
            maxStack.Push(Math.Max(a, b));
        }

        return maxStack.Pop();
    }

    static void Main()
    {
        int[] arr = { 3, 7, 2, 9, 5, 1, 8, 4 };

        int max = FindMaxIterative(arr);

        Console.WriteLine($"Максимальный элемент: {max}");
    }
}