﻿using System;

class Fibonacci
{
    // Рекурсивный метод
    static int FibRecursive(int n)
    {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return FibRecursive(n - 1) + FibRecursive(n - 2);
    }

    static void Main()
    {
        Console.Write("Введите n: ");
        int n = int.Parse(Console.ReadLine());

        Console.WriteLine($"Fb({n}) = {FibRecursive(n)}");
    }
}
