﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] numbers = { 12, 21, 31, 41, 15, 61, 17, 81, 91, 100 };

        Console.WriteLine("Исходный массив:");
        Console.WriteLine(string.Join(", ", numbers));

        for (int i = 0; i < numbers.Length; i++)
        {
            string numStr = numbers[i].ToString();

            // Проверяем, содержит ли число цифру 1
            if (numStr.Contains('1'))
            {
                // Заменяем все цифры, соседствующие с 1, нулями
                char[] digits = numStr.ToCharArray();
                bool[] toReplace = new bool[digits.Length];

                // Помечаем позиции для замены
                for (int j = 0; j < digits.Length; j++)
                {
                    if (digits[j] == '1')
                    {
                        if (j > 0) toReplace[j - 1] = true;
                        if (j < digits.Length - 1) toReplace[j + 1] = true;
                    }
                }

                // Выполняем замену
                for (int j = 0; j < digits.Length; j++)
                {
                    if (toReplace[j] && digits[j] != '1')
                    {
                        digits[j] = '0';
                    }
                }

                numbers[i] = int.Parse(new string(digits));
            }
        }

        Console.WriteLine("\nРезультат:");
        Console.WriteLine(string.Join(", ", numbers));
    }
}