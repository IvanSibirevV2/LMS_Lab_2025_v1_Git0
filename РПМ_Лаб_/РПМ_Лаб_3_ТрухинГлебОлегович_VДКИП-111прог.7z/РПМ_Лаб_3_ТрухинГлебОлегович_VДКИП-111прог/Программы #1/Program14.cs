﻿using System;

class DivideAndConquerMax
{
    // Рекурсивный метод поиска максимума
    static int FindMax(int[] arr, int left, int right)
    {
        // Базовый случай: если остался один элемент
        if (left == right)
            return arr[left];

        // Разделяем массив пополам
        int mid = (left + right) / 2;

        // Рекурсивно находим максимумы в каждой половине
        int maxLeft = FindMax(arr, left, mid);
        int maxRight = FindMax(arr, mid + 1, right);

        // Возвращаем наибольший из двух
        return Math.Max(maxLeft, maxRight);
    }

    static void Main()
    {
        int[] arr = { 3, 7, 2, 9, 5, 1, 8, 4 };

        int max = FindMax(arr, 0, arr.Length - 1);

        Console.WriteLine($"Максимальный элемент: {max}");
    }
}