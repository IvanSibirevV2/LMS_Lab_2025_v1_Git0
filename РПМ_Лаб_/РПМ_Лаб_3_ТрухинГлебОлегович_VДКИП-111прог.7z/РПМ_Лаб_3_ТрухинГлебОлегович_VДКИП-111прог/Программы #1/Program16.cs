﻿using System;

class ProductCalculator
{
    static double CalculateProduct(int n)
    {
        if (n < 2 || n % 2 != 0)
            throw new ArgumentException("n должно быть четным числом ≥ 2");

        double product = 1.0;

        for (int i = 1; i <= n / 2; i++)
        {
            int numerator = 2 * i;
            product *= (double)numerator / (numerator - 1) * (double)numerator / (numerator + 1);
        }

        return product;
    }

    static void Main()
    {
        Console.Write("Введите четное n ≥ 2: ");
        int n = int.Parse(Console.ReadLine());

        try
        {
            double result = CalculateProduct(n);
            Console.WriteLine($"Произведение для n={n}: {result:F10}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}