﻿using System;

class MaxElementFinder
{
    static int FindMaxIterative(int[] arr)
    {
        int max = arr[0];
        for (int i = 1; i < arr.Length; i++)
        {
            max = Math.Max(max, arr[i]);
        }
        return max;
    }

    static void Main()
    {
        int[] arr = { 3, 7, 2, 9, 5, 1, 8 };
        int max = FindMaxIterative(arr);

        Console.WriteLine($"Максимальный элемент: {max}");
    }
}