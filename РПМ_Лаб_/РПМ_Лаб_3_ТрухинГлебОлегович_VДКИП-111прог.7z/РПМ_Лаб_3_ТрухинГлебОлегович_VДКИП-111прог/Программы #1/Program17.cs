﻿using System;

class FastExponentiation
{
    // Рекурсивный метод быстрого возведения в степень
    static double Power(double x, int n)
    {
        if (n == 0) return 1;
        if (n < 0) return 1 / Power(x, -n);  // Обработка отрицательных степеней

        double halfPower = Power(x, n / 2);

        if (n % 2 == 0)
            return halfPower * halfPower;     // Чётная степень
        else
            return x * halfPower * halfPower; // Нечётная степень
    }

    static void Main()
    {
        Console.Write("Введите x: ");
        double x = double.Parse(Console.ReadLine());

        Console.Write("Введите степень n: ");
        int n = int.Parse(Console.ReadLine());

        try
        {
            double result = Power(x, n);
            Console.WriteLine($"{x}^{n} = {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}