﻿using System;

class ContinuedFractionCalculator
{
    static double CalculateY(int n)
    {
        if (n < 1)
            throw new ArgumentException("n должно быть положительным числом");

        double result = 1.0 / 2; // Начинаем с 1/2 (последний элемент)

        // Идем от 1 до n
        for (int i = 1; i <= n; i++)
        {
            result = 1.0 / (i + result);
        }

        return result;
    }

    static void Main()
    {
        Console.Write("Введите n: ");
        int n = int.Parse(Console.ReadLine());

        try
        {
            double result = CalculateY(n);
            Console.WriteLine($"y({n}) = {result:F10}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}