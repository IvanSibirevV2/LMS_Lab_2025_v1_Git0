﻿using System;

class ContinuedFraction
{
    static double CalculateY(int n)
    {
        double result = 1.0; // Начинаем с последнего элемента (1/1)

        for (int i = 1; i < n; i++)
        {
            result = 1.0 / (1.0 + result);
        }

        return result;
    }

    static void Main()
    {
        Console.Write("Введите глубину цепной дроби n: ");
        int n = int.Parse(Console.ReadLine());

        if (n < 1)
        {
            Console.WriteLine("n должно быть положительным числом");
            return;
        }

        double y = CalculateY(n);
        Console.WriteLine($"y({n}) = {y:F15}");
        Console.WriteLine($"При n→∞ золотое сечение: {(Math.Sqrt(5) - 1) / 2:F15}");
    }
}