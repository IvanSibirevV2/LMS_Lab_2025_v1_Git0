﻿using System;

class SquareRootCalculator
{
    // Метод вычисления квадратного корня по итерационной формуле
    static double SqrtNewton(double a, double epsilon = 1e-10)
    {
        if (a < 0)
            throw new ArgumentException("Число должно быть неотрицательным.");

        if (a == 0)
            return 0;

        double x_prev = 0.5 * (1 + a); // Начальное приближение
        double x_next;

        while (true)
        {
            x_next = 0.5 * (x_prev + a / x_prev);

            // Проверка достижения точности
            if (Math.Abs(x_next - x_prev) < epsilon)
                break;

            x_prev = x_next;
        }

        return x_next;
    }

    static void Main()
    {
        Console.Write("Введите число a: ");
        double a = double.Parse(Console.ReadLine());

        try
        {
            double sqrt = SqrtNewton(a);
            Console.WriteLine($"Квадратный корень из {a} равен: {sqrt:F10}");
            Console.WriteLine($"Проверка: {sqrt * sqrt:F10} ≈ {a}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}