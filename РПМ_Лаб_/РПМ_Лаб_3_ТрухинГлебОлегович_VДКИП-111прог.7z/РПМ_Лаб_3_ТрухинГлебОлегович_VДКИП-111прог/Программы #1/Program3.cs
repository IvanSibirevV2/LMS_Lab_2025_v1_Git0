﻿using System;

class BinarySearch
{
    // Итерационный метод двоичного поиска
    static int BinarySearchIterative(int[] arr, int target)
    {
        int left = 0;
        int right = arr.Length - 1;

        while (left <= right)
        {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target)
                return mid;  // Элемент найден, возвращаем индекс
            else if (arr[mid] < target)
                left = mid + 1;  // Ищем в правой половине
            else
                right = mid - 1; // Ищем в левой половине
        }

        return -1;  // Элемент не найден
    }

    static void Main()
    {
        int[] arr = { 2, 5, 8, 12, 16, 23, 38, 56, 72, 91 };
        Console.Write("Введите искомое число: ");
        int target = int.Parse(Console.ReadLine());

        int result = BinarySearchIterative(arr, target);

        if (result == -1)
            Console.WriteLine("Элемент не найден в массиве.");
        else
            Console.WriteLine($"Элемент найден на позиции: {result + 1}");
    }
}
