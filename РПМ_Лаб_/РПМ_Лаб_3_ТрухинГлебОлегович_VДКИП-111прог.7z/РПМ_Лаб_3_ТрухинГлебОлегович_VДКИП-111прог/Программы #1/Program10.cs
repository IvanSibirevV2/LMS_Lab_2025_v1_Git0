﻿using System;
using System.Collections.Generic;

class AckermannFunction
{
    static Dictionary<(int, int), int> cache = new Dictionary<(int, int), int>();

    static int AckermannMemo(int m, int n)
    {
        if (cache.TryGetValue((m, n), out int result))
            return result;

        if (m == 0)
            result = n + 1;
        else if (n == 0)
            result = AckermannMemo(m - 1, 1);
        else
            result = AckermannMemo(m - 1, AckermannMemo(m, n - 1));

        cache[(m, n)] = result;
        return result;
    }

    static void Main()
    {
        Console.Write("Введите m: ");
        int m = int.Parse(Console.ReadLine());

        Console.Write("Введите n: ");
        int n = int.Parse(Console.ReadLine());

        Console.WriteLine($"A({m}, {n}) = {AckermannMemo(m, n)}");
    }
}