﻿using System;

class BinarySearch
{
    // Рекурсивный метод двоичного поиска
    static int BinarySearchRecursive(int[] arr, int target, int left, int right)
    {
        if (left > right)
            return -1;  // Базовый случай: элемент не найден

        int mid = left + (right - left) / 2;

        if (arr[mid] == target)
            return mid;  // Элемент найден
        else if (arr[mid] < target)
            return BinarySearchRecursive(arr, target, mid + 1, right);  // Ищем в правой половине
        else
            return BinarySearchRecursive(arr, target, left, mid - 1);   // Ищем в левой половине
    }

    static void Main()
    {
        int[] arr = { 2, 5, 8, 12, 16, 23, 38, 56, 72, 91 };
        Console.Write("Введите искомое число: ");
        int target = int.Parse(Console.ReadLine());

        int result = BinarySearchRecursive(arr, target, 0, arr.Length - 1);

        if (result == -1)
            Console.WriteLine("Элемент не найден в массиве.");
        else
            Console.WriteLine($"Элемент найден на позиции: {result + 1}");
    }
}
