﻿using System;
using System.Text;

class Program
{
    // Итерационная функция для перевода числа в p-ичную систему
    static string ConvertIterative(int N, int p)
    {
        if (N == 0) return "0";

        StringBuilder result = new StringBuilder();
        while (N > 0)
        {
            result.Append(N % p);
            N /= p;
        }

        // Разворачиваем строку, так как остатки записывались в обратном порядке
        char[] charArray = result.ToString().ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }

    static void Main()
    {
        Console.Write("Введите число N: ");
        int N = int.Parse(Console.ReadLine());

        Console.Write("Введите основание p (2 ≤ p < 10): ");
        int p = int.Parse(Console.ReadLine());

        if (p < 2 || p >= 10)
        {
            Console.WriteLine("Основание должно быть от 2 до 9!");
            return;
        }

        Console.WriteLine("Итерационный метод: " + ConvertIterative(N, p));
    }
}
