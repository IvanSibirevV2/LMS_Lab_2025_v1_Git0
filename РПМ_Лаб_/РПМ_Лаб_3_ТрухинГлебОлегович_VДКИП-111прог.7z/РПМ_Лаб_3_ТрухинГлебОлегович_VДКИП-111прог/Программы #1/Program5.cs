﻿using System;

class EuclideanAlgorithm
{
    // Итерационный метод нахождения НОД
    static int GCDIterative(int m, int n)
    {
        while (n != 0)
        {
            int remainder = m % n;
            m = n;
            n = remainder;
        }
        return m;
    }

    static void Main()
    {
        Console.Write("Введите число M: ");
        int m = int.Parse(Console.ReadLine());

        Console.Write("Введите число N: ");
        int n = int.Parse(Console.ReadLine());

        int gcd = GCDIterative(m, n);

        Console.WriteLine($"Наибольший общий делитель чисел {m} и {n} равен: {gcd}");
    }
}
