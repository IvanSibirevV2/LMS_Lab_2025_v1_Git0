﻿using System;
using System.Collections.Generic;

class AckermannFunction
{
    static int AckermannIterative(int m, int n)
    {
        Stack<int> stack = new Stack<int>();
        stack.Push(m);
        stack.Push(n);

        while (stack.Count > 1)
        {
            n = stack.Pop();
            m = stack.Pop();

            if (m == 0)
                stack.Push(n + 1);
            else if (n == 0)
            {
                stack.Push(m - 1);
                stack.Push(1);
            }
            else
            {
                stack.Push(m - 1);
                stack.Push(m);
                stack.Push(n - 1);
            }
        }

        return stack.Pop();
    }

    static void Main()
    {
        Console.Write("Введите m: ");
        int m = int.Parse(Console.ReadLine());

        Console.Write("Введите n: ");
        int n = int.Parse(Console.ReadLine());

        Console.WriteLine($"A({m}, {n}) = {AckermannIterative(m, n)}");
    }
}