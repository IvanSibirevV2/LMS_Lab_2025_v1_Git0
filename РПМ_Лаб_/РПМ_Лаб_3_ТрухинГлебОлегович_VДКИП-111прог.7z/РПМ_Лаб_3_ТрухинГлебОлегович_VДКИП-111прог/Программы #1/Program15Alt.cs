﻿using System;

class ContinuedFractionCalculator
{
    static double CalculateYRecursive(int current, int n)
    {
        if (current == n)
            return 1.0 / (n + 1.0 / 2); // Базовый случай

        return 1.0 / (current + CalculateYRecursive(current + 1, n));
    }

    static void Main()
    {
        Console.Write("Введите n: ");
        int n = int.Parse(Console.ReadLine());

        try
        {
            double result = CalculateYRecursive(1, n);
            Console.WriteLine($"y({n}) = {result:F10}");
        }
        catch (StackOverflowException)
        {
            Console.WriteLine("Слишком большая глубина рекурсии для этого n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}