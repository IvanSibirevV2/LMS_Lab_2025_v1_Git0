﻿using System;

class EuclideanAlgorithm
{
    // Рекурсивный метод нахождения НОД
    static int GCDRecursive(int m, int n)
    {
        if (n == 0)
            return m;
        return GCDRecursive(n, m % n);
    }

    static void Main()
    {
        Console.Write("Введите число M: ");
        int m = int.Parse(Console.ReadLine());

        Console.Write("Введите число N: ");
        int n = int.Parse(Console.ReadLine());

        int gcd = GCDRecursive(m, n);

        Console.WriteLine($"Наибольший общий делитель чисел {m} и {n} равен: {gcd}");
    }
}
