﻿using System;

class Program
{
    // Исходная функция f(x) = 7 * sin²(x)
    static double Function(double x)
    {
        return 7 * Math.Pow(Math.Sin(x), 2);
    }

    // Метод дихотомии для поиска минимума
    static double FindMinimumDichotomy(double a, double b, double epsilon)
    {
        double delta = epsilon / 2; // Малое смещение для сравнения точек

        while (b - a > epsilon)
        {
            double c = (a + b) / 2;
            double x1 = c - delta;
            double x2 = c + delta;

            if (Function(x1) < Function(x2))
                b = x2;
            else
                a = x1;
        }

        return (a + b) / 2; // Возвращаем середину итогового отрезка
    }

    static void Main()
    {
        double a = 2.0;   // Начало отрезка
        double b = 6.0;   // Конец отрезка
        double epsilon = 0.01; // Точность

        double minPoint = FindMinimumDichotomy(a, b, epsilon);
        double minValue = Function(minPoint);

        Console.WriteLine($"Минимум функции находится в точке: x = {minPoint:F4}");
        Console.WriteLine($"Значение функции в минимуме: f(x) = {minValue:F4}");
    }
}