﻿using System;

class ProductCalculator
{
    static double CalculateProductRecursive(int pairsLeft, int current)
    {
        if (pairsLeft == 0)
            return 1.0;

        int numerator = 2 * current;
        double pair = (double)numerator / (numerator - 1) * (double)numerator / (numerator + 1);

        return pair * CalculateProductRecursive(pairsLeft - 1, current + 1);
    }

    static void Main()
    {
        Console.Write("Введите четное n ≥ 2: ");
        int n = int.Parse(Console.ReadLine());

        try
        {
            if (n < 2 || n % 2 != 0)
                throw new ArgumentException("n должно быть четным числом ≥ 2");

            double result = CalculateProductRecursive(n / 2, 1);
            Console.WriteLine($"Произведение для n={n}: {result:F10}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}