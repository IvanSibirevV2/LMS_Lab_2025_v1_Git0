﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { 10, 5, 8, 15, 3, 20, 7, 12 };

        // Находим индексы минимального и максимального элементов
        int minIndex = numbers.IndexOf(numbers.Min());
        int maxIndex = numbers.IndexOf(numbers.Max());

        // Определяем границы диапазона для удаления
        int start = Math.Min(minIndex, maxIndex) + 1;
        int end = Math.Max(minIndex, maxIndex) - 1;
        int count = end - start + 1;

        // Удаляем элементы между минимальным и максимальным
        if (count > 0)
        {
            numbers.RemoveRange(start, count);
        }

        // Выводим результаты
        Console.WriteLine($"Количество удалённых элементов: {count}");
        Console.WriteLine("Список после удаления: " + string.Join(", ", numbers));
    }
}