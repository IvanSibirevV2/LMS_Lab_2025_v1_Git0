﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Исходный список
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // Фильтруем, оставляя только нечетные числа
        numbers = numbers.Where(x => x % 2 != 0).ToList();

        // Выводим результат
        Console.WriteLine(string.Join(", ", numbers)); // 1, 3, 5, 7, 9
    }
}