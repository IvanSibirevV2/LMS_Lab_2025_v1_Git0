﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Исходный список чисел
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // Разделение на четные и нечетные числа
        List<int> evenNumbers = numbers.Where(x => x % 2 == 0).ToList();
        List<int> oddNumbers = numbers.Where(x => x % 2 != 0).ToList();

        // Вывод результатов
        Console.WriteLine("Исходный список: " + string.Join(", ", numbers));
        Console.WriteLine("Четные числа: " + string.Join(", ", evenNumbers));
        Console.WriteLine("Нечетные числа: " + string.Join(", ", oddNumbers));
    }
}