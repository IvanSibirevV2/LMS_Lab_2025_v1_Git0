﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { -5, 10, -3, 8, 0, -1, 15 };

        // Разделение с помощью LINQ
        List<int> positive = numbers.Where(n => n > 0).ToList();
        List<int> negative = numbers.Where(n => n < 0).ToList();

        Console.WriteLine("Положительные числа:");
        Console.WriteLine(string.Join(", ", positive));

        Console.WriteLine("\nОтрицательные числа:");
        Console.WriteLine(string.Join(", ", negative));
    }
}