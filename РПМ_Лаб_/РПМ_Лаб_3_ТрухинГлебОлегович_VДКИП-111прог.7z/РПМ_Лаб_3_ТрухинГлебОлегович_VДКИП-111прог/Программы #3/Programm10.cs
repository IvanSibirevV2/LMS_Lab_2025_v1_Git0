﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Исходный список
        List<int> numbers = new List<int> { 12, 5, 8, 19, 3, 7, 10, 4 };

        // Вычисляем среднее значение
        double average = CalculateAverage(numbers);

        // Определяем и удаляем элементы меньше среднего
        int count = RemoveElementsBelowAverage(numbers, average);

        // Выводим результаты
        Console.WriteLine($"Среднее значение: {average:F2}");
        Console.WriteLine($"Удалено элементов: {count}");
        Console.WriteLine("Итоговый список: " + string.Join(", ", numbers));
    }

    static double CalculateAverage(List<int> numbers)
    {
        if (numbers == null || numbers.Count == 0)
            throw new ArgumentException("Список не может быть пустым");

        double sum = 0;
        foreach (int num in numbers)
            sum += num;

        return sum / numbers.Count;
    }

    static int RemoveElementsBelowAverage(List<int> numbers, double average)
    {
        int count = 0;

        // Проходим список с конца для безопасного удаления
        for (int i = numbers.Count - 1; i >= 0; i--)
        {
            if (numbers[i] < average)
            {
                numbers.RemoveAt(i);
                count++;
            }
        }

        return count;
    }
}