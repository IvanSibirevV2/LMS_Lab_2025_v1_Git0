﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Создаем список
        List<double> numbers = new List<double> { 5.2, 8.1, 3.7, 10.4, 6.9 };

        // Вычисляем среднее арифметическое
        double average = numbers.Average();

        // Заменяем первый элемент средним значением
        if (numbers.Count > 0)
        {
            numbers[0] = average;
        }

        // Выводим результаты
        Console.WriteLine($"Среднее арифметическое: {average:F2}");
        Console.WriteLine("Измененный список: " + string.Join(", ", numbers));
    }
}