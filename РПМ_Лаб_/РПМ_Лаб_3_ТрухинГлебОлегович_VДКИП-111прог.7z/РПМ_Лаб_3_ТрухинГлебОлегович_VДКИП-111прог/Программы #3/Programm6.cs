﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { 3, 7, 2, 9, 5, 1, 8 };

        if (numbers.Count >= 2)
        {
            int minIndex = numbers.IndexOf(numbers.Min());
            int maxIndex = numbers.IndexOf(numbers.Max());

            // Меняем местами
            int temp = numbers[minIndex];
            numbers[minIndex] = numbers[maxIndex];
            numbers[maxIndex] = temp;
        }

        Console.WriteLine(string.Join(", ", numbers));
        // Для примера выше: 3, 7, 2, 1, 5, 9, 8
    }
}