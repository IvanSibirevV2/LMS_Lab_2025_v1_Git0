﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        List<int> result = new List<int>();

        for (int i = 0; i < numbers.Count; i++)
        {
            if (i % 2 == 0) // берем каждый первый (четные индексы)
            {
                result.Add(numbers[i]);
            }
        }

        Console.WriteLine(string.Join(", ", result)); // 1, 3, 5, 7, 9
    }
}