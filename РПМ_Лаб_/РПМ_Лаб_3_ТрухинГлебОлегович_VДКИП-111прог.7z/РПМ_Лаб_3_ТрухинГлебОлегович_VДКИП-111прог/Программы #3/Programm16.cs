﻿using System;

static void Main(string[] args)
{
    Random rand = new Random();

    int N = 4;


    int[] arr = new int[N];

    for (int i = 0; i < arr.Length; i++)
    {
        arr[i] = rand.Next(-20, 20);
    }

    Console.WriteLine();

    foreach (int i in arr) Console.Write(i + ", ");

    //---------------1---------------//
    float sumOfEven = 0;
    float countOfEven = 0;

    foreach (int i in arr)
        if (i % 2 == 0)
        {
            sumOfEven += i;
            countOfEven++;
        }

    Console.WriteLine($"Среднее арифметическое: {sumOfEven / countOfEven}");

    //---------------2---------------//

    int sumFrom = 0;
    foreach (int i in arr)
        if (i >= -10 && i <= 0)
            sumFrom += i;

    Console.WriteLine($"Сумма элементов в диапазоне [-10;0]: {sumFrom}");


    //---------------3----------------//

    int max = arr[0];
    foreach (int i in arr)
        if (Math.Abs(i) > Math.Abs(max))
            max = i;


    Console.WriteLine($"Максимально число по модулю: {max}");
}