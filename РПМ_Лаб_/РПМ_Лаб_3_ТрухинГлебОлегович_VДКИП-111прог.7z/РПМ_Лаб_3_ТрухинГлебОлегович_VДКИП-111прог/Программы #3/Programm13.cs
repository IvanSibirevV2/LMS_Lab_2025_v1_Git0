﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Исходный список
        List<int> numbers = new List<int> { 12, 5, 27, 8, 19, 3, 27, 7, 10 };

        // Находим максимальное значение
        int maxValue = numbers.Max();

        // Удаляем первое вхождение максимального значения
        numbers.Remove(maxValue);

        // Выводим результаты
        Console.WriteLine($"Максимальное значение: {maxValue}");
        Console.WriteLine("Список после удаления: " + string.Join(", ", numbers));
    }
}