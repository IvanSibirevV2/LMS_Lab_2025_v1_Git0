﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Исходный список
        List<int> originalList = new List<int> { 10, 5, 8, 15, 3, 20, 7, 12 };

        // Находим индекс максимального элемента
        int maxIndex = originalList.IndexOf(originalList.Max());
        int startIndex = 1; // Начинаем с элемента после вершины (индекс 0 - вершина)
        int count = maxIndex - startIndex; // Количество элементов между вершиной и максимумом

        // Создаем новый список с элементами между вершиной и максимумом
        List<int> newList = new List<int>();

        // Проверяем, есть ли элементы между вершиной и максимумом
        if (maxIndex > startIndex)
        {
            newList = originalList.GetRange(startIndex, count);
        }

        // Выводим результаты
        Console.WriteLine("Исходный список: " + string.Join(", ", originalList));
        Console.WriteLine("Максимальный элемент: " + originalList.Max() + " (индекс " + maxIndex + ")");
        Console.WriteLine("Новый список: " + string.Join(", ", newList));
    }
}