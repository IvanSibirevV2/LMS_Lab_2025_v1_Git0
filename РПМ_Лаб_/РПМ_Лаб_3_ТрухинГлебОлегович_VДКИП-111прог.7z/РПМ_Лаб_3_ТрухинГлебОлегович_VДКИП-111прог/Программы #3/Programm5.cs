﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { 5, 15, 23, 35, 42, 55, 60 };

        // Оставляем только числа, которые НЕ заканчиваются на 5
        numbers = numbers.Where(x => x % 10 != 5).ToList();

        Console.WriteLine(string.Join(", ", numbers)); // 23, 42, 60
    }
}