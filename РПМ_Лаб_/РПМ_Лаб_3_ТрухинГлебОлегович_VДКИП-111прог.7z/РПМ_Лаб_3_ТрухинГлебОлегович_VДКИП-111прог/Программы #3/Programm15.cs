﻿using System.Collections.Generic;
using System;

Random rnd = new Random();
var s = new List<int>();
for (int i = 0; i < 20; i++)
{
    s.Add(rnd.Next(10));
}
for (int i = 0; i < s.Count; i++)
{
    if (s[i] % 2 != 0)
    {
        s.RemoveAt(i);
    }
    i--; // Сдвиг индекса на единицу назад, так как после удаления следующий элемент будет на том же индексе, что и старый (удаленный) [1](https://qna.habr.com/q/218684)
}
Console.WriteLine(s);