﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Исходный список
        List<int> originalList = new List<int> { 10, 5, 8, 15, 3, 20, 7, 12 };

        // Находим индекс минимального элемента
        int minValue = originalList.Min();
        int minIndex = originalList.IndexOf(minValue);

        // Создаем новый список для элементов между вершиной и минимумом
        List<int> betweenElements = new List<int>();

        // Если минимальный элемент не первый и есть элементы между ними
        if (minIndex > 1)
        {
            betweenElements = originalList.GetRange(1, minIndex - 1);
        }

        // Выводим результаты
        Console.WriteLine("Исходный список: " + string.Join(", ", originalList));
        Console.WriteLine($"Минимальный элемент: {minValue} (индекс {minIndex})");
        Console.WriteLine("Элементы между вершиной и минимумом: " + string.Join(", ", betweenElements));
    }
}