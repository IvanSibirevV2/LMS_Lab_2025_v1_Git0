﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };

        // Проверяем, что в списке есть хотя бы 2 элемента
        if (numbers.Count >= 2)
        {
            // Сохраняем первый элемент во временную переменную
            int temp = numbers[0];

            // Заменяем первый элемент последним
            numbers[0] = numbers[numbers.Count - 1];

            // Заменяем последний элемент сохраненным первым
            numbers[numbers.Count - 1] = temp;
        }

        Console.WriteLine(string.Join(", ", numbers)); // 5, 2, 3, 4, 1
    }
}