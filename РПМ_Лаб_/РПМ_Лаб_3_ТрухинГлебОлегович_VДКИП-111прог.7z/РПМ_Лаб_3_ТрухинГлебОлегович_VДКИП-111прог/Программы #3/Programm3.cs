﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Исходный список
        List<int> numbers = new List<int> { -5, 3, -2, 8, 0, -1, 10 };

        // Фильтруем, оставляя только неотрицательные числа (>= 0)
        numbers = numbers.Where(x => x >= 0).ToList();

        // Выводим результат
        Console.WriteLine(string.Join(", ", numbers)); // 3, 8, 0, 10
    }
}