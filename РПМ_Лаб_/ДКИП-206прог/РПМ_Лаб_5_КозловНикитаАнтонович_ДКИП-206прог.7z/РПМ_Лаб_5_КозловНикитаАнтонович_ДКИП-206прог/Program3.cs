﻿using System;

// Базовый класс "Строка"
public class StringBase
{
    protected string value;

    public StringBase(string val)
    {
        value = val;
    }

    public override string ToString()
    {
        return value;
    }

    // Деструктор (финализатор)
    ~StringBase()
    {
        Console.WriteLine("Объект StringBase удален.");
    }
}

// Производный класс "Битовая строка"
public class BitString : StringBase
{
    public BitString(string val)
        : base(val)
    {
        if (!IsBinary(val))
        {
            value = ""; // Принимаем пустое значение
        }
    }

    // Проверка, является ли строка битовой
    private bool IsBinary(string s)
    {
        foreach (char c in s)
        {
            if (c != '0' && c != '1')
                return false;
        }
        return true;
    }

    // Метод присваивания
    public void Assign(string val)
    {
        if (IsBinary(val))
        {
            value = val;
        }
        else
        {
            value = "";
        }
    }

    // Метод изменения знака (дополнительный код)
    public void Negate()
    {
        if (string.IsNullOrEmpty(value))
            return;

        // Инвертируем биты
        char[] inverted = new char[value.Length];
        for (int i = 0; i < value.Length; i++)
        {
            inverted[i] = (value[i] == '0') ? '1' : '0';
        }

        // Прибавляем 1
        string twosComplement = AddBinary(new string(inverted), "1");
        value = twosComplement;
    }

    // Метод сложения двух битовых строк
    public static BitString Add(BitString a, BitString b)
    {
        if (a.value == null || b.value == null)
            return new BitString("");

        // Выравниваем длины строк
        string aStr = a.value.PadLeft(b.value.Length, a.value[0]);
        string bStr = b.value.PadLeft(a.value.Length, b.value[0]);

        // Складываем
        string result = AddBinary(aStr, bStr);
        return new BitString(result);
    }

    // Вспомогательный метод сложения двух битовых строк
    private static string AddBinary(string a, string b)
    {
        int length = Math.Max(a.Length, b.Length);
        a = a.PadLeft(length, a[0]);
        b = b.PadLeft(length, b[0]);

        char[] result = new char[length + 1];
        int carry = 0;

        for (int i = length - 1; i >= 0; i--)
        {
            int sum = (a[i] - '0') + (b[i] - '0') + carry;
            result[i + 1] = (sum % 2) == 0 ? '0' : '1';
            carry = sum / 2;
        }

        result[0] = (carry % 2) == 0 ? '0' : '1';
        return new string(result);
    }

    // Проверка на равенство
    public bool Equals(BitString other)
    {
        if (string.IsNullOrEmpty(value) || string.IsNullOrEmpty(other.value))
            return false;

        // Выравниваем длины
        string thisStr = value.PadLeft(other.value.Length, value[0]);
        string otherStr = other.value.PadLeft(value.Length, other.value[0]);

        return thisStr == otherStr;
    }

    // Деструктор
    ~BitString()
    {
        Console.WriteLine("Объект BitString удален.");
    }
}

class Program
{
    static void Main()
    {
        // Тестирование
        BitString bs1 = new BitString("1101"); // -3 (дополнительный код 4 бита)
        BitString bs2 = new BitString("101");  // 5 (3 бита)

        Console.WriteLine("bs1: " + bs1);
        Console.WriteLine("bs2: " + bs2);

        // Сложение
        BitString sum = BitString.Add(bs1, bs2);
        Console.WriteLine("Сумма: " + sum);

        // Изменение знака
        bs1.Negate();
        Console.WriteLine("bs1 после изменения знака: " + bs1);

        // Проверка на равенство
        BitString bs3 = new BitString("0011");
        Console.WriteLine("bs1 == bs3? " + bs1.Equals(bs3));
    }
}
