﻿using System;

struct ZNAK
{
    public string Surname;
    public string Name;
    public string ZodiacSign;
    public int[] BirthDate; // [год, месяц, день]
}

class Program
{
    static void Main()
    {
        const int COUNT = 8;
        ZNAK[] znaki = new ZNAK[COUNT];

        // Ввод данных
        for (int i = 0; i < COUNT; i++)
        {
            Console.WriteLine($"\nВведите данные для человека {i + 1}:");
            Console.Write("Фамилия: ");
            znaki[i].Surname = Console.ReadLine();
            Console.Write("Имя: ");
            znaki[i].Name = Console.ReadLine();
            Console.Write("Знак Зодиака: ");
            znaki[i].ZodiacSign = Console.ReadLine();

            znaki[i].BirthDate = new int[3];
            Console.Write("Год рождения: ");
            znaki[i].BirthDate[0] = int.Parse(Console.ReadLine());
            Console.Write("Месяц рождения: ");
            znaki[i].BirthDate[1] = int.Parse(Console.ReadLine());
            Console.Write("День рождения: ");
            znaki[i].BirthDate[2] = int.Parse(Console.ReadLine());
        }

        // Сортировка по дате рождения
        Array.Sort(znaki, (a, b) =>
        {
            for (int i = 0; i < 3; i++)
            {
                int cmp = a.BirthDate[i].CompareTo(b.BirthDate[i]);
                if (cmp != 0)
                    return cmp;
            }
            return 0;
        });

        // Вывод отсортированного массива
        Console.WriteLine("\nОтсортированные данные:");
        foreach (var znak in znaki)
        {
            Console.WriteLine($"{znak.Surname} {znak.Name}, {znak.ZodiacSign}, {znak.BirthDate[0]}-{znak.BirthDate[1]}-{znak.BirthDate[2]}");
        }

        // Поиск по знаку Зодиака
        Console.Write("\nВведите знак Зодиака для поиска: ");
        string targetZodiac = Console.ReadLine().Trim().ToLower();
        bool found = false;

        Console.WriteLine($"\nЛюди с знаком {targetZodiac}:");
        foreach (var znak in znaki)
        {
            if (znak.ZodiacSign.ToLower() == targetZodiac)
            {
                Console.WriteLine($"{znak.Surname} {znak.Name}, {znak.BirthDate[0]}-{znak.BirthDate[1]}-{znak.BirthDate[2]}");
                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("Нет людей с этим знаком Зодиака.");
        }
    }
}
