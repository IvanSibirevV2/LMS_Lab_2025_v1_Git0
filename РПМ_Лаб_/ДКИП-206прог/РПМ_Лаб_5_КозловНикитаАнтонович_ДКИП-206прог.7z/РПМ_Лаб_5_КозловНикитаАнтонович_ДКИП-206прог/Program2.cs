﻿using System;
using System.Collections.Generic;

// Класс "Поезд"
public class Train
{
    // Закрытые поля
    private string destination;
    private string trainNumber;
    private TimeSpan departureTime;

    // Свойства для получения состояния объекта
    public string Destination => destination;
    public string TrainNumber => trainNumber;
    public TimeSpan DepartureTime => departureTime;

    // Конструктор с проверкой корректности данных
    public Train(string destination, string trainNumber, string departureTimeString)
    {
        if (string.IsNullOrWhiteSpace(destination))
            throw new ArgumentException("Пункт назначения не может быть пустым.");
        if (string.IsNullOrWhiteSpace(trainNumber))
            throw new ArgumentException("Номер поезда не может быть пустым.");
        if (!TimeSpan.TryParse(departureTimeString, out departureTime))
            throw new ArgumentException("Некорректный формат времени отправления (ожидается HH:mm).");
    }

    // Перегрузка операторов сравнения
    public static bool operator >(Train t1, Train t2)
    {
        return t1.DepartureTime > t2.DepartureTime;
    }

    public static bool operator <(Train t1, Train t2)
    {
        return t1.DepartureTime < t2.DepartureTime;
    }

    public static bool operator ==(Train t1, Train t2)
    {
        return t1?.DepartureTime == t2?.DepartureTime;
    }

    public static bool operator !=(Train t1, Train t2)
    {
        return !(t1 == t2);
    }

    public override string ToString()
    {
        return $"Поезд {TrainNumber} до {Destination}, отправление в {DepartureTime:hh\\:mm tt}";
    }
}

// Класс "Вокзал"
public class Station
{
    // Закрытый массив поездов
    private Train[] trains;

    // Конструктор
    public Station(Train[] trains)
    {
        this.trains = trains;
    }

    // Индексатор для доступа к поездам по индексу
    public Train this[int index]
    {
        get
        {
            if (index < 0 || index >= trains.Length)
                throw new IndexOutOfRangeException("Индекс вне диапазона.");
            return trains[index];
        }
    }

    // Метод для вывода информации о поезде по номеру
    public void PrintTrainByNumber(string trainNumber)
    {
        foreach (var train in trains)
        {
            if (train.TrainNumber == trainNumber)
            {
                Console.WriteLine(train);
                return;
            }
        }
        Console.WriteLine("Поезд с таким номером не найден.");
    }

    // Метод для вывода поездов, отправляющихся после заданного времени
    public void PrintTrainsAfterTime(TimeSpan time)
    {
        Console.WriteLine($"\nПоезда, отправляющиеся после {time:hh\\:mm tt}:");
        foreach (var train in trains)
        {
            if (train.DepartureTime > time)
            {
                Console.WriteLine(train);
            }
        }
    }

    // Метод для вывода поездов в заданный пункт назначения, отсортированных по времени
    public void PrintTrainsToDestination(string destination)
    {
        List<Train> filteredTrains = new List<Train>();
        foreach (var train in trains)
        {
            if (train.Destination.Equals(destination, StringComparison.OrdinalIgnoreCase))
            {
                filteredTrains.Add(train);
            }
        }

        if (filteredTrains.Count == 0)
        {
            Console.WriteLine($"Постов в пункт {destination} не найдено.");
            return;
        }

        // Сортировка по времени отправления
        filteredTrains.Sort((t1, t2) => t1.DepartureTime.CompareTo(t2.DepartureTime));

        Console.WriteLine($"\nПоезда в пункт {destination}, отсортированные по времени:");
        foreach (var train in filteredTrains)
        {
            Console.WriteLine(train);
        }
    }

    // Метод для сравнения двух поездов по времени отправления
    public void CompareTrains(int index1, int index2)
    {
        Train train1 = this[index1];
        Train train2 = this[index2];

        if (train1 > train2)
        {
            Console.WriteLine($"Поезд {train1.TrainNumber} отправляется позже, чем {train2.TrainNumber}.");
        }
        else if (train1 < train2)
        {
            Console.WriteLine($"Поезд {train1.TrainNumber} отправляется раньше, чем {train2.TrainNumber}.");
        }
        else
        {
            Console.WriteLine($"Поезда {train1.TrainNumber} и {train2.TrainNumber} отправляются одновременно.");
        }
    }
}

// Основная программа
class Program
{
    static void Main()
    {
        // Создание массива поездов
        Train[] trains = new Train[]
        {
            new Train("Москва", "R123A", "08:00"),
            new Train("Санкт-Петербург", "S456B", "10:30"),
            new Train("Москва", "R789C", "12:45"),
            new Train("Новосибирск", "N012D", "09:15"),
            new Train("Москва", "R345E", "14:00")
        };

        // Создание вокзала
        Station station = new Station(trains);

        // Демонстрация работы с индексатором
        Console.WriteLine("Поезд по индексу 2:");
        Console.WriteLine(station[2]);

        // Демонстрация поиска поезда по номеру
        Console.WriteLine("\nПоиск поезда по номеру:");
        station.PrintTrainByNumber("S456B");

        // Демонстрация поиска поездов, отправляющихся после заданного времени
        Console.WriteLine("\nВвод времени отправления для поиска (в формате HH:mm):");
        string inputTime = Console.ReadLine();
        if (TimeSpan.TryParse(inputTime, out TimeSpan time))
        {
            station.PrintTrainsAfterTime(time);
        }
        else
        {
            Console.WriteLine("Некорректный формат времени.");
        }

        // Демонстрация сравнения поездов
        Console.WriteLine("\nСравнение поездов по индексам 0 и 3:");
        station.CompareTrains(0, 3);

        // Демонстрация поиска поездов в заданный пункт
        Console.WriteLine("\nВвод пункта назначения для поиска:");
        string destination = Console.ReadLine();
        station.PrintTrainsToDestination(destination);
    }
}
