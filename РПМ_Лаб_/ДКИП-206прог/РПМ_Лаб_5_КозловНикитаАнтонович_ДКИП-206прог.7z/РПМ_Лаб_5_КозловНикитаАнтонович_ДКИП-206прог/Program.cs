﻿using System;

// Определение класса Room
public class Room
{
    // Поля класса
    private double area;
    private double ceilingHeight;
    private int windowCount;

    // Конструктор с проверкой допустимости значений
    public Room(double area, double ceilingHeight, int windowCount)
    {
        if (area <= 0)
            throw new ArgumentException("Площадь комнаты должна быть положительной.");
        if (ceilingHeight <= 0)
            throw new ArgumentException("Высота потолка должна быть положительной.");
        if (windowCount < 0)
            throw new ArgumentException("Количество окон не может быть отрицательным.");

        this.area = area;
        this.ceilingHeight = ceilingHeight;
        this.windowCount = windowCount;
    }

    // Метод вычисления площади
    public double GetArea()
    {
        return area;
    }

    // Метод вычисления объема
    public double CalculateVolume()
    {
        return area * ceilingHeight;
    }

    // Свойства для получения состояния объекта
    public double Area => area;
    public double CeilingHeight => ceilingHeight;
    public int WindowCount => windowCount;

    // Метод для удобного вывода информации о комнате
    public override string ToString()
    {
        return $"Комната: Площадь = {Area:F2} м², Высота потолка = {CeilingHeight:F2} м, Окон = {WindowCount}";
    }
}

// Основная программа
class Program
{
    static void Main()
    {
        Console.WriteLine("Программа для расчета характеристик комнаты");
        Console.WriteLine("========================================");

        try
        {
            // Ввод площади комнаты
            Console.Write("Введите площадь комнаты (м², положительное число): ");
            string areaInput = Console.ReadLine();
            double area = Convert.ToDouble(areaInput);

            // Ввод высоты потолка
            Console.Write("Введите высоту потолка (м, положительное число): ");
            string heightInput = Console.ReadLine();
            double height = Convert.ToDouble(heightInput);

            // Ввод количества окон
            Console.Write("Введите количество окон (целое число ≥ 0): ");
            string windowsInput = Console.ReadLine();
            int windows = Convert.ToInt32(windowsInput);

            // Создание объекта Room
            Room room = new Room(area, height, windows);

            // Вывод информации
            Console.WriteLine("\nДанные успешно введены:");
            Console.WriteLine(room.ToString());
            Console.WriteLine($"Объем комнаты: {room.CalculateVolume():F2} м³");
        }
        catch (FormatException)
        {
            Console.WriteLine("\nОшибка: Введите корректное числовое значение.");
        }
        catch (OverflowException)
        {
            Console.WriteLine("\nОшибка: Значение слишком большое или маленькое.");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"\nОшибка: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nПроизошла непредвиденная ошибка: {ex.Message}");
        }

        Console.WriteLine("\nПрограмма завершена.");
    }
}
