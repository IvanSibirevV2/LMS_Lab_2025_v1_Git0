﻿
namespace Laba1
{
    using System.Numerics;
    using static System.Math;
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            Task1();
            Task2_2();
            Task3();
            Task4();
        }

        private static void Task1()
        {
            Console.WriteLine("Лабораторная 1");
            Task1_Solution(0, 0);
        }
        private static void Task1_Solution(int a, int b)
        {
            double z1 = Pow(Cos(a) - Cos(b), 2) - Pow(Sin(a) - Sin(b), 2);
            double z2 = -4 * Pow(Sin((a - b) / 2), 2) - Pow(Sin(a) - Sin(b), 2);
            Console.WriteLine(z1);
            Console.WriteLine(z2);
        }
        private static void Task2_2(float x = 0, float y = 0)
        {
            Console.WriteLine("Лабораторная 2");

            Task2_2_Solution(x, y);
        }
        static void Task2_2_Solution(float x = 0, float y = 0)
        {
            Vector2 p = new(x, y);
            if (p.X > 0 && p.Length() < 1)
            {
                Console.WriteLine("Попал");
                return;
            }
            if (PointInTriangle(p, new Vector2(-1, 1), new Vector2(0, 1), new Vector2(0, 0))
                || PointInTriangle(p, new Vector2(-1, -1), new Vector2(0, -1), new Vector2(0, 0)))
            {
                Console.WriteLine("Попал");
                return;
            }
            Console.WriteLine("Не попал");
        }
        static float Sign(Vector2 p1, Vector2 p2, Vector2 p3)
        {
            return (p1.X - p3.X) * (p2.Y - p3.Y) - (p2.X - p3.X) * (p1.Y - p3.Y);
        }

        static bool PointInTriangle(Vector2 pt, Vector2 v1, Vector2 v2, Vector2 v3)
        {
            float d1, d2, d3;
            bool has_neg, has_pos;
            d1 = Sign(pt, v1, v2);
            d2 = Sign(pt, v2, v3);
            d3 = Sign(pt, v3, v1);
            has_neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
            has_pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
            return !(has_neg && has_pos);
        }

        static void Task3()
        {
            Console.WriteLine("Лабораторная 3");

            Task3_1();
            Task3_2();
            Task3_3();
        }
        static void Task3_1()
        {
            Console.WriteLine("В моём варианте №9 нет R у графической функции");
        }
        static void Task3_2()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Введите x y");
                var str = Console.ReadLine()?.Split(' ');
                if (str == null ||
                    str.Length == 0 ||
                    !float.TryParse(str[0], out var x) ||
                    !float.TryParse(str[0], out var y))
                {
                    Console.WriteLine("Вы плохо ввели значение поэтому выстрел штрафной");
                    continue;
                }
                Task2_2(x, y);
            }
        }
        static void Task3_3()
        {
            Console.WriteLine("Третья лабораторная, третье задание");
            if (!int.TryParse(Console.ReadLine(), out var x0))
            {
                Console.WriteLine("НЕ ПРАВИЛЬНО ВВЕДЕН x");
                return;
            }
            if (!int.TryParse(Console.ReadLine(), out var x1))
            {
                Console.WriteLine("НЕ ПРАВИЛЬНО ВВЕДЕН x");
                return;
            }
            if (!double.TryParse(Console.ReadLine(), out var dx))
            {
                Console.WriteLine("НЕ ПРАВИЛЬНО ВВЕДЕН dx");
                return;
            }
            if (Abs(x0) >= 1 || Abs(x1) >= 1)
            {
                Console.WriteLine("x В МОДУЛЕ БОЛЬШЕ ОДНОГО");
                return;
            }

            for (double x = x0; x < x1; x += dx)
            {
                Console.WriteLine($"{x:0.####}|{Arctg(x, 100):0.####}|100");
            }
        }
        static double Arctg(double x, int precision)
        {
            return PI / 2 + Enumerable.Range(0, precision).Select(n =>
            Pow(-1, n + 1) /
            ((2 * n + 1) * Pow(x, 2 * n + 1))).Aggregate((a, b) => a + b);
        }

        static void Task4()
        {
            Console.WriteLine("Лабораторная 4");

            var arr = new float[] { 0, -1, -5.4f, 1.1f, -2.34f, -3.6f, 2.4f, 9.1f, -12.2f };
            Task4_1(arr);
            Task4_2();
            Task4_3();
        }
        static void Task4_1(float[] arr)
        {
            var maxAbs = arr.Max(x => Abs(x));

            bool exit = false;
            float sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (exit)
                    break;
                var n = arr[i];
                if (n < 1)
                    continue;
                // Если число положительное то начинаем счет суммы
                for (int j = i + 1; j < arr.Length; j++)
                {
                    // Если число положительное заканчиваем счет суммы и выходим из цикла
                    if (arr[j] > 0)
                    {
                        exit = true;
                        break;
                    }
                    sum += arr[j];

                }
            }
            Console.WriteLine($"Макс По Модулю={maxAbs}\nСумма={sum}");
        }
        static void Task4_2()
        {
            var randomMatrix = Enumerable.Range(0, 10).Select(x => Enumerable.Range(0, 10).Select(n => Random.Shared.NextSingle() * 10).ToArray()).ToArray();
            Array.ForEach(randomMatrix, (n) => { Array.ForEach(n, m => Console.Write($"{m}, ")); Console.WriteLine(); });
            var result = (float[][])randomMatrix.Clone();
            result =
            result
                .Select((a, j) =>
                    a.Select((b, i) =>
                    {
                        if (i == 0) return
                            (randomMatrix[j][i] + randomMatrix[j][i + 1]) / 2;
                        if (i == randomMatrix[j].Length - 1) return
                            (randomMatrix[j][i - 1] + randomMatrix[j][i]) / 2;
                        return (randomMatrix[j][i - 1] + randomMatrix[j][i] + randomMatrix[j][i + 1]) / 3;
                    })
                    .ToArray()
                )
            .ToArray();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------");
            Array.ForEach(result, (n) => { Array.ForEach(n, m => Console.Write($"{m}, ")); Console.WriteLine(); });
        }
        static void Task4_3()
        {
            if(!File.Exists("Laba4_Task3.txt"))
            {
                Console.WriteLine("ФАЙЛА Laba4_Task3.txt НЕТ");
                return;
            }
            if(!int.TryParse(Console.ReadLine(), out var numWords))
            {
                Console.WriteLine("НЕПРАВИЛЬНО ВВЕДЕН numWords!");
                return;
            }
            var text = File.ReadAllText("Laba4_Task3.txt");
            var sentences = text.Split(".");
            Array.ForEach(sentences.Where(c => c.Split(" ").Length <= numWords).ToArray(), Console.WriteLine);
        }
    }
}