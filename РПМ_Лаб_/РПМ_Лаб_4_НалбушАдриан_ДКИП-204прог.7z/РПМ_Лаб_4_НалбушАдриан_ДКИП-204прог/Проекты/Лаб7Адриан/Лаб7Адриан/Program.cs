﻿using System;
using System.IO;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        // Указываем путь к файлу
        string filePath = @"C:\Users\724\Downloads\Лаб7Адриан\adrianlr7.txt";

        // Проверяем, существует ли файл
        if (!File.Exists(filePath))
        {
            Console.WriteLine("Файл не найден: " + filePath);
            return;
        }

        // Читаем все строки из файла
        string[] lines = File.ReadAllLines(filePath);

        // Регулярное выражение для поиска двузначных чисел
        Regex regex = new Regex(@"\b\d{2}\b");

        // Перебираем каждую строку
        foreach (string line in lines)
        {
            // Проверяем, содержит ли строка двузначные числа
            if (regex.IsMatch(line))
            {
                Console.WriteLine(line); // Выводим строку, если она содержит двузначные числа
            }
        }
    }
}
