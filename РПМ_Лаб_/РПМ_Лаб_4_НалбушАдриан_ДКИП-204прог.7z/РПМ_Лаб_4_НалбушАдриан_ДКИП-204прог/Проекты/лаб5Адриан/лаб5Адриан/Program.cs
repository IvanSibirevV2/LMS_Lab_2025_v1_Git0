﻿using System;

class Program
{
    static void Main()
    {
        // Ввод размера массива
        Console.Write("Введите количество элементов в массиве: ");
        int n = int.Parse(Console.ReadLine());

        double[] array = new double[n];

        // Ввод элементов массива
        Console.WriteLine("Введите элементы массива:");
        for (int i = 0; i < n; i++)
        {
            array[i] = double.Parse(Console.ReadLine());
        }

        // 1. Сумма элементов с нечетными номерами
        double sumOddIndices = 0;
        for (int i = 1; i < n; i += 2)
        {
            sumOddIndices += array[i];
        }
        Console.WriteLine($"Сумма элементов с нечетными номерами: {sumOddIndices}");

        // 2. Сумма элементов между первым и последним отрицательными элементами
        int firstNegativeIndex = -1;
        int lastNegativeIndex = -1;

        for (int i = 0; i < n; i++)
        {
            if (array[i] < 0)
            {
                if (firstNegativeIndex == -1)
                {
                    firstNegativeIndex = i;
                }
                lastNegativeIndex = i;
            }
        }

        double sumBetweenNegatives = 0;
        if (firstNegativeIndex != -1 && lastNegativeIndex != -1 && firstNegativeIndex < lastNegativeIndex)
        {
            for (int i = firstNegativeIndex + 1; i < lastNegativeIndex; i++)
            {
                sumBetweenNegatives += array[i];
            }
        }
        Console.WriteLine($"Сумма элементов между первым и последним отрицательными элементами: {sumBetweenNegatives}");

        // 3. Сжатие массива
        double[] compressedArray = new double[n];
        int newSize = 0;

        for (int i = 0; i < n; i++)
        {
            if (Math.Abs(array[i]) > 1)
            {
                compressedArray[newSize] = array[i];
                newSize++;
            }
        }

        // Заполнение оставшихся элементов нулями
        for (int i = newSize; i < n; i++)
        {
            compressedArray[i] = 0;
        }

        // Вывод сжатого массива
        Console.WriteLine("Сжатый массив:");
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine(compressedArray[i]);
        }
    }
}
