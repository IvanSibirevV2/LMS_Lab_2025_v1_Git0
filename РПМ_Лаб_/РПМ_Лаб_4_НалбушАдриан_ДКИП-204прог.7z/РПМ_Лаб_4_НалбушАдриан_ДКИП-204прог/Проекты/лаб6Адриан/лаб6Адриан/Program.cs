﻿using System;

class Program
{
    static void Main()
    {
        int rows = 0;
        int cols = 0;

        // Ввод количества строк
        while (true)
        {
            Console.Write("Введите количество строк матрицы: ");
            if (int.TryParse(Console.ReadLine(), out rows) && rows > 0)
                break;
            Console.WriteLine("Пожалуйста, введите корректное положительное целое число.");
        }

        // Ввод количества столбцов
        while (true)
        {
            Console.Write("Введите количество столбцов матрицы: ");
            if (int.TryParse(Console.ReadLine(), out cols) && cols > 0)
                break;
            Console.WriteLine("Пожалуйста, введите корректное положительное целое число.");
        }

        int[,] matrix = new int[rows, cols];

        // Ввод элементов матрицы
        Console.WriteLine("Введите элементы матрицы (по одному элементу за раз):");
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                while (true)
                {
                    Console.Write($"Элемент [{i}, {j}]: ");
                    if (int.TryParse(Console.ReadLine(), out matrix[i, j]))
                        break;
                    Console.WriteLine("Пожалуйста, введите корректное целое число.");
                }
            }
        }

        // 1. Сумма элементов в строках с хотя бы одним отрицательным элементом
        int totalSum = 0;
        for (int i = 0; i < rows; i++)
        {
            bool hasNegative = false;
            for (int j = 0; j < cols; j++)
            {
                if (matrix[i, j] < 0)
                {
                    hasNegative = true;
                    break;
                }
            }
            if (hasNegative)
            {
                for (int j = 0; j < cols; j++)
                {
                    totalSum += matrix[i, j];
                }
            }
        }
        Console.WriteLine($"Сумма элементов в строках с хотя бы одним отрицательным элементом: {totalSum}");

        // 2. Номера строк и столбцов всех седловых точек
        Console.WriteLine("Седловые точки (строка, столбец):");
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                bool isSaddlePoint = true;

                // Проверяем, является ли текущий элемент минимальным в строке
                for (int k = 0; k < cols; k++)
                {
                    if (matrix[i, k] < matrix[i, j])
                    {
                        isSaddlePoint = false;
                        break;
                    }
                }

                // Проверяем, является ли текущий элемент максимальным в столбце
                if (isSaddlePoint)
                {
                    for (int k = 0; k < rows; k++)
                    {
                        if (matrix[k, j] > matrix[i, j])
                        {
                            isSaddlePoint = false;
                            break;
                        }
                    }
                }

                if (isSaddlePoint)
                {
                    Console.WriteLine($"Седловая точка найдена на позиции: ({i}, {j})");
                }
            }
        }
    }
}
