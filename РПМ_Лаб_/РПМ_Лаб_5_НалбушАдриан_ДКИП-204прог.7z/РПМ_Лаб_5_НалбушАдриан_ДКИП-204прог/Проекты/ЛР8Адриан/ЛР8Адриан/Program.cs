﻿using System;

namespace VectorExample
{
    public class IntegerVector
    {
        private int[] _elements;
        private int _lowerBound;
        private int _upperBound;

        // Конструктор с произвольными границами индексов
        public IntegerVector(int lowerBound, int upperBound)
        {
            if (lowerBound > upperBound)
                throw new ArgumentException("Нижняя граница должна быть меньше или равна верхней границе.");

            _lowerBound = lowerBound;
            _upperBound = upperBound;
            _elements = new int[upperBound - lowerBound + 1];
        }

        // Индексатор для доступа к элементам массива
        public int this[int index]
        {
            get
            {
                CheckIndex(index);
                return _elements[index - _lowerBound];
            }
            set
            {
                CheckIndex(index);
                _elements[index - _lowerBound] = value;
            }
        }

        // Проверка индекса на выход за пределы
        private void CheckIndex(int index)
        {
            if (index < _lowerBound || index > _upperBound)
                throw new IndexOutOfRangeException($"Индекс {index} выходит за пределы массива.");
        }

        // Метод для сложения двух векторов
        public IntegerVector Add(IntegerVector other)
        {
            if (other._lowerBound != _lowerBound || other._upperBound != _upperBound)
                throw new ArgumentException("Векторы должны иметь одинаковые границы индексов.");

            IntegerVector result = new IntegerVector(_lowerBound, _upperBound);
            for (int i = _lowerBound; i <= _upperBound; i++)
            {
                result[i] = this[i] + other[i];
            }
            return result;
        }

        // Метод для вычитания двух векторов
        public IntegerVector Subtract(IntegerVector other)
        {
            if (other._lowerBound != _lowerBound || other._upperBound != _upperBound)
                throw new ArgumentException("Векторы должны иметь одинаковые границы индексов.");

            IntegerVector result = new IntegerVector(_lowerBound, _upperBound);
            for (int i = _lowerBound; i <= _upperBound; i++)
            {
                result[i] = this[i] - other[i];
            }
            return result;
        }

        // Метод для умножения всех элементов на скаляр
        public void Multiply(int scalar)
        {
            for (int i = _lowerBound; i <= _upperBound; i++)
            {
                _elements[i - _lowerBound] *= scalar;
            }
        }

        // Метод для деления всех элементов на скаляр
        public void Divide(int scalar)
        {
            if (scalar == 0)
                throw new DivideByZeroException("Деление на ноль недопустимо.");

            for (int i = _lowerBound; i <= _upperBound; i++)
            {
                _elements[i - _lowerBound] /= scalar;
            }
        }

        // Метод для вывода элемента по индексу
        public void PrintElement(int index)
        {
            Console.WriteLine($"Элемент с индексом {index}: {this[index]}");
        }

        // Метод для вывода всего массива
        public void PrintAll()
        {
            Console.WriteLine("Элементы массива:");
            for (int i = _lowerBound; i <= _upperBound; i++)
            {
                Console.WriteLine($"Индекс {i}: {this[i]}");
            }
        }
    }

    class Program
    {
        static void Main()
        {
            // Пример использования класса IntegerVector
            try
            {
                IntegerVector vector1 = new IntegerVector(0, 4);
                vector1[0] = 1;
                vector1[1] = 2;
                vector1[2] = 3;
                vector1[3] = 4;
                vector1[4] = 5;

                IntegerVector vector2 = new IntegerVector(0, 4);
                vector2[0] = 5;
                vector2[1] = 4;
                vector2[2] = 3;
                vector2[3] = 2;
                vector2[4] = 1;

                // Сложение векторов
                IntegerVector sumVector = vector1.Add(vector2);
                Console.WriteLine("Сумма векторов:");
                sumVector.PrintAll();

                // Вычитание векторов
                IntegerVector diffVector = vector1.Subtract(vector2);
                Console.WriteLine("Разность векторов:");
                diffVector.PrintAll();

                // Умножение на скаляр
                vector1.Multiply(2);
                Console.WriteLine("Вектор 1 после умножения на 2:");
                vector1.PrintAll();

                // Деление на скаляр
                vector1.Divide(2);
                Console.WriteLine("Вектор 1 после деления на 2:");
                vector1.PrintAll();

                // Вывод отдельного элемента
                vector1.PrintElement(2);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }

            Console.WriteLine("Программа завершена.");
        }
    }
}
