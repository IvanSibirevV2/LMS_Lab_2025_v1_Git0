﻿using System;
using System.Collections.Generic;

namespace Geometry
{
    // Базовый класс Point
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Point(double x, double y)
        {
            X = x;
            Y = y;
        }

        public override bool Equals(object? obj)
        {
            if (obj is Point other)
            {
                return X == other.X && Y == other.Y;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(X, Y);
        }

        public override string ToString()
        {
            return $"Point({X}, {Y})";
        }
    }

    // Класс ColoredPoint
    public class ColoredPoint : Point
    {
        public string Color { get; set; }

        public ColoredPoint(double x, double y, string color) : base(x, y)
        {
            Color = color;
        }

        public override bool Equals(object? obj)
        {
            if (obj is ColoredPoint other)
            {
                return base.Equals(other) && Color == other.Color;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(base.GetHashCode(), Color);
        }

        public override string ToString()
        {
            return $"{base.ToString()}, Color: {Color}";
        }
    }

    // Класс Line
    public class Line
    {
        public Point Start { get; set; }
        public Point End { get; set; }

        public Line(Point start, Point end)
        {
            Start = start;
            End = end;
        }

        public void Rotate(double angle)
        {
            double radians = angle * Math.PI / 180;
            double cos = Math.Cos(radians);
            double sin = Math.Sin(radians);

            double newX = Start.X + (End.X - Start.X) * cos - (End.Y - Start.Y) * sin;
            double newY = Start.Y + (End.X - Start.X) * sin + (End.Y - Start.Y) * cos;

            End = new Point(newX, newY);
        }

        public override bool Equals(object? obj)
        {
            if (obj is Line other)
            {
                return Start.Equals(other.Start) && End.Equals(other.End);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Start, End);
        }

        public override string ToString()
        {
            return $"Line from {Start} to {End}";
        }
    }

    // Класс ColoredLine
    public class ColoredLine : Line
    {
        public string Color { get; set; }

        public ColoredLine(Point start, Point end, string color) : base(start, end)
        {
            Color = color;
        }

        public override bool Equals(object? obj)
        {
            if (obj is ColoredLine other)
            {
                return base.Equals(other) && Color == other.Color;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(base.GetHashCode(), Color);
        }

        public override string ToString()
        {
            return $"{base.ToString()}, Color: {Color}";
        }
    }

    // Класс PolyLine
    public class PolyLine
    {
        public List<Point> Points { get; private set; }

        public PolyLine(List<Point> points)
        {
            Points = points;
        }

        public void Scale(double factor)
        {
            for (int i = 0; i < Points.Count; i++)
            {
                Points[i] = new Point(Points[i].X * factor, Points[i].Y * factor);
            }
        }

        public override string ToString()
        {
            return $"PolyLine with points: {string.Join(", ", Points)}";
        }
    }

    class Program
    {
        static void Main()
        {
            // Создаем список базового класса
            var shapes = new List<object>
            {
                new Point(1, 2),
                new ColoredPoint(3, 4, "Red"),
                new Line(new Point(0, 0), new Point(1, 1)),
                new ColoredLine(new Point(2, 2), new Point(3, 3), "Blue"),
                new PolyLine(new List<Point> { new Point(0, 0), new Point(1, 1), new Point(2, 2) })
            };

            // Демонстрация использования всех классов
            foreach (var shape in shapes)
            {
                Console.WriteLine(shape);
            }

            // Пример изменения угла линии
            if (shapes[2] is Line line)
            {
                Console.WriteLine($"Before rotation: {line}");
                line.Rotate(90);
                Console.WriteLine($"After rotation: {line}");
            }

            // Пример масштабирования многоугольника
            if (shapes[4] is PolyLine polyline)
            {
                Console.WriteLine($"Before scaling: {polyline}");
                polyline.Scale(2);
                Console.WriteLine($"After scaling: {polyline}");
            }
        }
    }
}
