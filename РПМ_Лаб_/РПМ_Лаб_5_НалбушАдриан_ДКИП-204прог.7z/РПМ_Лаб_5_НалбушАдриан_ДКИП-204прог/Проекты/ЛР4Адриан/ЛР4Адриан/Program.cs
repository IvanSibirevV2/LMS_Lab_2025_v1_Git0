﻿using System;

namespace ExceptionHandlingExample
{
    public class BankAccount
    {
        private string _owner;
        private decimal _balance;

        // Конструктор без параметров
        public BankAccount()
        {
            _owner = "Неизвестный";
            _balance = 0m;
        }

        // Конструктор с параметрами
        public BankAccount(string owner, decimal initialBalance)
        {
            if (string.IsNullOrWhiteSpace(owner))
                throw new ArgumentException("Имя владельца не может быть пустым.", nameof(owner));
            if (initialBalance < 0)
                throw new ArgumentOutOfRangeException(nameof(initialBalance), "Начальный баланс не может быть отрицательным.");

            _owner = owner;
            _balance = initialBalance;
        }

        public string Owner
        {
            get => _owner;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Имя владельца не может быть пустым.");
                _owner = value;
            }
        }

        // Только для чтения
        public decimal Balance => _balance;

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount), "Сумма вклада должна быть положительной.");
            _balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount), "Сумма снятия должна быть положительной.");
            if (amount > _balance)
                throw new InvalidOperationException("Недостаточно средств для снятия.");
            _balance -= amount;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Владелец счёта: {Owner}");
            Console.WriteLine($"Баланс: {Balance:C}");
        }
    }

    class Program
    {
        static void Main()
        {
            try
            {
                BankAccount account = new BankAccount("Иван Иванов", 1000m);
                account.DisplayInfo();

                account.Deposit(500m);
                Console.WriteLine("После внесения 500:");
                account.DisplayInfo();

                account.Withdraw(300m);
                Console.WriteLine("После снятия 300:");
                account.DisplayInfo();

                Console.WriteLine("Попытка снять 1500:");
                account.Withdraw(1500m);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine("Ошибка диапазона: " + ex.Message);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Ошибка аргумента: " + ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Ошибка операции: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Общая ошибка: " + ex.Message);
            }

            Console.WriteLine("Программа завершена.");
        }
    }
}
