﻿using System;

namespace StudentManagement
{
    // Определение структуры STUDENT
    struct STUDENT
    {
        public string FullName; // Фамилия и инициалы
        public string GroupNumber; // Номер группы
        public int[] Grades; // Успеваемость (массив из пяти элементов)

        // Метод для вычисления среднего балла
        public double AverageGrade()
        {
            double sum = 0;
            foreach (var grade in Grades)
            {
                sum += grade;
            }
            return sum / Grades.Length;
        }
    }

    class Program
    {
        static void Main()
        {
            const int numberOfStudents = 10;
            STUDENT[] students = new STUDENT[numberOfStudents];

            // Ввод данных о студентах
            for (int i = 0; i < numberOfStudents; i++)
            {
                Console.WriteLine($"Введите данные для студента {i + 1}:");
                Console.Write("Фамилия и инициалы: ");
                students[i].FullName = Console.ReadLine();

                Console.Write("Номер группы: ");
                students[i].GroupNumber = Console.ReadLine();

                students[i].Grades = new int[5];
                Console.WriteLine("Введите 5 оценок (от 0 до 5):");
                for (int j = 0; j < 5; j++)
                {
                    Console.Write($"Оценка {j + 1}: ");
                    students[i].Grades[j] = int.Parse(Console.ReadLine());
                }
            }

            // Сортировка студентов по среднему баллу
            Array.Sort(students, (s1, s2) => s1.AverageGrade().CompareTo(s2.AverageGrade()));

            // Вывод студентов с оценками 4 и 5
            bool hasHighGrades = false;
            Console.WriteLine("\nСтуденты с оценками 4 и 5:");
            foreach (var student in students)
            {
                if (Array.Exists(student.Grades, grade => grade >= 4))
                {
                    Console.WriteLine($"Фамилия: {student.FullName}, Номер группы: {student.GroupNumber}");
                    hasHighGrades = true;
                }
            }

            if (!hasHighGrades)
            {
                Console.WriteLine("Студенты с оценками 4 и 5 не найдены.");
            }
        }
    }
}
