﻿using System;

namespace LabCombined
{
    // Лабораторная 1
    // ФИО: [Алиев Тимур Заурович]
    // Группа: [VДКИП 111-прог]
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Программа с тремя задачами:");
            Console.WriteLine("1 - Расчёт гиперболического синуса по двум формулам");
            Console.WriteLine("2 - Вычисление значения функции (Лаб. 2, Задание 1)");
            Console.WriteLine("3 - Попадание точки в заштрихованную область (Лаб. 2, Задание 2)");
            Console.WriteLine("Введите номер задачи (1, 2 или 3):");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Task1(); // Расчёт гиперболического синуса
                    break;
                case "2":
                    Task2(); // Вычисление значения функции
                    break;
                case "3":
                    Task3(); // Проверка попадания точки в область
                    break;
                default:
                    Console.WriteLine("Ошибка: введите 1, 2 или 3.");
                    break;
            }
        }

        // Задание 1: Расчёт гиперболического синуса по двум формулам
        static void Task1()
        {
            Console.WriteLine("\nЗадание 1: Расчёт гиперболического синуса по двум формулам");
            Console.WriteLine("Формула 1: sinh(x) = (e^x - e^-x) / 2");
            Console.WriteLine("Формула 2: sinh(x) = 2 * sinh(x/2) * cosh(x/2)");
            Console.WriteLine("Введите значение x в радианах:");

            string input = Console.ReadLine();
            if (double.TryParse(input, out double x))
            {
                double result1 = (Math.Exp(x) - Math.Exp(-x)) / 2;

                double xHalf = x / 2;
                double sinhHalf = (Math.Exp(xHalf) - Math.Exp(-xHalf)) / 2;
                double coshHalf = (Math.Exp(xHalf) + Math.Exp(-xHalf)) / 2;
                double result2 = 2 * sinhHalf * coshHalf;

                Console.WriteLine($"Результат по формуле 1: {result1:F6}");
                Console.WriteLine($"Результат по формуле 2: {result2:F6}");

                if (Math.Abs(result1 - result2) < 1e-10)
                {
                    Console.WriteLine("Результаты совпадают!");
                }
                else
                {
                    Console.WriteLine("Результаты не совпадают!");
                }
            }
            else
            {
                Console.WriteLine("Ошибка: введите корректное число.");
            }
        }

        // Задание 2: Вычисление значения функции (Лаб. 2, Задание 1)
        static void Task2()
        {
            Console.WriteLine("\nЗадание 2: Вычисление значения функции");
            Console.WriteLine("Функция: f(x) = -R при x < -R; x при -R <= x < 0; x^2 при 0 <= x < R; R при x >= R");
            Console.WriteLine("Введите параметр R:");
            if (!double.TryParse(Console.ReadLine(), out double R) || R <= 0)
            {
                Console.WriteLine("Ошибка: R должен быть положительным числом.");
                return;
            }

            Console.WriteLine("Введите значение x:");
            if (!double.TryParse(Console.ReadLine(), out double x))
            {
                Console.WriteLine("Ошибка: введите корректное число для x.");
                return;
            }

            double result;
            if (x < -R)
            {
                result = -R;
            }
            else if (x >= -R && x < 0)
            {
                result = x;
            }
            else if (x >= 0 && x < R)
            {
                result = x * x;
            }
            else // x >= R
            {
                result = R;
            }

            Console.WriteLine($"Значение функции f({x}) = {result:F2}");
        }

        // Задание 3: Попадание точки в заштрихованную область (Лаб. 2, Задание 2)
        static void Task3()
        {
            Console.WriteLine("\nЗадание 3: Попадание точки в область");
            Console.WriteLine("Область: круг с центром (0,0) и радиусом R");
            Console.WriteLine("Введите радиус R:");
            if (!double.TryParse(Console.ReadLine(), out double R) || R <= 0)
            {
                Console.WriteLine("Ошибка: R должен быть положительным числом.");
                return;
            }

            Console.WriteLine("Введите координату x:");
            if (!double.TryParse(Console.ReadLine(), out double x))
            {
                Console.WriteLine("Ошибка: введите корректное число для x.");
                return;
            }

            Console.WriteLine("Введите координату y:");
            if (!double.TryParse(Console.ReadLine(), out double y))
            {
                Console.WriteLine("Ошибка: введите корректное число для y.");
                return;
            }

            bool isInside = (x * x + y * y) <= (R * R);

            if (isInside)
            {
                Console.WriteLine($"Точка ({x}, {y}) попадает в заштрихованную область круга радиуса {R}.");
            }
            else
            {
                Console.WriteLine($"Точка ({x}, {y}) НЕ попадает в заштрихованную область круга радиуса {R}.");
            }
        }
    }
}