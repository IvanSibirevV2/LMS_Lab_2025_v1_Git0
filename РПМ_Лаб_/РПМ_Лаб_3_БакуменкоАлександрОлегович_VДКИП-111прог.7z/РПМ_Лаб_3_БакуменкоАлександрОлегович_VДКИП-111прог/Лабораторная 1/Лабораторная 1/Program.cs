﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите количество элементов в массиве: ");
        int n = Convert.ToInt32(Console.ReadLine());

        int[] array = new int[n];

        Console.WriteLine("Введите элементы массива:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Элемент {i + 1}: ");
            array[i] = Convert.ToInt32(Console.ReadLine());
        }

        int maxElement = FindMax(array, n);
        Console.WriteLine($"Максимальный элемент в массиве: {maxElement}");
    }

    static int FindMax(int[] array, int n)
    {
        if (n == 1)
        {
            return array[0];
        }

        int maxOfRest = FindMax(array, n - 1);

        return Math.Max(maxOfRest, array[n - 1]);
    }
}
