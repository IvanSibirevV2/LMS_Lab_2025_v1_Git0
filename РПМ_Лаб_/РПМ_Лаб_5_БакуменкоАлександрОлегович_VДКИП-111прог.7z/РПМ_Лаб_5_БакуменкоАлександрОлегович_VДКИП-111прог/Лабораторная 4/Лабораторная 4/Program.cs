﻿using System;

public class Date
{
    private int year;
    private int month;
    private int day;


    public Date(int year, int month, int day)
    {
        SetDate(year, month, day);
    }

    public void SetDate(int year, int month, int day)
    {
        if (year < 1)
            throw new ArgumentException("Год должен быть положительным числом.");

        if (month < 1 || month > 12)
            throw new ArgumentException("Месяц должен быть в диапазоне от 1 до 12.");

        if (day < 1 || day > GetDaysInMonth(year, month))
            throw new ArgumentException($"День должен быть в диапазоне от 1 до {GetDaysInMonth(year, month)} для месяца {month}.");

        this.year = year;
        this.month = month;
        this.day = day;
    }

    public void SetYear(int year)
    {
        if (year < 1)
            throw new ArgumentException("Год должен быть положительным числом.");
        this.year = year;
    }

    public void SetMonth(int month)
    {
        if (month < 1 || month > 12)
            throw new ArgumentException("Месяц должен быть в диапазоне от 1 до 12.");

        if (day > GetDaysInMonth(year, month))
            throw new ArgumentException($"Число {day} недопустимо для месяца {month}.");

        this.month = month;
    }

    public void SetDay(int day)
    {
        if (day < 1 || day > GetDaysInMonth(year, month))
            throw new ArgumentException($"День должен быть в диапазоне от 1 до {GetDaysInMonth(year, month)}.");
        this.day = day;
    }

    public void AddDays(int days)
    {
        DateTime dt = new DateTime(year, month, day);
        dt = dt.AddDays(days);
        SetDate(dt.Year, dt.Month, dt.Day);
    }

    public void AddMonths(int months)
    {
        DateTime dt = new DateTime(year, month, day);
        dt = dt.AddMonths(months);
        SetDate(dt.Year, dt.Month, dt.Day);
    }

    public void AddYears(int years)
    {
        DateTime dt = new DateTime(year, month, day);
        dt = dt.AddYears(years);
        SetDate(dt.Year, dt.Month, dt.Day);
    }

    private int GetDaysInMonth(int year, int month)
    {
        return DateTime.DaysInMonth(year, month);
    }

    public override string ToString()
    {
        return $"{day:00}.{month:00}.{year}";
    }
}
class Program
{
    static void Main(string[] args)
    {
        try
        {
            Date date = new Date(2023, 10, 1);
            Console.WriteLine("Исходная дата: " + date);

            date.AddDays(30);
            Console.WriteLine("Дата после добавления 30 дней: " + date);

            date.AddMonths(1);
            Console.WriteLine("Дата после добавления 1 месяца: " + date);

            date.AddYears(1);
            Console.WriteLine("Дата после добавления 1 года: " + date);

            date.SetDate(2024, 1, 15);
            Console.WriteLine("Новая дата: " + date);

            date.SetDay(28);
            date.SetMonth(2);
            Console.WriteLine("Измененная дата: " + date);

            date.SetDay(29);
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}