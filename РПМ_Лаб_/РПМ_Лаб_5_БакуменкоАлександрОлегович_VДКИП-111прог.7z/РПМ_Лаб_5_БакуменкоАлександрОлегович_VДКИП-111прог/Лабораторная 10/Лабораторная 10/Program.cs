﻿using System;

struct TRAIN
{
    public string Destination;
    public string TrainNumber;
    public DateTime DepartureTime;

    public TRAIN(string destination, string trainNumber, DateTime departureTime)
    {
        Destination = destination;
        TrainNumber = trainNumber;
        DepartureTime = departureTime;
    }
}

class Program
{
    static void Main(string[] args)
    {
        TRAIN[] trains = new TRAIN[6];

        for (int i = 0; i < trains.Length; i++)
        {
            Console.WriteLine($"Введите данные для поезда {i + 1}:");
            Console.Write("Название пункта назначения: ");
            string destination = Console.ReadLine();

            Console.Write("Номер поезда: ");
            string trainNumber = Console.ReadLine();

            Console.Write("Время отправления (в формате ГГГГ-ММ-ДД ЧЧ:ММ): ");
            DateTime departureTime;
            while (!DateTime.TryParse(Console.ReadLine(), out departureTime))
            {
                Console.Write("Некорректный формат. Пожалуйста, введите время отправления: ");
            }

            trains[i] = new TRAIN(destination, trainNumber, departureTime);
        }

        Array.Sort(trains, (train1, train2) => train1.DepartureTime.CompareTo(train2.DepartureTime));

        Console.Write("Введите пункт назначения для поиска поездов: ");
        string searchDestination = Console.ReadLine();

        Console.WriteLine($"\nПоезда, направляющиеся в пункт назначения '{searchDestination}':");
        bool found = false;

        foreach (var train in trains)
        {
            if (train.Destination.Equals(searchDestination, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"Номер поезда: {train.TrainNumber}, Время отправления: {train.DepartureTime}");
                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("Поездов в указанном направлении нет.");
        }
    }
}