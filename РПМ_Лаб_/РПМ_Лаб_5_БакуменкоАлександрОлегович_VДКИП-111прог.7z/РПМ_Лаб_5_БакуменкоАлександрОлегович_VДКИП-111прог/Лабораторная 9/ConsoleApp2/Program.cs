﻿using System;
using System.Collections.Generic;
using System.Drawing; 

public class Point
{
    public double X { get; set; }
    public double Y { get; set; }

    public Point() : this(0, 0) { }

    public Point(double x, double y)
    {
        X = x;
        Y = y;
    }
}

public class ColoredPoint : Point
{
    public Color Color { get; set; }

    public ColoredPoint() : this(0, 0, Color.Black) { }

    public ColoredPoint(double x, double y, Color color) : base(x, y)
    {
        Color = color;
    }
}

public class Line
{
    public Point Start { get; set; }
    public Point End { get; set; }

    public Line(Point start, Point end)
    {
        Start = start;
        End = end;
    }

    public void Rotate(double angleDegree)
    {
        double angleRad = angleDegree * Math.PI / 180;
        double cos = Math.Cos(angleRad);
        double sin = Math.Sin(angleRad);

        double newX = cos * (End.X - Start.X) - sin * (End.Y - Start.Y) + Start.X;
        double newY = sin * (End.X - Start.X) + cos * (End.Y - Start.Y) + Start.Y;

        End.X = newX;
        End.Y = newY;
    }
}

public class ColoredLine : Line
{
    public Color Color { get; set; }

    public ColoredLine(Point start, Point end, Color color) : base(start, end)
    {
        Color = color;
    }
}

public class PolyLine
{
    public List<Point> Points { get; set; }

    public PolyLine()
    {
        Points = new List<Point>();
    }

    public void AddPoint(Point point)
    {
        Points.Add(point);
    }

    public void Scale(double scaleFactor)
    {
        foreach (var point in Points)
        {
            point.X *= scaleFactor;
            point.Y *= scaleFactor;
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        ColoredPoint coloredPoint = new ColoredPoint(5, 10, Color.Red);
        Console.WriteLine($"ColoredPoint: ({coloredPoint.X}, {coloredPoint.Y}), Color: {coloredPoint.Color}");

        Line line = new Line(new Point(1, 1), new Point(4, 5));
        Console.WriteLine($"Line Start: ({line.Start.X}, {line.Start.Y}), End: ({line.End.X}, {line.End.Y})");

        line.Rotate(90);
        Console.WriteLine($"After rotation (90 degrees): Start: ({line.Start.X}, {line.Start.Y}), End: ({line.End.X}, {line.End.Y})");

        ColoredLine coloredLine = new ColoredLine(new Point(2, 2), new Point(5, 6), Color.Blue);
        Console.WriteLine($"ColoredLine Start: ({coloredLine.Start.X}, {coloredLine.Start.Y}), End: ({coloredLine.End.X}, {coloredLine.End.Y}), Color: {coloredLine.Color}");

        PolyLine polyLine = new PolyLine();
        polyLine.AddPoint(new Point(0, 0));
        polyLine.AddPoint(new Point(1, 1));
        polyLine.AddPoint(new Point(2, 2));

        Console.WriteLine("PolyLine Points before scaling:");
        foreach (var point in polyLine.Points)
        {
            Console.WriteLine($"({point.X}, {point.Y})");
        }


        polyLine.Scale(2);
        Console.WriteLine("PolyLine Points after scaling by 2:");
        foreach (var point in polyLine.Points)
        {
            Console.WriteLine($"({point.X}, {point.Y})");
        }
    }
}
