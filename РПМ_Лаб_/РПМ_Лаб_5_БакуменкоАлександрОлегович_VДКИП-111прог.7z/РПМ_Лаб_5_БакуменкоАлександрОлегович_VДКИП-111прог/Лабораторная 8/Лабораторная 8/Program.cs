﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Student
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime DateOfBirth { get; set; }

    public Student(string firstName, string lastName, DateTime dateOfBirth)
    {
        FirstName = firstName;
        LastName = lastName;
        DateOfBirth = dateOfBirth;
    }

    public override string ToString()
    {
        return $"{FirstName} {LastName}, Дата рождения: {DateOfBirth.ToShortDateString()}";
    }
}

public class StudentGroup
{
    private List<Student> students = new List<Student>();

    // Добавление студента
    public void AddStudent(Student student)
    {
        students.Add(student);
    }

    // Удаление студента
    public void RemoveStudent(Student student)
    {
        students.Remove(student);
    }

    // Поиск студента по фамилии
    public Student FindStudentByLastName(string lastName)
    {
        return students.FirstOrDefault(s => s.LastName.Equals(lastName, StringComparison.OrdinalIgnoreCase));
    }

    // Поиск студента по имени
    public Student FindStudentByFirstName(string firstName)
    {
        return students.FirstOrDefault(s => s.FirstName.Equals(firstName, StringComparison.OrdinalIgnoreCase));
    }

    // Поиск студента по дате рождения
    public List<Student> FindStudentsByDateOfBirth(DateTime dateOfBirth)
    {
        return students.Where(s => s.DateOfBirth.Date == dateOfBirth.Date).ToList();
    }

    // Сортировка студентов по фамилии
    public void SortByLastName()
    {
        students = students.OrderBy(s => s.LastName).ToList();
    }

    // Сортировка студентов по дате рождения
    public void SortByDateOfBirth()
    {
        students = students.OrderBy(s => s.DateOfBirth).ToList();
    }

    // Доступ к студенту по номеру (индексу)
    public Student GetStudentByIndex(int index)
    {
        if (index < 0 || index >= students.Count)
            throw new ArgumentOutOfRangeException(nameof(index), "Индекс выходит за пределы списка.");
        return students[index];
    }

    // Печать всех студентов
    public void PrintStudents()
    {
        Console.WriteLine("Список студентов:");
        foreach (var student in students)
        {
            Console.WriteLine(student);
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        StudentGroup group = new StudentGroup();

        // Добавление студентов
        group.AddStudent(new Student("Иван", "Иванов", new DateTime(2000, 5, 21)));
        group.AddStudent(new Student("Петр", "Петров", new DateTime(1999, 11, 15)));
        group.AddStudent(new Student("Светлана", "Сидорова", new DateTime(2001, 2, 10)));

        // Печать всех студентов
        group.PrintStudents();

        // Поиск студента по фамилии
        Console.WriteLine("\nПоиск студента по фамилии 'Петров':");
        var student = group.FindStudentByLastName("Петров");
        Console.WriteLine(student != null ? student.ToString() : "Студент не найден.");

        // Сортировка по фамилии
        group.SortByLastName();
        Console.WriteLine("\nСортировка студентов по фамилии:");
        group.PrintStudents();

        // Сортировка по дате рождения
        group.SortByDateOfBirth();
        Console.WriteLine("\nСортировка студентов по дате рождения:");
        group.PrintStudents();

        // Доступ к студенту по индексу
        try
        {
            Console.WriteLine("\nСтудент по индексу 1:");
            Console.WriteLine(group.GetStudentByIndex(1));
        }
        catch (ArgumentOutOfRangeException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        // Удаление студента
        group.RemoveStudent(student);
        Console.WriteLine("\nПосле удаления студента 'Петров':");
        group.PrintStudents();
    }
}
