import datetime

def err(y):
    try:
        int(y)
        return False
    except ValueError:
        return True

def calculate_age(birth_year):
    current_year = datetime.datetime.now().year
    if birth_year < 0:
        raise ValueError("Год рождения не может быть меньше нуля.")
    elif birth_year > current_year:
        raise ValueError("Год рождения не может быть больше текущего года.")
    return current_year - birth_year

def main():
    
    try:
        year_of_birth = input("Введите год рождения: ")  
        if err(year_of_birth):
            print("Ошибка ввода")
        else:
            age = calculate_age(int(year_of_birth))
            print(f"Ваш возраст: {age} лет.")
    except ValueError as e:
        print(f"Ошибка: {e}")

if __name__ == "__main__":
    main()
