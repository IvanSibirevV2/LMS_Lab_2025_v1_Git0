import math

PI = math.pi

def calculate(A, B, C):
    if A < -1.0 or A > 1.0:
        raise ValueError("Ошибка: A должно быть в диапазоне [-1, 1].")
    
    if math.sin(PI * B) < 0:
        raise ValueError("Ошибка: Выражение под корнем принимает отрицательные значения.")
    
    if C % 2 == 0.75:
        raise ValueError("Ошибка: tan(PI * C) + 1 не должно быть равно нулю.")
    
    if (C % 0.5 == 0.0) and (C != 0):
        raise ValueError("Ошибка: Тангенс не определен для Пи/2 + Пи*n (n=0,1,2...).")
    
    return math.acos(A) + math.sqrt(math.sin(PI * B)) / (math.tan(PI * C) + 1)

def main():
    try:
        A = float(input("Введите значение A (-1 <= A <= 1): "))
        B = float(input("Введите значение B (sin(PI * B) не должно принимать отрицательные значения) : "))
        C = float(input("Введите значение C (не кратно 1/2 а так же не должно приводить к tan(PI * C) + 1 = 0: "))

        result = calculate(A, B, C)
        print(f"Результат: {result}")
    
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    main()