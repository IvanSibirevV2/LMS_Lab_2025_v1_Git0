def is_float(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

def get_coefficients():
    while True:
        try:
            A = float(input("Введите A: "))
            B = float(input("Введите B: "))
            C = float(input("Введите C: "))
            D = float(input("Введите D: "))
            E = float(input("Введите E: "))
            F = float(input("Введите F: "))
            return A, B, C, D, E, F
        except ValueError:
            print("Ошибка: Введите корректное вещественное число.")

def line_type(A, B):
    if A == 0 and B == 0:
        return "не существует"
    elif A == 0:
        return "параллельно оси X"
    elif B == 0:
        return "параллельно оси Y"
    else:
        return "общего положения"

def cross(A, B, C, D, E, F):
    det = A * E - B * D

    if det == 0:
        # Прямые параллельны или совпадают
        if A * F == C * D and B * F == C * E:
            return "бесконечно много точек пересечения, т. к. прямые совпадают"
        else:
            return "точек пересечения нет, т. к. прямые параллельны"
    else:
        x = (C * E - B * F) / det
        y = (A * F - C * D) / det
        return f"одна точка пересечения: ({x}, {y})"


A, B, C, D, E, F = get_coefficients()

line1_type = line_type(A, B)
line2_type = line_type(D, E)

print(f"Первая прямая: {line1_type}")
print(f"Вторая прямая: {line2_type}")

if line1_type == "не существует" or line2_type == "не существует":
    print("Система неразрешима, т. к. одна или обе прямые не существуют.")
else:
    result = cross(A, B, C, D, E, F)
    print(result)

