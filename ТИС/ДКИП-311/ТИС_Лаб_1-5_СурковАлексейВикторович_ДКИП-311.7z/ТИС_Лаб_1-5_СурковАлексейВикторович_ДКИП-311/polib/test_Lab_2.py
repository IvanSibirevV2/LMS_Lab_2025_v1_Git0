import pytest
from Lab_2 import to_decode, write_encrypt, get_encrypt, to_encrypt, read_encrypt, is_all_latin_letters, is_code, get_decode

data_is_all_latin = (
    ("abcdefghijklmnopqrstuvwxyz", True),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", True),
    ("абв", False),
    ("АБВ", False),
    ("123", False),
    (" , ", False),
    ("Hello Word",False),
)

@pytest.mark.parametrize('symbol, result', data_is_all_latin)
def test_is_all_latin_letter(symbol, result):
    assert is_all_latin_letters(symbol) == result


data_get_encrypt = (
    ("A", "11"),
    ("B", "12"),
    ("C", "13"),
    ("D", "14"),
    ("E", "15"),
    ("F", "21"),
    ("G", "22"),
    ("H", "23"),
    ("I", "24"),
    ("J", "24"),
    ("K", "25"),
    ("L", "31"),
    ("M", "32"),
    ("N", "33"),
    ("O", "34"),
    ("P", "35"),
    ("Q", "41"),
    ("R", "42"),
    ("S", "43"),
    ("T", "44"),
    ("U", "45"),
    ("V", "51"),
    ("W", "52"),
    ("X", "53"),
    ("Y", "54"),
    ("Z", "55")
)


@pytest.mark.parametrize('symbol, result', data_get_encrypt)
def test_data_get_encrypt(symbol, result):
    assert get_encrypt(symbol) == result


data_to_encrypt = (
    ("abcdefghijklmnopqrstuvwxyz", "1112131415212223242425313233343541424344455152535455"),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "1112131415212223242425313233343541424344455152535455")
)


@pytest.mark.parametrize('text, result', data_to_encrypt)
def test_to_encrypt(text, result):
    assert to_encrypt(text) == result


data_read_write = (
    ("abc", "111213"),
    ("xyz", "535455")
)


@pytest.mark.parametrize('text, result', data_read_write)
def test_read_write(text, result):
    write_encrypt(text)
    assert read_encrypt() == result


data_is_code = (
    ("1", False),
    ("1277", False),
    ("abc", False),
    ("", False),
    ("11", True)
)


@pytest.mark.parametrize('text, result', data_is_code)
def test_is_code(text, result):
    assert is_code(text) == result



data_get_decode = (
    ("A", "A"),
    ("B", "B"),
    ("C", "C"),
    ("D", "D"),
    ("E", "E"),
    ("F", "F"),
    ("G", "G"),
    ("H", "H"),
    ("I", "I"),
    ("J", "J"),
    ("K", "K"),
    ("L", "L"),
    ("M", "M"),
    ("N", "N"),
    ("O", "O"),
    ("P", "P"),
    ("Q", "Q"),
    ("R", "R"),
    ("S", "S"),
    ("T", "T"),
    ("U", "U"),
    ("V", "V"),
    ("W", "W"),
    ("X", "X"),
    ("Y", "Y"),
    ("Z", "Z"),
)


@pytest.mark.parametrize('text, result', data_get_decode)
def test_get_decode(text, result):
    write_encrypt(text)
    assert to_decode() == result

