def get_table() -> tuple:
    table = (
        ("A", "B", "C", "D", "E"),
        ("F", "G", "H", "IJ", "K"),
        ("L", "M", "N", "O", "P"),
        ("Q", "R", "S", "T", "U"),
        ("V", "W", "X", "Y", "Z"))
    return table

def is_all_latin_letters(text) -> bool:
    return all(s.isalpha() and ('A' <= s.upper() <= "Z") for s in text)

def get_encrypt(symbol: str) -> str:
    table = get_table()
    if symbol.upper() in ("I", "J"):
        return "24"
    for i, line in enumerate(table, start=1):
        for j, smbl in enumerate(line, start=1):
             if symbol.upper() == smbl:
                return f"{i}{j}"

def to_encrypt(text: str) -> str:
    crypt_text = ""
    for symbol in text:
        crypt_text += get_encrypt(symbol)
    return crypt_text

def write_encrypt(text: str) -> None:
    with open("crypt.txt", "w") as file:
        file.write(to_encrypt(text))

def read_encrypt() -> str:
    with open("crypt.txt") as file:
        text = file.read()
        return text

def is_code(text:str) -> bool:
    if not len(text) == 0:
        return all(s.isdigit() and (1 <= int(s) <= 5) and (len(text)%2 == 0) for s in text)
    else:
        return False

def get_decode(i: int, j: int) -> str:
    table = get_table()
    symbol = table[i][j]
    return symbol

def to_decode() -> str:
    encrypt_text = read_encrypt()
    if is_code(encrypt_text):
        text = ""
        while len(encrypt_text) > 0:
            i = int(encrypt_text[0])-1
            j = int(encrypt_text[1])-1
            text += get_decode(i, j)
            encrypt_text = encrypt_text[2:]
        return text
    else:
        return "Содержимое файла не корректно"

def main(your_text: str):
    if not len(your_text) == 0 :
        if is_all_latin_letters(your_text):
            print (f"Код {to_encrypt(your_text)} записан в файл")
            write_encrypt(your_text)  
        else:
            print ('Ошибка ввода, символы не подлежат кодированию')
    else:
        print("Не введены символы")


#main(input("Введите текст: ")) # для задания 1.а)

#print(f"Файл содержит: {read_encrypt()} -> {to_decode()}") # для задания 1.б)
