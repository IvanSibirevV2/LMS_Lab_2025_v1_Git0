import pytest
from Lab_1 import main


data = (
    (0, 0, 0, "Бесконечное число корней"),
    (1, 2, 1, -1),
    (9, 0, 0, 0),
    (0, 2, 1, -0.5),
    (0, 0, 1,"Нет корней"),
    (3, 2, 15, "Комплексные корни"),
    (3, -12, 0, (4,0)),
    ('s', 2, 'b',"Ошибка ввода"),
    (0.1,0.2,0,(0.0,-2.0))
)

@pytest.mark.parametrize('a, b, c, result', data)
def test_disc(a, b, c, result):
    assert main(a, b, c) == result