def err(s):
    try:
        float(s)
        return False
    except ValueError:
        return True

def dis(a, b, c):
    d = b ** 2 - 4 * a * c
    return d

def two_root(a, b, d):
    x1 = (-b + d ** (1/2)) / (2 * a)
    x2 = (-b - d ** (1/2)) / (2 * a)
    return x1, x2

def one_root(a, b):
    x = -b / (2 * a)
    return x

def null_root():
    return "Нет корней"

def s_root(a, b, d): 
    if d < 0:
        return "Комплексные корни"
    if d == 0:
        return one_root(a, b)
    if d > 0:
        return two_root(a, b, d)

def main(a, b, c):
    if err(a) or err(b) or err(c): # Для тестирования с помощью pytest
        return "Ошибка ввода"
    else:
        if a == 0:
            if b == 0:
                if c == 0:
                    return "Бесконечное число корней"
                else:
                    res = null_root()
            else:
                res = (-1)*c/b
        else:
            d = dis(a, b, c)
            res = s_root(a, b, d)
        return res
'''
print('Решаем уравнение a•x²+b•x+c=0')
a = input('Введите значение a: ').replace(',','.')
if err(a):
    print("Ошибка ввода")
else:
    b = input('Введите значение b: ').replace(',','.')
    if err(b):
        print("Ошибка ввода")
    else:
        c = input('Введите значение c: ').replace(',','.')
        if err(c):
            print("Ошибка ввода")
        else:
            print(f"Решение уравнения : {main(float(a),float(b),float(c))}")
'''